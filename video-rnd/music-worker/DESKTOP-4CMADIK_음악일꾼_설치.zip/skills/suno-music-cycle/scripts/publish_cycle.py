#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""suno-music-cycle 발행 도구.

  make-reel     90초 이하, 1080x1920, 30fps 릴스 규격으로 자르기(오디오는 이득만, 320k 한 번. --audio-copy 면 비트 동일)
  safe-mux      Suno MP4 를 업로드 전에 음질 변동 없이 정리(true peak 안전하면 스트림 복사)
  accounts      Zernio에 연결된 계정 목록 확인 (읽기 전용)
  instagram     Zernio 업로드(presign) 후 인스타 릴스 즉시 게시, 게시물 링크를 IG_PERMALINK 로 출력
  story         같은 영상을 인스타 스토리에 즉시 게시 (60초 이하)
  auth-youtube  유튜브 OAuth 최초 1회 인증 (사람이 동의 화면에서 허용)
  youtube       유튜브 공식 Data API v3로 업로드 (기본 비공개)

설정은 ~/.config/suno-cycle/.env 에서 읽는다 (값은 절대 출력하지 않는다).
실행은 전용 venv로: ~/.config/suno-cycle/venv/Scripts/python.exe -u publish_cycle.py ...
좋아요(하트)는 공식 API·Zernio에 없어서 이 스크립트가 아니라 SKILL.md 의 브라우저 단계에서 한다.
"""
from __future__ import annotations

import argparse
import glob
import json
import re
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import requests
from dotenv import dotenv_values

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

CFG_DIR = Path(os.environ.get("SUNO_CYCLE_HOME") or Path.home() / ".config" / "suno-cycle")
ENV = {**dotenv_values(CFG_DIR / ".env"), **os.environ}
YT_SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]


def need(key: str) -> str:
    v = ENV.get(key, "")
    if not v:
        sys.exit(f"설정 누락: {key} ({CFG_DIR / '.env'})")
    return v


def tool(name: str) -> str:
    p = shutil.which(name)
    if p:
        return p
    pattern = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WinGet", "Packages",
                           "Gyan.FFmpeg*", "**", "bin", name + ".exe")
    hits = glob.glob(pattern, recursive=True)
    if hits:
        return hits[0]
    sys.exit(f"{name} 를 찾을 수 없습니다 (ffmpeg 설치 필요)")


def probe(path: str) -> dict:
    out = subprocess.run(
        [tool("ffprobe"), "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height,r_frame_rate,codec_name:format=duration,size",
         "-of", "json", path], capture_output=True, text=True, check=True).stdout
    j = json.loads(out)
    s = j["streams"][0]
    num, den = s["r_frame_rate"].split("/")
    return {"width": s["width"], "height": s["height"], "fps": round(int(num) / int(den), 2),
            "codec": s["codec_name"], "duration": float(j["format"]["duration"]),
            "size_mb": round(int(j["format"]["size"]) / 1e6, 2)}


# ---------------------------------------------------------------- 음질 보존 (2026-10-18 사용자 지시: Suno 원본 음질이 업로드에서 변하지 않게)
def _ebur128(src: str, ss: float | None = None, dur: float | None = None) -> tuple[float, float]:
    """(통합 음량 LUFS, true peak dBFS). 실패하면 (nan, nan)."""
    cmd = [tool("ffmpeg"), "-hide_banner", "-nostats"]
    if ss is not None:
        cmd += ["-ss", str(ss)]
    if dur is not None:
        cmd += ["-t", f"{dur:.3f}"]
    cmd += ["-i", src, "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    tail = r.stderr[r.stderr.rfind("Summary"):] if "Summary" in r.stderr else ""
    mi = re.search(r"I:\s+(-?\d+\.\d+) LUFS", tail)
    mp = re.search(r"True peak:\s+Peak:\s+(-?\d+\.\d+) dBFS", tail) or re.search(r"Peak:\s+(-?\d+\.\d+) dBFS", tail)
    return (float(mi.group(1)) if mi else float("nan"), float(mp.group(1)) if mp else float("nan"))


def safe_gain_db(src: str, ss: float | None, dur: float | None, ceiling: float = -1.0, lufs: float = 0.0) -> tuple[float, float, float]:
    """음질을 건드리지 않는 이득만 구한다: true peak 가 ceiling 보다 높으면 그만큼만 낮추고(리미터·압축기 없음), 올리지는 않는다.
    lufs 를 주면 그 음량까지 선형 이득(ceiling 을 넘지 않는 범위, 최대 +3dB)을 쓴다. 반환: (이득 dB, 원본 LUFS, 원본 true peak)."""
    loud, tp = _ebur128(src, ss, dur)
    if tp != tp:  # 측정 실패
        return 0.0, loud, tp
    gain = min(0.0, ceiling - tp)
    if lufs and loud == loud:
        gain = max(gain, min(lufs - loud, ceiling - tp, 3.0))
    return round(gain, 2), loud, tp


AAC_Q = ["-c:a", "aac", "-b:a", "320k", "-ar", "48000"]  # Suno 원본(AAC 196k·48kHz)보다 높은 비트레이트로 한 번만 재인코딩 → 실측 잔차 SNR 약 43dB(귀로 구분 불가)


def cmd_make_reel(a) -> None:
    dur = a.end - a.start
    if dur <= 0 or dur > 90:
        sys.exit(f"릴스 길이는 3~90초여야 합니다 (지금 {dur:.1f}초)")
    fo = a.fade
    vf = f"scale=1080:1920:flags=lanczos,fps=30,fade=t=out:st={dur - fo:.2f}:d={fo},format=yuv420p"
    cmd = [tool("ffmpeg"), "-v", "error", "-y", "-ss", str(a.start), "-i", a.src, "-t", f"{dur:.2f}", "-vf", vf]
    if a.audio_copy:
        # 오디오를 한 번도 다시 인코딩하지 않는다(비트 동일). 페이드·이득 없음 → 끝이 뚝 끊길 수 있으니 컷 끝이 숨 고르는 곳일 때만.
        cmd += ["-c:a", "copy"]
        print("오디오: 스트림 복사(비트 동일, 페이드·이득 없음)")
    else:
        gain, loud, tp = safe_gain_db(a.src, a.start, dur, ceiling=a.true_peak, lufs=a.lufs)
        af = f"afade=t=in:st=0:d=0.05,afade=t=out:st={dur - fo:.2f}:d={fo}"
        if gain != 0:
            af = f"volume={gain}dB," + af
        print(f"오디오: 원본 {loud} LUFS / true peak {tp} dBFS → 이득 {gain:+.2f} dB만 적용(리미터·압축·리샘플 없음), AAC 320k·48kHz로 한 번만 인코딩")
        cmd += ["-af", af] + AAC_Q
    cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", "22", "-profile:v", "high", "-r", "30", "-movflags", "+faststart", a.out]
    subprocess.run(cmd, check=True)
    info = probe(a.out)
    print("릴스 파일:", a.out)
    print(json.dumps(info, ensure_ascii=False))
    if info["duration"] > 90 or info["fps"] < 23 or info["size_mb"] > 300:
        sys.exit("릴스 규격(90초 이하, 23fps 이상, 300MB 이하)을 벗어났습니다")


def cmd_safe_mux(a) -> None:
    """Suno MP4 를 올리기 전에: true peak 가 안전하면(<= ceiling) 영상·오디오 모두 스트림 복사(비트 동일), 넘으면 영상은 복사하고 오디오만
    선형 이득을 낮춰 AAC 320k 로 한 번 인코딩한다(Suno 원본은 true peak +0.3~+0.4 dBFS 라 플랫폼 재인코딩에서 고음이 깨질 위험이 있다)."""
    gain, loud, tp = safe_gain_db(a.src, None, None, ceiling=a.true_peak)
    if gain == 0:
        cmd = [tool("ffmpeg"), "-v", "error", "-y", "-i", a.src, "-c", "copy", "-movflags", "+faststart", a.out]
        print(f"원본 {loud} LUFS / true peak {tp} dBFS ≤ {a.true_peak} → 영상·오디오 스트림 복사(비트 동일)")
    else:
        cmd = [tool("ffmpeg"), "-v", "error", "-y", "-i", a.src, "-c:v", "copy", "-af", f"volume={gain}dB"] + AAC_Q + ["-movflags", "+faststart", a.out]
        print(f"원본 {loud} LUFS / true peak {tp} dBFS → 오디오 이득 {gain:+.2f} dB만 적용, AAC 320k·48kHz 한 번 인코딩(영상은 복사)")
    subprocess.run(cmd, check=True)
    loud2, tp2 = _ebur128(a.out)
    print(f"결과: {a.out}  {loud2} LUFS / true peak {tp2} dBFS")


# ---------------------------------------------------------------- Zernio / Instagram
def zbase() -> str:
    return ENV.get("ZERNIO_API_BASE", "https://zernio.com/api/v1").rstrip("/")


def zheaders(json_body: bool = False) -> dict:
    h = {"Authorization": f"Bearer {need('ZERNIO_API_KEY')}"}
    if json_body:
        h["Content-Type"] = "application/json"
    return h


def _accounts_list(payload) -> list:
    if isinstance(payload, list):
        return payload
    for k in ("accounts", "data", "items", "results"):
        if isinstance(payload, dict) and isinstance(payload.get(k), list):
            return payload[k]
    return []


def cmd_accounts(_a) -> None:
    r = requests.get(f"{zbase()}/accounts", headers=zheaders(), timeout=30)
    if r.status_code >= 400:
        sys.exit(f"Zernio 계정 조회 실패: {r.status_code} {r.text[:300]}")
    want = need("ZERNIO_INSTAGRAM_ACCOUNT_ID")
    found = False
    for acc in _accounts_list(r.json()):
        aid = str(acc.get("_id") or acc.get("id") or acc.get("accountId") or "")
        name = acc.get("username") or acc.get("displayName") or acc.get("name") or ""
        plat = acc.get("platform") or acc.get("type") or ""
        mark = "  <- 설정된 인스타 계정" if aid == want else ""
        found = found or aid == want
        print(f"{plat:12} {name:30} {aid}{mark}")
    if not found:
        sys.exit("설정된 ZERNIO_INSTAGRAM_ACCOUNT_ID 가 연결된 계정 목록에 없습니다")


def upload_media(video: str) -> str:
    """Zernio presign -> PUT. 임시 저장소(7일)에 올리고 publicUrl 을 돌려준다."""
    fname = f"suno_{time.strftime('%Y%m%d_%H%M%S')}.mp4"
    size = os.path.getsize(video)
    p = requests.post(f"{zbase()}/media/presign", headers=zheaders(True), timeout=30,
                      json={"filename": fname, "contentType": "video/mp4", "size": size})
    if p.status_code >= 400:
        sys.exit(f"presign 실패: {p.status_code} {p.text[:300]}")
    pj = p.json()
    upload_url, public_url = pj.get("uploadUrl"), pj.get("publicUrl")
    if not upload_url or not public_url:
        sys.exit(f"presign 응답에 uploadUrl/publicUrl 이 없습니다: {list(pj.keys())}")
    with open(video, "rb") as f:
        put = requests.put(upload_url, data=f, headers={"Content-Type": "video/mp4"}, timeout=600)
    if put.status_code >= 400:
        sys.exit(f"파일 업로드 실패: {put.status_code} {put.text[:300]}")
    print(f"업로드 완료: {size / 1e6:.1f}MB")
    return public_url


def create_ig_post(public_url: str, content: str, story: bool, share_to_feed: bool, ai: bool) -> requests.Response:
    psd: dict = {"contentType": "story"} if story else {"shareToFeed": share_to_feed}
    if ai:
        psd["isAiGenerated"] = True
    body = {"content": content,
            "mediaItems": [{"type": "video", "url": public_url}],
            "platforms": [{"platform": "instagram", "accountId": need("ZERNIO_INSTAGRAM_ACCOUNT_ID"),
                           "platformSpecificData": psd}],
            "publishNow": True}
    r = requests.post(f"{zbase()}/posts", headers=zheaders(True), json=body, timeout=180)
    if ai and r.status_code == 400 and "isAiGenerated" in r.text:
        print("isAiGenerated 를 받지 않아 빼고 다시 요청합니다")
        psd.pop("isAiGenerated", None)
        r = requests.post(f"{zbase()}/posts", headers=zheaders(True), json=body, timeout=180)
    return r


def report_ig(r: requests.Response, label: str) -> str | None:
    print(f"{label} 응답:", r.status_code, r.text[:700])
    try:
        data = r.json()
    except ValueError:
        sys.exit(f"{label} 실패: JSON 응답이 아닙니다")
    post = data.get("post") if isinstance(data.get("post"), dict) else data
    if r.status_code >= 300 and r.status_code != 207:
        sys.exit(f"{label} 요청 실패: HTTP {r.status_code}")
    return wait_published(post, label)


def _plats(post: dict) -> list:
    return [x for x in (post.get("platforms") or []) if isinstance(x, dict)]


def wait_published(post: dict, label: str, tries: int = 24) -> str | None:
    """게시는 비동기라 처음 응답은 보통 status=publishing 이다. published/failed 가 될 때까지 확인한다."""
    pid = str(post.get("_id") or "")
    for _ in range(tries):
        plats = _plats(post)
        st = post.get("status")
        if st == "published" or any(x.get("status") == "published" for x in plats):
            return next((x.get("platformPostUrl") for x in plats if x.get("platformPostUrl")), None)
        if st == "failed" or any(x.get("status") == "failed" for x in plats):
            errs = [x.get("errorMessage") for x in plats if x.get("errorMessage")]
            sys.exit(f"{label} 실패: 상태={st} 오류={errs}")
        if not pid:
            break
        time.sleep(10)
        g = requests.get(f"{zbase()}/posts/{pid}", headers=zheaders(), timeout=30)
        if g.status_code >= 400:
            print(f"{label} 상태 조회 실패: {g.status_code} {g.text[:200]}")
            break
        gj = g.json()
        post = gj.get("post") if isinstance(gj.get("post"), dict) else gj
        print(f"{label} 상태:", post.get("status"))
    sys.exit(f"{label}: 4분 안에 게시 완료를 확인하지 못했습니다 (post id={pid}). 중복 게시를 피하려면 post-status 로 확인하세요.")


def cmd_post_status(a) -> None:
    g = requests.get(f"{zbase()}/posts/{a.id}", headers=zheaders(), timeout=30)
    print("HTTP", g.status_code)
    if g.status_code >= 300:
        print(g.text[:500])
        return
    gj = g.json()
    post = gj.get("post") if isinstance(gj.get("post"), dict) else gj
    print("post.status =", post.get("status"), "| publishedAt =", post.get("publishedAt"))
    for x in _plats(post):
        keys = ("status", "platformPostId", "platformPostUrl", "publishedAt", "errorMessage", "errorCategory")
        print(" -", x.get("platform"), {k: x.get(k) for k in keys if x.get(k) is not None})
    print("IG_PERMALINK", next((x.get("platformPostUrl") for x in _plats(post) if x.get("platformPostUrl")), "(아직 없음)"))


def cmd_instagram(a) -> None:
    info = probe(a.video)
    if info["duration"] > 90 or info["duration"] < 3:
        sys.exit(f"인스타 릴스는 3~90초여야 합니다 (지금 {info['duration']:.1f}초). make-reel 로 먼저 자르세요.")
    caption = Path(a.caption_file).read_text(encoding="utf-8").strip()
    if len(caption) > 2200:
        sys.exit(f"캡션이 2200자를 넘습니다 ({len(caption)}자)")
    if a.dry_run:
        print("[DRY RUN] 업로드·게시하지 않음. 규격:", json.dumps(info, ensure_ascii=False))
        print("캡션 미리보기:\n" + caption)
        return
    url = create_ig_post(upload_media(a.video), caption, story=False,
                         share_to_feed=not a.reels_tab_only, ai=not a.no_ai_label)
    permalink = report_ig(url, "인스타 릴스")
    print(f"IG_PERMALINK {permalink}" if permalink else "IG_PERMALINK (응답에 링크 없음)")


def cmd_story(a) -> None:
    info = probe(a.video)
    if info["duration"] > 60 or info["duration"] < 3:
        sys.exit(f"스토리는 3~60초여야 합니다 (지금 {info['duration']:.1f}초)")
    if a.dry_run:
        print("[DRY RUN] 스토리 게시하지 않음. 규격:", json.dumps(info, ensure_ascii=False))
        return
    r = create_ig_post(upload_media(a.video), "", story=True, share_to_feed=False, ai=not a.no_ai_label)
    report_ig(r, "인스타 스토리")
    print("IG_STORY_OK")


# ---------------------------------------------------------------- YouTube
def yt_creds(interactive: bool):
    from google.auth.exceptions import RefreshError
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials

    tok = Path(ENV.get("YOUTUBE_TOKEN_FILE") or CFG_DIR / "youtube_token.json")
    creds = None
    if tok.exists():
        creds = Credentials.from_authorized_user_file(str(tok), YT_SCOPES)
        if not creds.valid and creds.refresh_token:
            try:
                creds.refresh(Request())
                tok.write_text(creds.to_json(), encoding="utf-8")
            except RefreshError as e:
                print(f"refresh token 만료/무효: {e}")
                creds = None
    if creds and creds.valid:
        return creds
    if not interactive:
        sys.exit("유튜브 토큰이 없거나 만료됐습니다. `auth-youtube` 로 사람이 한 번 인증해야 합니다.")

    from google_auth_oauthlib.flow import InstalledAppFlow
    cfg = {"installed": {
        "client_id": need("YOUTUBE_CLIENT_ID"), "client_secret": need("YOUTUBE_CLIENT_SECRET"),
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "redirect_uris": ["http://localhost"]}}
    flow = InstalledAppFlow.from_client_config(cfg, YT_SCOPES)
    creds = flow.run_local_server(
        port=0, open_browser=False, timeout_seconds=900,
        authorization_prompt_message="AUTH_URL: {url}",
        success_message="인증이 끝났습니다. 이 창은 닫아도 됩니다.")
    tok.parent.mkdir(parents=True, exist_ok=True)
    tok.write_text(creds.to_json(), encoding="utf-8")
    print("AUTH_OK 토큰 저장:", tok)
    return creds


def cmd_auth_youtube(_a) -> None:
    yt_creds(interactive=True)


def cmd_youtube(a) -> None:
    from googleapiclient.discovery import build
    from googleapiclient.errors import HttpError
    from googleapiclient.http import MediaFileUpload

    title = (Path(a.title_file).read_text(encoding="utf-8").strip() if a.title_file else a.title)[:100]
    if not title:
        sys.exit("--title 또는 --title-file 이 필요합니다")
    description = Path(a.description_file).read_text(encoding="utf-8").strip()[:5000]
    tags = [t.strip() for t in (a.tags or "").split(",") if t.strip()]
    privacy = a.privacy or ENV.get("YOUTUBE_PRIVACY_STATUS", "private")
    category = ENV.get("YOUTUBE_CATEGORY_ID", "10")
    body = {"snippet": {"title": title, "description": description, "tags": tags, "categoryId": category},
            "status": {"privacyStatus": privacy, "selfDeclaredMadeForKids": False}}
    if a.dry_run:
        print("[DRY RUN] 업로드하지 않음")
        print(json.dumps(body, ensure_ascii=False, indent=1))
        return

    creds = yt_creds(interactive=a.auth_if_needed)
    svc = build("youtube", "v3", credentials=creds)
    media = MediaFileUpload(a.video, chunksize=-1, resumable=True, mimetype="video/mp4")
    try:
        req = svc.videos().insert(part="snippet,status", body=body, media_body=media)
        resp = None
        while resp is None:
            status, resp = req.next_chunk()
            if status:
                print(f"유튜브 업로드 {int(status.progress() * 100)}%")
    except HttpError as e:
        sys.exit(f"유튜브 업로드 실패: {e}")
    vid = resp["id"]
    # youtube.upload 스코프로는 videos.list 를 못 읽는다(403). insert 응답의 status 를 그대로 쓴다.
    st = resp.get("status", {})
    print(f"YOUTUBE_OK https://youtu.be/{vid}  공개상태={st.get('privacyStatus')}  업로드상태={st.get('uploadStatus')}")
    if st.get("privacyStatus") != privacy:
        print(f"참고: 요청한 공개 상태({privacy})와 실제({st.get('privacyStatus')})가 다릅니다. "
              "미검증 API 프로젝트는 감사 전까지 비공개로 고정됩니다.")


# ---------------------------------------------------------------- CLI
def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("make-reel")
    s.add_argument("--src", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--start", type=float, required=True)
    s.add_argument("--end", type=float, required=True)
    s.add_argument("--fade", type=float, default=0.6, help="끝 페이드 길이(초). 마지막 음절을 살리려면 0.25 정도")
    s.add_argument("--lufs", type=float, default=0.0, help="목표 음량(LUFS). 기본 0=끔(음질 보존). 주면 선형 이득만 쓰고 true peak 한계를 넘지 않는다")
    s.add_argument("--true-peak", type=float, default=-1.0, help="true peak 상한(dBFS). 원본이 이보다 높을 때만 그만큼 낮춘다")
    s.add_argument("--audio-copy", action="store_true", help="오디오를 재인코딩 없이 그대로 복사(비트 동일, 페이드·이득 없음)")
    s.set_defaults(fn=cmd_make_reel)

    s = sub.add_parser("safe-mux", help="Suno MP4 를 음질 변동 없이 업로드용으로 정리(안전하면 스트림 복사, 아니면 이득만 낮춰 320k 한 번)")
    s.add_argument("--src", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--true-peak", type=float, default=-1.0)
    s.set_defaults(fn=cmd_safe_mux)

    s = sub.add_parser("accounts")
    s.set_defaults(fn=cmd_accounts)

    s = sub.add_parser("instagram")
    s.add_argument("--video", required=True)
    s.add_argument("--caption-file", required=True)
    s.add_argument("--reels-tab-only", action="store_true", help="피드에는 안 올리고 릴스 탭에만")
    s.add_argument("--no-ai-label", action="store_true", help="AI 생성 표시(isAiGenerated)를 켜지 않음")
    s.add_argument("--dry-run", action="store_true")
    s.set_defaults(fn=cmd_instagram)

    s = sub.add_parser("story")
    s.add_argument("--video", required=True)
    s.add_argument("--no-ai-label", action="store_true")
    s.add_argument("--dry-run", action="store_true")
    s.set_defaults(fn=cmd_story)

    s = sub.add_parser("post-status", help="이미 요청한 인스타 게시물 상태 확인 (중복 게시 방지)")
    s.add_argument("--id", required=True)
    s.set_defaults(fn=cmd_post_status)

    s = sub.add_parser("auth-youtube")
    s.set_defaults(fn=cmd_auth_youtube)

    s = sub.add_parser("youtube")
    s.add_argument("--video", required=True)
    s.add_argument("--title", default="")
    s.add_argument("--title-file", help="제목을 UTF-8 파일로 전달 (공백·괄호 인용 문제 방지)")
    s.add_argument("--description-file", required=True)
    s.add_argument("--tags", default="")
    s.add_argument("--privacy", choices=["private", "unlisted", "public"])
    s.add_argument("--auth-if-needed", action="store_true", help="토큰이 없으면 OAuth 동의 URL을 출력하고 기다림")
    s.add_argument("--dry-run", action="store_true")
    s.set_defaults(fn=cmd_youtube)

    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
