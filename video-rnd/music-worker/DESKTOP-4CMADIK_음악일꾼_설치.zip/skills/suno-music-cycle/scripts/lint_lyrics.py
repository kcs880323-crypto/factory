#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Suno 입력 사전 점검 (표준 라이브러리만 사용). 연출PD 검수 규칙을 기계로 확인한다.

  python lint_lyrics.py --md 날짜_제목_최종.md [--hook "훅 한 줄"]
  python lint_lyrics.py --style-file style.txt --lyrics-file lyrics.txt [--hook ...]

--md 는 첫 번째 코드 블록을 스타일, 두 번째 코드 블록을 가사로 읽는다(최종.md 형식).
실패가 있으면 종료 코드 1. 주의는 사람이 판단한다.
"""
from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

SECTION_RE = re.compile(r"^\[([^\]]+)\]\s*$")
KNOWN = ("intro", "verse", "pre-chorus", "chorus", "final chorus", "bridge", "outro", "instrumental", "break", "hook")
DIRECTION_WORDS = ("다 같이", "반복", "x2", "×2", "코러스", "후렴", "간주", "합창", "속삭", "크게", "작게")
BANNED_AI_CLICHES = (
    ("센서등", re.compile(r"센서등")),
    ("신발장", re.compile(r"신발장")),
    ("식은 밥", re.compile(r"식은\s*밥")),
    ("밥 데우기", re.compile(r"밥을?\s*(?:데워|댑혀|데우)")),
    ("전자레인지", re.compile(r"전자레인지")),
    ("달걀/계란 하나", re.compile(r"(?:달걀|계란)\s*하나")),
    ("반찬통", re.compile(r"반찬통")),
    ("현관 불빛/앞/문", re.compile(r"현관\s*(?:불빛|등|앞|문)")),
    ("삼각김밥", re.compile(r"삼각김밥")),
)
HANGUL = re.compile(r"[가-힣]")
LATIN = re.compile(r"[A-Za-z]")

results: list[tuple[str, str, str]] = []  # (level, name, detail)


def add(level: str, name: str, detail: str = "") -> None:
    results.append((level, name, detail))


def syl(line: str) -> int:
    return len(HANGUL.findall(re.sub(r"\([^)]*\)", "", line)))


def parse_md(path: Path) -> tuple[str, str]:
    blocks = re.findall(r"```[^\n]*\n(.*?)```", path.read_text(encoding="utf-8"), flags=re.S)
    if len(blocks) < 2:
        sys.exit("최종.md 에서 코드 블록 2개(스타일, 가사)를 찾지 못했습니다")
    return blocks[0].strip(), blocks[1].strip()


PRESETS_PATH = Path(__file__).resolve().parent.parent / "config" / "presets.json"
PITCH_WORDS = re.compile(r"high note|belt|falsetto|\b[A-G][3-7]\b|target|key change|더 높게", re.I)   # 가사 줄 괄호에 들어가면 안 되는 고음·창법 지시
OPEN_VOWELS = (0, 2, 4, 6, 8, 9)   # ㅏ ㅑ ㅓ ㅕ ㅗ ㅘ


def load_preset(pid: str) -> dict:
    import json
    d = json.loads(PRESETS_PATH.read_text(encoding="utf-8"))
    if pid not in d or pid.startswith("_"):
        sys.exit(f"알 수 없는 프리셋: {pid}")
    return d[pid]


def ends_open(line: str) -> bool:
    hangul = [c for c in re.sub(r"\([^)]*\)", "", line) if "가" <= c <= "힣"]
    if not hangul:
        return False
    o = ord(hangul[-1]) - 0xAC00
    return o % 28 == 0 and (o % 588) // 28 in OPEN_VOWELS


def lint_style_preset(style: str, preset: dict) -> None:
    n = len(style)
    add("실패" if n > 1000 else "통과", f"스타일 길이 {n}자", "프리셋 스타일은 1000자 이내(원문 995자)")
    verb, comp = preset["style_verbatim"], preset["style_compact"]
    same = style.strip() == verb.strip() or re.sub(r"\d+ BPM", "{bpm} BPM", style.strip()) == comp.strip()
    add("통과" if same else "주의", "프리셋 스타일 원문과 일치" if same else "프리셋 스타일 원문과 다름",
        "" if same else "사용자가 준 원문(verbatim) 또는 compact 변형을 그대로 쓴다")
    add("통과" if not re.search(r"[\[\]]", style) else "실패", "스타일에 섹션 태그([ ]) 없음")


def lint_hiphop(sections: list[tuple[str, list[str]]], body: list[str], hook: str | None) -> None:
    """힙합 스타일1 규칙(사용자 지적 2026-10-18: 훅이 약했고 고음이 없었고 영어는 좋았다)."""
    names = [n.lower() for n, _ in sections]
    sung = [l for l in body if syl(l) > 0 or LATIN.search(l)]
    # 구조
    add("통과" if sum(1 for n in names if n.startswith("verse")) >= 2 else "주의", "벌스 2개 이상")
    add("통과" if sum(1 for n in names if n.startswith("pre-chorus")) >= 2 else "주의", "프리코러스 2개(상승 구간)")
    br = [n for n in names if n.startswith("bridge")]
    add("통과" if br and re.search(r"whisper|falsetto|quiet|stripped", br[0]) else "주의", "브릿지: 조용한 가성(quiet falsetto whisper) 지시")
    fin = [n for n in names if n.startswith("final chorus")]
    add("통과" if fin and re.search(r"belt|falsetto|climax|high", fin[0]) else "주의", "파이널 코러스 태그에 고음 클라이맥스 지시")
    add("통과" if 9 <= len(sections) <= 12 else "주의", f"섹션 {len(sections)}개", "Intro~Outro 10개 안팎(3분 30초)")
    # 랩 벌스 줄 길이
    vl = [syl(l) for n, ls in sections if n.lower().startswith("verse") for l in ls if syl(l) > 0]
    if vl:
        avg = sum(vl) / len(vl)
        add("통과" if 10 <= avg <= 16.5 else "주의", f"랩 벌스 평균 {avg:.1f}음절/줄", "12~16음절 권장(대화체 랩)")
        add("통과" if len(vl) >= 12 else "주의", f"랩 벌스 줄 수 {len(vl)}줄", "벌스 2개 × 8줄 권장")
    # 영어 혼합 (사용자: 중간중간 알맞게 들어간 영어가 좋았다)
    paren = re.findall(r"\(([^)]*)\)", "\n".join(body))
    adlib = [x for x in paren if LATIN.search(x)]
    add("통과" if len(adlib) >= 4 else "주의", f"영어 애드립 괄호 {len(adlib)}개", "4~10개 권장: (yeah) (okay) (breathe) (let it go) (my way)")
    add("통과" if len(adlib) <= 14 else "주의", "영어 애드립이 과하지 않음", "14개 이하")
    en_lines = [l for l in body if LATIN.search(re.sub(r"\([^)]*\)", "", l))]
    en_only = [l for l in en_lines if not HANGUL.search(re.sub(r"\([^)]*\)", "", l))]
    share = len(en_lines) / max(1, len(sung))
    add("통과" if 0.12 <= share <= 0.40 else "주의", f"영어가 들어간 줄 {len(en_lines)}/{len(sung)} ({share:.0%})", "20~30% 권장(12~40% 허용)")
    add("통과" if len(en_only) <= 6 else "주의", f"영어 단독 줄 {len(en_only)}줄", "6줄 이하")
    longen = [l for l in en_lines if len(re.findall(r"[A-Za-z]+", re.sub(r"\([^)]*\)", "", l))) > 5]
    add("통과" if not longen else "주의", "영어 구절이 길지 않음(한 줄 5단어 이하)", "; ".join(longen[:2]))
    # 고음 지시를 가사 줄(괄호·본문)에 넣지 않았는지
    bad = [x for x in paren if PITCH_WORDS.search(x)]
    bad_lines = [l for l in body if re.search(r"high note|belt |C5|D5|E5|F5|G5", l, re.I)]
    add("통과" if not bad and not bad_lines else "실패", "가사 줄에 고음·창법 지시 없음(섹션 태그에만)",
        "; ".join((bad + bad_lines)[:3]) + " — 괄호는 노래로 불린다(참고곡 내 뜻대로·너를 믿어봐가 이렇게 써서 고음이 안 나왔다)")
    # 훅
    chor = [(n, ls) for n, ls in sections if n.lower().startswith("chorus")]
    norm = lambda s: re.sub(r"\([^)]*\)|\s+", "", s)
    if chor and chor[0][1]:
        hk = chor[0][1][0]
        hs = syl(hk)
        add("통과" if 4 <= hs <= 8 else "주의", f"훅(코러스 첫 줄) 한글 {hs}음절", hk)
        add("통과" if LATIN.search(re.sub(r"\([^)]*\)", "", hk)) else "주의", "훅에 쉬운 영어 1~2단어", "예: Stay with me, 아직 여기 있어")
        add("통과" if ends_open(hk) else "주의", "훅 끝 음절이 열린 모음(받침 없음)")
        multi = [n for n, ls in chor if sum(1 for l in ls if norm(l) == norm(hk)) >= 2]
        add("통과" if len(multi) == len(chor) else "주의", "모든 코러스에서 훅이 2번 이상(첫 줄·셋째 줄)", f"{len(multi)}/{len(chor)}")
        # 같은 어절을 연속 세 번(살 거야, 살 거야, 살 거야) 외치는 반복 금지
        trip = [l for l in body if re.search(r"(\S+(?: \S+)?),? \1,? \1", l)]
        add("통과" if not trip else "주의", "같은 어절을 세 번 외치는 반복 없음", "; ".join(trip[:2]))
        # 정점 줄
        peaks = [(n, ls[-1] if ls else "") for n, ls in chor]
        fl = [ls for n, ls in sections if n.lower().startswith("final chorus")]
        if fl and fl[0]:
            peaks.append(("Final Chorus", fl[0][-1]))
        bad_peak = [f"{n}: {l[:16]}" for n, l in peaks if not (syl(l) <= 10 and ends_open(l))]
        add("통과" if not bad_peak else "주의", "코러스 마지막 줄이 정점 줄(10음절 이하, 열린 모음으로 끝)", "; ".join(bad_peak[:3]))
        total = sum(1 for _, ls in sections for l in ls if norm(l) == norm(hk))
        add("통과" if total >= 6 else "주의", f"훅 반복 합계 {total}회", "6회 이상")
        add("통과" if all(len(ls) <= 6 for n, ls in chor) else "주의", "코러스는 4줄 안팎(길면 훅이 희석된다)")
    for n, ls in chor:
        if not re.search(r"high|falsetto|belt|soar", n, re.I):
            add("실패", f"[{n}] 코러스 태그에 고음 지시 없음", "soaring high singing C5-D5, falsetto and belt blend 를 태그에")


def lint_style(style: str, gender: str | None = None) -> None:
    n = len(style)
    add("실패" if n > 1000 else ("통과" if n <= 300 else "주의"), f"스타일 길이 {n}자",
        "300자 이내 권장(보컬 묘사를 앞에 길게 쓰므로 200자에서 완화). 1000자 초과는 입력이 잘린다. 항목이 많으면 서로 부딪힌다")
    parts = [p.strip() for p in style.split(",") if p.strip()]
    add("통과" if 4 <= len(parts) <= 9 else "주의", f"스타일 항목 {len(parts)}개", "4~7개가 가장 안정적(너무 적으면 기본값이 채워지고, 많으면 충돌)")
    add("통과" if re.search(r"korean", style, re.I) else "실패", "Korean 보컬 명시")
    m = re.search(r"female|male|vocal|voice|singer|tenor|baritone|alto|soprano|mezzo", style, re.I)
    if not m:
        add("주의", "보컬 묘사(성별·음역·질감)가 없음")
    else:
        pos = m.start() / max(1, len(style))
        add("통과" if pos <= 0.45 else "주의", "보컬 묘사가 스타일 앞쪽에 있음",
            f"위치 {int(pos * 100)}%. 보컬 묘사는 앞쪽에 둘수록 반영이 잘 된다(제3자 가이드)")
    if gender:
        has_f = bool(re.search(r"\bfemale\b", style, re.I))
        has_m = bool(re.search(r"\bmale\b", style, re.I))
        if gender == "duet":
            add("통과" if has_f and has_m and re.search(r"\bduet\b", style, re.I) else "실패",
                "듀엣: 스타일에 male·female·duet 모두 있음", "듀엣은 두 성별 단어와 duet 가 함께 있어야 한다")
        else:
            ok = has_f and not has_m if gender == "female" else has_m and not has_f
            add("통과" if ok else "실패", f"스타일의 성별 단어가 요청({gender})과 일치",
                "female/male이 함께 있거나 반대면 Suno가 섞는다")
    add("통과" if re.search(r"\d+\s*bpm", style, re.I) else "주의", "BPM 명시")
    add("통과" if re.search(r"clean|wide|polished|separation|stereo|mix|master|lush|spacious|balanced", style, re.I) else "주의",
        "믹스·음질 용어(clean mix / wide stereo / instrument separation 등)", "믹스 용어를 넣으면 뭉침이 줄어드는 경향(제3자 가이드)")
    add("통과" if not re.search(r"[\[\]]", style) else "실패", "스타일에 섹션 태그 없음")
    add("통과" if not HANGUL.search(style) else "주의", "스타일을 영어로 작성", "가사 문장이 스타일 칸에 섞이면 혼란")


def lint_lyrics(lyrics: str, hook: str | None, high_note: bool = False, gender: str | None = None, preset: str | None = None) -> None:
    lines = [l.rstrip() for l in lyrics.splitlines()]
    sections: list[tuple[str, list[str]]] = []
    cur: tuple[str, list[str]] | None = None
    for l in lines:
        m = SECTION_RE.match(l.strip())
        if m:
            cur = (m.group(1).strip(), [])
            sections.append(cur)
        elif l.strip() and cur is not None:
            cur[1].append(l.strip())
        elif l.strip() and cur is None:
            add("실패", "첫 줄이 섹션 태그가 아님", l.strip()[:30])
    names = [s[0].lower() for s in sections]
    add("통과" if len(sections) >= 8 else "주의", f"섹션 {len(sections)}개", "Intro~Outro 10개 구조 권장")
    unknown = [n for n in names if not any(n.startswith(k) for k in KNOWN)]
    add("통과" if not unknown else "주의", "알 수 없는 섹션 태그", ", ".join(unknown))
    add("통과" if sum(1 for n in names if "chorus" in n) >= 3 else "주의", "코러스 3곳 이상(Chorus×2 + Final Chorus)")

    body = [l for _, ls in sections for l in ls]
    text = "\n".join(body)
    add("통과" if not re.search(r"[\"“”‘’—–]", text) else "실패", "따옴표·줄표 없음", "Suno가 박자를 흘리거나 어색하게 읽음")
    add("통과" if not re.search(r"\d", text) else "실패", "숫자 없음(한글로 풀어 쓰기)", "예: 3시 → 세 시")
    add("통과" if not re.search(r"[\U0001F300-\U0001FAFF☀-➿]", text) else "실패", "이모지 없음")

    # 2026-11-25 찰스님 지시: 반복되는 진부 AI 자취 클리셰(신발장·센서등·식은 밥 등) 원천 차단
    hit_cliches = [lbl for lbl, pat in BANNED_AI_CLICHES if pat.search(text)]
    add("통과" if not hit_cliches else "실패",
        "진부한 AI 자취 클리셰 없음 (2005-2020 명곡 작사 기준)",
        "감지됨: " + ", ".join(hit_cliches) + " — 계절·빛·온도·시선·침묵 등 보편적 감각 이미지로 교체 필수" if hit_cliches else "")

    # 괄호 = 부를 말
    paren = re.findall(r"\(([^)]*)\)", text)
    bad = [p for p in paren if any(w in p for w in DIRECTION_WORDS)]
    add("통과" if not bad else "실패", "괄호에 연출 지시어 없음", "; ".join(bad))
    add("통과", f"애드립 괄호 {len(paren)}개", "괄호 안 글자는 전부 노래로 불린다")

    # 영어 단어: 한국어 줄(괄호 밖)에 라틴 문자
    latin_lines = [l for l in body if LATIN.search(re.sub(r"\([^)]*\)", "", l))]
    if not preset:
        add("통과" if not latin_lines else "주의", "한국어 줄에 영어 단어 없음", "; ".join(latin_lines[:3]))
    else:
        add("통과", f"영어 혼합 허용(프리셋 {preset}): 영어가 든 줄 {len(latin_lines)}개")

    # 음절 수
    counts = [(syl(l), l) for l in body if syl(l) > 0]
    too_long = [(c, l) for c, l in counts if c > 16]
    very_long = [(c, l) for c, l in counts if c > 20]
    add("실패" if very_long else ("주의" if too_long else "통과"), "줄당 음절 16 이하",
        "; ".join(f"{c}음절 {l[:18]}" for c, l in (very_long or too_long)[:3]))
    for name, ls in sections:
        cs = [syl(l) for l in ls if syl(l) > 0]
        if len(cs) >= 3 and max(cs) - min(cs) > 9:
            add("주의", f"[{name}] 줄 길이 편차 큼", f"{min(cs)}~{max(cs)}음절")
    avg = sum(c for c, _ in counts) / max(1, len(counts))
    add("통과", f"평균 {avg:.1f}음절/줄", "")

    # 훅
    if not hook:
        norm = Counter(re.sub(r"\([^)]*\)|\s+", "", l) for l in body)
        top, n = norm.most_common(1)[0]
        hook = next(l for l in body if re.sub(r"\([^)]*\)|\s+", "", l) == top)
        add("통과", f"훅 자동 감지: {hook} (×{n})")
    hk = re.sub(r"\s+", "", hook)
    hs = syl(hook)
    add("통과" if 5 <= hs <= 10 else "주의", f"훅 {hs}음절", "5~10음절 권장")
    hangul = [c for c in hook if "가" <= c <= "힣"]
    if hangul:
        o = ord(hangul[-1]) - 0xAC00
        jung, jong = (o % 588) // 28, o % 28
        open_ok = jong == 0 and jung in (0, 2, 4, 6, 8, 9)   # ㅏ ㅑ ㅓ ㅕ ㅗ ㅘ, 받침 없음
        add("통과" if open_ok else "주의", f"훅 끝 음절 '{hangul[-1]}'" + (" 열린 모음(받침 없음)" if open_ok else " 닫힌 음절"),
            "고음을 길게 끌 마지막 음절은 받침 없는 ㅏ/ㅓ/ㅗ가 유리(작곡 관례. Suno에서의 효과는 미검증)")
    chor = [(n, ls) for n, ls in sections if "chorus" in n.lower() and "pre" not in n.lower()]
    if high_note:
        no_tag = [n for n, _ in chor if not re.search(r"belt|falsetto|soar|high", n, re.I)]
        add("통과" if not no_tag else "주의", "코러스 태그에 고음 지시(belted/falsetto/soaring/high)",
            "없는 섹션: " + ", ".join(no_tag) if no_tag else "")
    if gender == "duet":
        vs = [n for n, _ in sections if re.match(r"(verse|pre-chorus|bridge)", n, re.I)]
        untagged = [n for n in vs if not re.search(r"female|male", n, re.I)]
        add("통과" if not untagged else "실패", "듀엣: 벌스·프리코러스·브릿지에 부르는 사람(female/male) 표기",
            "없는 섹션: " + ", ".join(untagged) if untagged else "")
        kinds = {("female" if re.search(r"\bfemale\b", n, re.I) and not re.search(r"\bmale\b", n, re.I) else
                  "male" if re.search(r"\bmale\b", n, re.I) and not re.search(r"\bfemale\b", n, re.I) else "")
                 for n in vs}
        add("통과" if {"female", "male"} <= kinds else "주의", "듀엣: 여성 파트와 남성 파트가 모두 있음")
        no_duet = [n for n, _ in chor if not re.search(r"duet", n, re.I)]
        add("통과" if not no_duet else "실패", "듀엣: 모든 코러스 태그에 duet 표기", "없는 섹션: " + ", ".join(no_duet) if no_duet else "")
    elif gender in ("male", "female"):
        wrong = [n for n, _ in sections if re.search(r"\bfemale\b" if gender == "male" else r"\bmale\b", n, re.I)]
        add("통과" if not wrong else "실패", "솔로: 섹션 태그에 반대 성별 단어 없음", ", ".join(wrong))
    per = [(n, sum(1 for l in ls if re.sub(r"\([^)]*\)|\s+", "", l) == re.sub(r"\([^)]*\)", "", hk))) for n, ls in chor]
    missing = [n for n, c in per if c == 0]
    add("통과" if not missing else "실패", "모든 코러스에 훅 포함", "누락: " + ", ".join(missing) if missing else "")
    add("통과" if sum(c for _, c in per) >= 5 else "주의", f"코러스 훅 반복 합계 {sum(c for _, c in per)}회", "5회 이상 권장")

    if preset == "hiphop1":
        lint_hiphop(sections, body, hook)

    # 연속 동일 줄
    run = 1
    for a, b in zip(body, body[1:]):
        run = run + 1 if a == b else 1
        if run > 3:
            add("주의", "같은 줄 4회 이상 연속", a[:20])
            break
    add("통과" if len(lyrics) <= 3000 else "실패", f"가사 {len(lyrics)}자", "3000자 이내")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--md")
    ap.add_argument("--style-file")
    ap.add_argument("--lyrics-file")
    ap.add_argument("--hook")
    ap.add_argument("--gender", choices=["male", "female", "duet"], help="스타일·섹션 태그의 성별 표기가 이 값과 일치하는지 검사(duet 은 파트 표기까지)")
    ap.add_argument("--high-note", action="store_true", help="코러스 태그에 고음 지시가 있는지 검사")
    ap.add_argument("--preset", choices=["hiphop1"], help="이름 붙인 스타일 프리셋 규칙(힙합 스타일1): 스타일 1000자, 영어 혼합 허용, 훅·고음·애드립 검사")
    a = ap.parse_args()
    if a.md:
        style, lyrics = parse_md(Path(a.md))
    elif a.style_file and a.lyrics_file:
        style = Path(a.style_file).read_text(encoding="utf-8").strip()
        lyrics = Path(a.lyrics_file).read_text(encoding="utf-8").strip()
    else:
        ap.error("--md 또는 --style-file/--lyrics-file 이 필요합니다")
    if a.preset:
        lint_style_preset(style, load_preset(a.preset))
        if not a.gender:
            a.gender = load_preset(a.preset)["vocal_type"]
        a.high_note = True
    else:
        lint_style(style, a.gender)
    lint_lyrics(lyrics, a.hook, a.high_note, a.gender, a.preset)
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import story_check
        story_check.run(lyrics, a.hook, add)   # 이야기 구조 점검(주의까지만). 의미·진정성은 못 잰다
    except ImportError:
        add("주의", "story_check.py 를 찾지 못해 이야기 구조 점검을 건너뜀")
    fails = warns = 0
    for level, name, detail in results:
        fails += level == "실패"
        warns += level == "주의"
        print(f"[{level}] {name}" + (f" — {detail}" if detail else ""))
    print(f"\n실패 {fails}, 주의 {warns}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
