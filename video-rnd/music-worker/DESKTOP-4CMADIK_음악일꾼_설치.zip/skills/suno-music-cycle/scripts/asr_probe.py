import sys
import wave

import numpy as np
from faster_whisper import WhisperModel

wav_path, model_name = sys.argv[1], sys.argv[2]
with wave.open(wav_path, "rb") as w:
    assert w.getframerate() == 16000 and w.getnchannels() == 1 and w.getsampwidth() == 2
    audio = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0

model = WhisperModel(model_name, device="cpu", compute_type="int8")
segments, info = model.transcribe(audio, language="ko", word_timestamps=True, beam_size=5,
                                  vad_filter=False, condition_on_previous_text=False)
for s in segments:
    words = " ".join(f"{w.word.strip()}[{w.start:.1f}]" for w in (s.words or []))
    print(f"{s.start:7.2f}-{s.end:7.2f} | {s.text.strip()} || {words}", flush=True)
