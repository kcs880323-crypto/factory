#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""곡의 한 지점부터 끝까지 반음 단위로 올린다(전조, key change up). 표준 파이썬 + ffmpeg(rubberband 필터).

  python -u -I key_lift.py --audio 곡.mp4 --at 134.0 --semitones 3 --out 곡_키업.wav [--xfade 0.4]

`--at` 앞은 원본 그대로, 그 뒤는 보컬 포먼트를 유지하며(`formant=preserved`) 피치만 올린다. `--at` 은 에너지가 가장 낮은 곳(후렴 직전 악기만 남은 구간)에 둔다.
이어 붙이는 부분은 `--xfade` 초 교차 페이드. 길이·타이밍은 그대로다(2026-10-18 `천천히 가도 좋아`: 134.0초 +3반음, 길이 193.2초 그대로, 포락선 상관으로 지연 0.00초 확인).
한계: 전조는 반주까지 함께 올라가므로 `진짜로 높은 음을 노래하게` 한 것이 아니라 키가 오른 것이다. 귀로 확인하지 못했고(F0로 +3반음, 가사 인식 유지만 측정) 믹스 전체를 처리하므로 타악·베이스에 약한 인공음이 생길 수 있다.
Suno `Replace Section` 으로 후렴만 다시 만들면 가사를 지키지 않아서(아래 SKILL.md 함정) 이 방법을 썼다.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--audio", required=True)
    ap.add_argument("--at", type=float, required=True, help="전조가 시작되는 초")
    ap.add_argument("--semitones", type=float, default=3.0)
    ap.add_argument("--xfade", type=float, default=0.4)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    ff = shutil.which("ffmpeg") or "ffmpeg"
    ratio = 2 ** (a.semitones / 12)
    head_end = a.at + a.xfade
    graph = (f"[0:a]atrim=0:{head_end:.3f},asetpts=PTS-STARTPTS[a0];"
             f"[0:a]atrim={a.at:.3f},asetpts=PTS-STARTPTS,"
             f"rubberband=pitch={ratio:.6f}:formant=preserved:transients=smooth:detector=soft:pitchq=quality:window=long[a1];"
             f"[a0][a1]acrossfade=d={a.xfade}:c1=tri:c2=tri[a]")
    cmd = [ff, "-v", "error", "-y", "-i", str(Path(a.audio).resolve()), "-vn", "-filter_complex", graph, "-map", "[a]", "-c:a", "pcm_s16le", str(Path(a.out).resolve())]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        sys.exit("ffmpeg 실패(rubberband 필터가 있는 ffmpeg 가 필요하다):\n" + r.stderr[-1500:])
    print(f"완료: {a.out}  ({a.semitones:+g}반음, {a.at:.1f}초부터)")


if __name__ == "__main__":
    main()
