#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genspark API(`gsk task create super_agent`)로 일반 곡 가사를 받는다 — 웹 화면을 조작하지 않는 빠른 길 (표준 라이브러리만).

  python -u -I scripts/genspark_lyrics.py --concept publish/날짜_concept.json --out publish/날짜_genspark_lyrics.md
  python -u -I scripts/genspark_lyrics.py --from-project <project_id> --out ...    # 이미 받은 작업의 답만 다시 읽기(제출·크레딧 없음)

하는 일: 0단계 concept → `build_lyrics_request.build`와 같은 요청문(+ 출력 형식 한 줄) → 스킬 원본
`genspark-skill/suno-lyrics-writer/SKILL.md` 본문을 instructions로 → 제출 → 끝날 때까지 `task status --follow`
→ `task status <project_id>`의 `result_content`에서 답 → 형식 확인 → `--out`(첫 코드 블록 = 스타일, 둘째 = 가사 —
`lint_lyrics.py --md`에 그대로) + `.answer.txt`(원문) + `.task.json`(실행 기록).
성공하면 마지막에 `GENSPARK_LYRICS: ok project=<id> …` 한 줄을 낸다(자비스 음악 일꾼 점검이 이 줄로 API 사용을 확인).

**같은 --out으로 다시 돌려도 새로 제출하지 않는다** — 제출 직후 `.task.json`에 run_id·project_id를 먼저 적고, 다음
실행은 그 작업을 이어서 확인한다(`gsk task create`는 부를 때마다 새로 과금된다). 제출 결과를 모르는 기록(제출 중 끊김)이면
다시 제출하지 않고 멈춘다(종료 코드 5) — 그때는 웹 화면 방식으로 넘어간다.

2026-11-20 시험(1편): 제출→답 약 51초, 0 크레딧(Super Agent 프로모션 100% — 웹 화면 방식과 같은 과금 종류, 프로모션이 늘 붙는 것은 아님),
점검기 실패 0·주의 0. 키 값은 다루지 않는다(gsk가 자기 설정 파일에 보관).

종료 코드: 0 성공 / 2 입력 오류 / 3 gsk 없음·로그인 안 됨 / 4 크레딧 부족 / 5 시간 초과·작업 실패·답 없음 / 6 답이 출력 형식을 벗어남
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))          # -I(격리 모드)는 스크립트 폴더를 경로에 넣지 않는다
import build_lyrics_request as blr  # noqa: E402

SKILL_MD = HERE.parent / "genspark-skill" / "suno-lyrics-writer" / "SKILL.md"
MARK = "GENSPARK_LYRICS:"
QUERY_TAIL = "\n\n위 요구로 노래 가사를 써 주세요. '8. 출력 형식' 그대로 채팅 답 하나로만 출력해 주세요(파일·문서 없이)."
TASK_RULES = ("\n\n## 이 작업에서 지킬 것\n"
              "- 답은 채팅 본문 하나로만 쓴다. 문서·슬라이드·파일·이미지를 만들지 않는다.\n"
              "- 웹 검색·자료 조사를 하지 않는다(필요 없는 작업이다). 되묻지 않는다.\n"
              "- '8. 출력 형식' 그대로, 다른 말 없이 출력한다.")
DONE_STATES = {"succeeded", "success", "completed", "complete", "finished", "done"}
FAIL_STATES = {"failed", "failure", "error", "errored", "cancelled", "canceled", "stopped", "aborted", "timed_out", "timeout", "expired"}
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
LOGIN_RE = re.compile(r"log ?in|api[ _-]?key|unauthori|401|credential|not authenticated", re.I)
CREDIT_RE = re.compile(r"credit|insufficient|quota|balance|402|payment|upgrade", re.I)


class Stop(Exception):
    def __init__(self, code: int, msg: str):
        super().__init__(msg)
        self.code = code


# ── gsk 실행 ──────────────────────────────────────────────────────────────
def find_gsk() -> list[str] | None:
    """JARVIS_GSK(.py면 이 파이썬으로 — 시험용 가짜) > Genspark 앱 안의 CLI > npm 전역 설치 > PATH의 gsk.
    git bash에서 gsk 셸 껍데기를 부르면 멈춘 적이 있어 node + index.js를 직접 부른다(자비스 genspark.py와 같은 순서)."""
    explicit = os.environ.get("JARVIS_GSK", "").strip().strip('"')
    node = shutil.which("node") or r"C:\Program Files\nodejs\node.exe"
    node = node if Path(node).is_file() else None
    if explicit and Path(explicit).is_file():
        if explicit.lower().endswith(".py"):
            return [sys.executable, explicit]
        return [node, explicit] if explicit.lower().endswith(".js") and node else [explicit]
    local, appdata = os.environ.get("LOCALAPPDATA", ""), os.environ.get("APPDATA", "")
    for c in (Path(local) / "Programs" / "gensparkaio" / "resources" / "gsk-cli" / "vendor" / "node_modules" / "@genspark" / "cli" / "dist" / "index.js",
              Path(appdata) / "npm" / "node_modules" / "@genspark" / "cli" / "dist" / "index.js"):
        if node and c.is_file():
            return [node, str(c)]
    which = shutil.which("gsk") or shutil.which("gsk.cmd")
    return [which] if which else None


def _last_json(text: str):
    for line in reversed((text or "").strip().splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                return json.loads(line)
            except ValueError:
                continue
    try:
        return json.loads(text[text.index("{"):])
    except (ValueError, AttributeError):
        return None


def _short(text: str, n: int = 200) -> str:
    """오류 글을 짧게 — 키처럼 보이는 긴 글자 덩어리는 가린다."""
    return re.sub(r"[A-Za-z0-9_\-]{40,}", "…", " ".join((text or "").split()))[:n]


def gsk(args: list[str], timeout: float = 120) -> dict:
    """gsk 한 번 → JSON 봉투. 실패하면 Stop(3 로그인 / 4 크레딧 / 5 그 밖)."""
    cmd = find_gsk()
    if not cmd:
        raise Stop(3, "Genspark 명령줄 도구(gsk)를 찾지 못했어요.")
    env = dict(os.environ, GSK_NO_AUTO_UPDATE="1", PYTHONUTF8="1")
    try:
        done = subprocess.run([*cmd, "--no-input", *args], capture_output=True, text=True, encoding="utf-8", errors="replace",
                              timeout=timeout, stdin=subprocess.DEVNULL, env=env, creationflags=NO_WINDOW)
    except subprocess.TimeoutExpired as exc:
        raise Stop(5, f"gsk {args[0]} {args[1] if len(args) > 1 else ''}이(가) {int(timeout)}초 안에 응답하지 않았어요.") from exc
    except OSError as exc:
        raise Stop(3, f"gsk를 실행하지 못했어요: {exc}") from exc
    env_json = _last_json(done.stdout)
    tail = _short(" ".join((done.stderr or "").strip().splitlines()[-3:]))
    # `--follow`가 기다림 시간을 다 쓰고 아직 진행 중이면 종료 코드가 0이 아닐 수 있다 — 봉투가 정상(data 있음)이면 받아들인다
    if env_json is None or env_json.get("status") == "error" or (done.returncode != 0 and not env_json.get("data")):
        msg = str((env_json or {}).get("message") or tail or f"종료 코드 {done.returncode}")
        if LOGIN_RE.search(msg) or LOGIN_RE.search(tail):
            raise Stop(3, f"Genspark 로그인이 안 돼 있어요({_short(msg, 120)}).")
        if CREDIT_RE.search(msg):
            raise Stop(4, f"Genspark 크레딧이 부족해요({_short(msg, 120)}).")
        raise Stop(5, f"gsk 오류: {_short(msg)}")
    return env_json


def balance() -> float | None:
    data = gsk(["me"], 60).get("data") or {}
    try:
        return round(float(data.get("credit_balance")), 2)
    except (TypeError, ValueError):
        return None


# ── 요청 만들기 ────────────────────────────────────────────────────────────
def skill_body(path: Path = SKILL_MD) -> str:
    text = path.read_text(encoding="utf-8")
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            text = text[end + 4:]
    return text.strip()


def build_args(concept: dict, fix_hook: str | None = None, titles: list[str] | None = None) -> dict:
    if titles is None:
        state = blr.HOME / "voice_state.json"
        titles = [h["title"] for h in json.loads(state.read_text(encoding="utf-8"))["history"]] if state.exists() else []
    query = blr.build(concept, titles, slash=False, fix_hook=fix_hook) + QUERY_TAIL
    name = f"suno-lyrics {datetime.now():%m-%d} {concept.get('theme', '')}".strip()[:60]
    return {"query": query, "instructions": skill_body() + TASK_RULES, "task_name": name}


# ── 답 읽기 ────────────────────────────────────────────────────────────────
def _field(text: str, name: str) -> str:
    m = re.search(rf"^\s*\**{re.escape(name)}\**\s*[:：]\s*(.+?)\s*$", text, flags=re.M)
    return m.group(1).strip().strip("*`").strip() if m else ""


def parse_answer(text: str) -> dict:
    """스킬 '8. 출력 형식'(설계 줄들 / 제목 / 훅 / 스타일 / 스타일 제외 / 가사 코드 블록)을 읽는다."""
    blocks = re.findall(r"```[^\n]*\n(.*?)```", text or "", flags=re.S)
    lyrics = next((b.strip() for b in blocks if re.search(r"\[\s*(Final\s+)?Chorus", b, re.I)), "")
    title, hook = _field(text, "제목"), re.sub(r"\s*\((\d+\s*음절|[^)]*음절)\)\s*$", "", _field(text, "훅"))
    style, exclude = _field(text, "스타일"), _field(text, "스타일 제외")
    head = (text or "").split("```")[0]
    design = head.split("제목")[0].strip() if "제목" in head else ""
    return {"design": design, "title": title, "hook": hook, "style": style, "exclude": exclude, "lyrics": lyrics}


def format_problems(p: dict) -> list[str]:
    out = []
    for key, ko in (("title", "제목"), ("hook", "훅"), ("style", "스타일")):
        if not p.get(key):
            out.append(f"{ko} 줄 없음")
    if not p.get("lyrics"):
        out.append("가사 코드 블록 없음")
    else:
        if not re.search(r"\[\s*Final\s+Chorus", p["lyrics"], re.I):
            out.append("[Final Chorus] 없음")
        if len(re.findall(r"^\s*\[[^\]]+\]", p["lyrics"], flags=re.M)) < 6:
            out.append("섹션 태그가 6개 미만")
    if p.get("style") and re.search(r"[가-힣]", p["style"]):
        out.append("스타일에 한국어가 섞임")
    return out


def pick_answer(result: dict, query: str = "") -> str:
    content = result.get("content") if isinstance(result, dict) else None
    items = [c for c in (content if isinstance(content, list) else [content]) if isinstance(c, str) and c.strip()]
    q = (query or "").strip()[:80]
    for c in reversed(items):
        if "```" in c and not (q and c.strip().startswith(q)):
            return c
    return ""


def to_markdown(p: dict, project: str, task_url: str) -> str:
    return (f"# {p['title']} — 가사: Genspark(API)\n\n"
            f"- 훅: {p['hook']}\n- 스타일 제외: {p['exclude'] or '(없음)'}\n"
            f"- 가사: Genspark(API, gsk task super_agent · project {project} · {datetime.now():%Y-%m-%d %H:%M})\n"
            f"- 작업 페이지(주인만 열림): {task_url}\n\n"
            f"## 설계\n{p['design'] or '(없음)'}\n\n## 스타일\n```\n{p['style']}\n```\n\n## 가사\n```\n{p['lyrics']}\n```\n")


# ── 실행 ──────────────────────────────────────────────────────────────────
def save(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")


def follow(run_id: str, deadline: float, gap: float) -> dict:
    """끝날 때까지 run 상태를 본다. 끝나면 마지막 data, 실패·시간 초과면 Stop(5)."""
    errors = 0
    while True:
        left = deadline - time.time()
        try:      # 기한이 지났어도 상태는 먼저 한 번 본다(이미 끝났을 수 있다)
            data = gsk(["task", "status", run_id, "--follow", "--wait-seconds", str(max(1, min(45, int(left))))], 90).get("data") or {}
            errors = 0
        except Stop as exc:
            if exc.code != 5:
                raise
            errors += 1
            if errors >= 3:
                raise
            data = {}
        state = str(data.get("state") or data.get("run_status") or "").lower()
        if state in DONE_STATES:
            return data
        if state in FAIL_STATES:
            raise Stop(5, f"Genspark 작업이 '{state}'로 끝났어요. {_short(str(data.get('state_note') or ''), 120)}")
        if deadline - time.time() <= 0:
            try:
                gsk(["task", "stop", run_id], 60)     # 시간을 넘긴 작업은 멈춰 더 쓰지 않게(멈출 게 없어도 안전)
            except Stop:
                pass
            raise Stop(5, "Genspark가 정한 시간 안에 가사를 끝내지 못했어요(작업을 멈춤).")
        time.sleep(min(gap or 0, max(0, deadline - time.time())))


def fetch(project: str, query: str = "") -> tuple[str, str]:
    """(답 원문, task_url). status(가벼움) → info 순서로 result_content를 본다."""
    url = ""
    for args in (["task", "status", project], ["task", "info", project, "-n", "10"]):
        data = gsk(args, 90).get("data") or {}
        url = data.get("task_url") or url
        res = data.get("result_content") or {}
        ans = pick_answer(res, query)
        if ans:
            return ans, url
    return "", url


def run(a) -> int:
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    task_file, args_file, answer_file = (out.with_name(out.stem + s) for s in (".task.json", ".args.json", ".answer.txt"))
    rec = json.loads(task_file.read_text(encoding="utf-8")) if task_file.exists() else {}
    query = ""
    if a.from_project:
        project, rec = a.from_project, {"project_id": a.from_project, "from_project": True}
        print(f"이미 받은 작업 {project}의 답만 읽어요(새로 제출하지 않음).")
    else:
        if not a.concept:
            raise Stop(2, "--concept 또는 --from-project가 필요해요.")
        concept = json.loads(Path(a.concept).read_text(encoding="utf-8"))
        args = build_args(concept, a.fix_hook)
        query = args["query"]
        sig = hashlib.sha256(json.dumps(args, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()[:16]
        if rec.get("run_id") or rec.get("project_id"):
            print(f"이미 제출한 작업(project {rec.get('project_id') or '?'})을 이어서 확인해요 — 새로 제출하지 않아요.")
            if rec.get("sig") and rec["sig"] != sig:
                print("주의: 지난번과 요청 내용이 다르지만 새 제출(크레딧)을 피하려고 지난 작업 결과를 씁니다. 새 요청이 필요하면 --out을 바꾸세요.")
        elif rec:
            raise Stop(5, f"지난 제출 결과를 알 수 없는 기록이 있어요({task_file.name}) — 중복 과금을 피하려고 다시 제출하지 않아요. 웹 화면 방식으로 넘어가세요.")
        else:
            rec = {"concept": str(a.concept), "sig": sig, "state": "submitting", "started": datetime.now().isoformat(timespec="seconds")}
            rec["balance_before"] = balance()                      # 로그인 확인 겸(실패하면 Stop 3)
            args_file.write_text(json.dumps(args, ensure_ascii=False, indent=1), encoding="utf-8")
            save(task_file, rec)                                    # 제출 전에 먼저 적는다 — 끊겨도 다시 제출하지 않게
            t0 = time.time()
            created = gsk(["task", "create", "super_agent", "--args-file", str(args_file)], 120).get("data") or {}
            rec.update(state="submitted", run_id=created.get("run_id") or "", project_id=created.get("project_id") or "",
                       task_url=created.get("task_url") or "", t0=t0)
            save(task_file, rec)
            if not rec["run_id"] and not rec["project_id"]:
                raise Stop(5, "제출 응답에 작업 번호가 없어요.")
            print(f"제출했어요 — project {rec['project_id'] or '?'} (작업 페이지는 주인만 열림)")
        # 이번 실행에서 제출했으면 제출 시각부터, 이어서 확인하는 실행이면 지금부터 기한을 잰다
        deadline = (rec["t0"] if rec.get("state") == "submitted" and time.time() - float(rec.get("t0") or 0) < a.timeout else time.time()) + a.timeout
        if rec.get("state") != "finished" and rec.get("run_id"):
            data = follow(rec["run_id"], deadline, a.poll_gap)
            rec["project_id"] = rec.get("project_id") or data.get("project_id") or ""
            rec["task_url"] = rec.get("task_url") or data.get("task_url") or ""
            rec.update(state="finished", finished=datetime.now().isoformat(timespec="seconds"))
            if rec.get("t0"):
                rec["seconds"] = round(time.time() - float(rec["t0"]), 1)
            save(task_file, rec)
        project = rec.get("project_id") or ""
        if not project:
            raise Stop(5, "작업 번호(project_id)를 받지 못했어요.")
    answer, url = fetch(project, query)
    rec["task_url"] = rec.get("task_url") or url
    if not answer:
        if not a.from_project:
            save(task_file, rec)
        raise Stop(5, "Genspark 답에 가사가 없어요(에이전트가 질문으로 끝났을 수 있음).")
    answer_file.write_text(answer, encoding="utf-8")
    p = parse_answer(answer)
    problems = format_problems(p)
    if problems:
        rec["format_problems"] = problems
        if not a.from_project:
            save(task_file, rec)
        raise Stop(6, f"Genspark 답이 출력 형식을 벗어났어요: {', '.join(problems)} (원문 {answer_file.name})")
    out.write_text(to_markdown(p, project, rec.get("task_url") or url), encoding="utf-8")
    after = None
    if not a.from_project:
        try:
            after = balance()
        except Stop:
            after = None
        rec.update(balance_after=after, title=p["title"], hook=p["hook"], out=str(out))
        save(task_file, rec)
    before = rec.get("balance_before")
    credit = (f"크레딧 잔액 {before} → {after}(늦게 반영될 수 있음 — 정확한 차감은 `gsk account credit usage`)"
              if before is not None and after is not None else "크레딧: 확인 안 함")
    print(f"제목: {p['title']} / 훅: {p['hook']}")
    print(f"저장: {out} (원문 {answer_file.name}, 기록 {task_file.name})")
    print(credit)
    secs = rec.get("seconds")
    print(f"{MARK} ok project={project} seconds={secs if secs is not None else '-'} title={p['title']} hook={p['hook']}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="Genspark API로 일반 곡 가사 받기")
    ap.add_argument("--concept", help="0단계 pick_concept.py draw 결과 JSON")
    ap.add_argument("--out", required=True, help="결과 md(작업 폴더 publish 안). 같은 이름의 .task.json·.args.json·.answer.txt도 함께")
    ap.add_argument("--fix-hook", help="제목과 훅을 이 문장으로 고정(재작업할 때)")
    ap.add_argument("--timeout", type=float, default=360, help="제출부터 답까지 기다리는 최대 초(기본 360)")
    ap.add_argument("--poll-gap", type=float, default=3, help="상태 확인 사이 쉬는 초")
    ap.add_argument("--from-project", help="이미 받은 작업(project_id)의 답만 다시 읽기 — 제출 없음")
    a = ap.parse_args()
    try:
        return run(a)
    except Stop as exc:
        print(f"{MARK} fail code={exc.code} — {exc}")
        print("→ 스킬 1단계: 웹 화면 방식(genspark.ai/skills의 suno-lyrics-writer)으로 넘어가고, 그것도 안 되면 Claude가 같은 규칙으로 쓴다.")
        return exc.code
    except (OSError, ValueError, KeyError) as exc:
        print(f"{MARK} fail code=2 — 입력을 읽지 못했어요: {exc}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
