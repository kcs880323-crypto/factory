#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""랜덤 컨셉 추첨기 (표준 라이브러리만). '오늘의 노래 만들어줘' 한마디에 아래를 전부 알아서 정한다.

  장르(R&B 4종 포함 16종) · 보컬 타입(여성/남성/듀엣) · 보이스 · 주제 · BPM · 무드 · 고음 훅 방식

  python pick_concept.py draw [--genre ID] [--vocal female|male|duet] [--seed N] [--json out.json]
      컨셉 한 건을 추첨해 JSON 으로 출력한다(이력은 건드리지 않는다).
  python pick_concept.py commit --title 제목 --concept 컨셉.json
      생성이 끝난 곡을 이력에 기록한다. 다음 추첨이 이 이력을 피한다.
  python pick_concept.py draw --preset hiphop1 [--theme ID] [--compact] [--json out.json]
      '힙합 스타일1로 만들어줘' 같은 이름 붙인 프리셋(config/presets.json, 문서 config/saved_styles/hiphop_style1.md)
  python pick_concept.py history | list
  python pick_concept.py sim [--n 200] [--seed 1]
      이력을 건드리지 않고 연속 추첨해서 규칙(장르·계열 비중복, 보컬 연속 제한)이 지켜지는지 센다.

규칙 (사용자 지시 2026-10-17: 여성/남성/듀엣 랜덤, 이전과 다른 장르)
  장르: 최근 5곡의 장르와 최근 2곡의 계열(family)은 제외. 후보가 없으면 단계적으로 완화.
        최근 6곡에 안 나온 계열은 가중치 2배(오래 안 나온 계열 우선).
  보컬: 여 3 : 남 3 : 듀엣 2 가중. 직전 타입은 ×0.4. 같은 타입 3연속 금지, 듀엣은 연속 금지.
  보이스: voices.json 에서 장르 키워드가 맞는 쪽 가중. 최근 3곡에 쓴 보이스는 제외(듀엣은 두 명 모두).
이력 파일은 pick_voice.py 와 공유한다($SUNO_CYCLE_HOME/voice_state.json).
"""
from __future__ import annotations

import argparse
import json
import random
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pick_voice as pv  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
CONCEPTS = Path(__file__).resolve().parent.parent / "config" / "concepts.json"
PRESETS = Path(__file__).resolve().parent.parent / "config" / "presets.json"
TYPES = ["female", "male", "duet"]
BASE_W = {"female": 3.0, "male": 3.0, "duet": 2.0}
STYLE_LIMIT = 300

HOOK_MODE = {
    "belt": ("belted high note", "후렴 훅의 마지막 음절을 가슴소리로 지르는 고음(벨팅)으로 끌어올린다"),
    "falsetto": ("falsetto lift", "훅의 가장 높은 음절을 가성으로 올려 부른다"),
    "soar": ("soaring high note", "훅의 정점을 두성으로 높게 뻗어 부른다"),
    "strain": ("strained emotional high note", "훅의 정점을 목이 살짝 갈라질 만큼 힘주어 끌어올린다(너무 매끈하지 않게 — 숨소리와 갈라짐을 살린다)"),
}


def rng(seed):
    return random.Random(seed) if seed is not None else random.SystemRandom()


def wchoice(items, weights, r):
    total = sum(weights)
    x, acc = r.uniform(0, total), 0.0
    for it, w in zip(items, weights):
        acc += w
        if x <= acc:
            return it
    return items[-1]


# ---------- 장르 ----------
def pick_genre(pool: list[dict], hist: list[dict], r, force: str | None = None) -> tuple[dict, str]:
    if force:
        g = next((x for x in pool if x["id"] == force), None)
        if not g:
            sys.exit(f"알 수 없는 장르 id: {force}. `list` 로 확인하세요")
        return g, "강제 지정"
    ids = [h["genre"] for h in hist if h.get("genre")]
    fams = [h["family"] for h in hist if h.get("family")]
    seen6 = set(fams[-6:])
    levels = [
        ("최근 5곡 장르·최근 2곡 계열 제외", lambda g: g["id"] not in ids[-5:] and g["family"] not in fams[-2:]),
        ("최근 3곡 장르·직전 계열 제외(완화)", lambda g: g["id"] not in ids[-3:] and g["family"] not in fams[-1:]),
        ("직전 장르만 제외(최대 완화)", lambda g: g["id"] not in ids[-1:]),
        ("제한 없음", lambda g: True),
    ]
    for label, ok in levels:
        cands = [g for g in pool if ok(g)]
        if cands:
            w = [2.0 if g["family"] not in seen6 else 1.0 for g in cands]
            return wchoice(cands, w, r), label
    raise RuntimeError("장르 풀이 비었습니다")


# ---------- 보컬 타입 ----------
def pick_vocal_type(hist: list[dict], r, force: str | None = None) -> tuple[str, str]:
    if force:
        return force, "강제 지정"
    seq = [h["gender"] for h in hist if h.get("gender") in TYPES]
    w = dict(BASE_W)
    why = "이력 없음, 가중 랜덤(여 3 : 남 3 : 듀엣 2)"
    if seq:
        last = seq[-1]
        run = 0
        for t in reversed(seq):
            if t != last:
                break
            run += 1
        w[last] *= 0.4
        why = f"직전 {last}, 가중 랜덤(직전 타입 ×0.4)"
        if run >= 2:
            w[last] = 0.0
            why = f"{last} {run}곡 연속이라 제외"
        if last == "duet":
            w["duet"] = 0.0
            why = "직전이 듀엣이라 듀엣 제외"
        if "duet" not in seq[-6:] and w["duet"] > 0:
            w["duet"] *= 1.5
            why += ", 최근 6곡에 듀엣이 없어 듀엣 ×1.5"
    return wchoice(TYPES, [w[t] for t in TYPES], r), why


# ---------- 보이스 ----------
def recent_voices(hist: list[dict], n: int = 3) -> list[str]:
    out: list[str] = []
    for h in hist[-n:]:
        out += [v for v in str(h.get("voice", "")).split("+") if v]
    return out


def voice_for(gender: str, kw: str, hist: list[dict], r, exclude: list[str] | None = None) -> dict:
    recent = recent_voices(hist) + (exclude or [])
    return pv.pick_voice(gender, kw, hist, r, recent=recent)


# ---------- 조립 ----------
def build_style(parts: list[str]) -> tuple[str, bool]:
    s = ", ".join(p for p in parts if p)
    return s, len(s) <= STYLE_LIMIT


def favorite_of(cfg: dict) -> tuple[str, float]:
    """찰스님 선호 스타일(config/concepts.json의 favorite) — (장르 id, 비중). 없으면 ("", 0)."""
    fav = cfg.get("favorite") or {}
    gid = str(fav.get("genre") or "")
    try:
        share = max(0.0, min(1.0, float(fav.get("share", 0))))
    except (TypeError, ValueError):
        share = 0.0
    return (gid, share) if any(g["id"] == gid for g in cfg["genres"]) else ("", 0.0)


def palette_voice(entry: dict) -> dict:
    return {"voice": entry["id"], "ko": entry["ko"], "short": entry.get("short", ""), "style_only": entry["style"],
            "hook_tag": entry["hook_tag"], "mix": entry.get("mix"), "suno_params": entry.get("suno_params")}


def theme_families(cfg: dict, text: str) -> set:
    """주제·제목 글에 든 낱말로 주제 계열을 정한다(config/concepts.json의 theme_families). 2026-11-20 찰스님:
    "요즘 가사가 어른이 되는 중 주제가 너무 반복 — 스타일을 참고해 달라는 거였지 매번 어른 주제를 써 달라는 건 아니었어"."""
    fams = cfg.get("theme_families") or {}
    t = str(text or "")
    return {k for k, words in fams.items() if not k.startswith("_") and isinstance(words, list) and any(w in t for w in words)}


def recent_songs(hist: list[dict], n: int) -> list[dict]:
    """최근 n곡 — 같은 제목이 여러 번 적혀 있으면(이어서 하기로 다시 기록됨) 한 곡으로 센다."""
    out, seen = [], set()
    for h in reversed(hist):
        key = h.get("title") or id(h)
        if key in seen:
            continue
        seen.add(key)
        out.append(h)
        if len(out) >= n:
            break
    return out


def pick_theme(cfg: dict, genre: dict, hist: list[dict], r) -> tuple:
    """최근 5곡과 같은 주제는 빼고, 최근 2곡과 같은 계열(자기위로·성장 등) 주제도 뺀다. 다 빠지면 같은 주제만 빼고 고른다."""
    recent = recent_songs(hist, 5)
    used = {h.get("theme") for h in recent}
    near = set()
    for h in recent[:2]:
        near |= theme_families(cfg, f"{h.get('theme', '')} {h.get('title', '')}")
    fresh = [t for t in genre["themes"] if t not in used]
    best = [t for t in fresh if not (theme_families(cfg, t) & near)]
    pool = best or fresh or genre["themes"]
    why = f"최근 두 곡의 주제 계열({', '.join(sorted(near))}) 제외" if near and best else ("최근 5곡 주제 제외" if fresh else "주제 후보가 모자라 반복 허용")
    return r.choice(pool), why


def draw(hist: list[dict], r, force_genre=None, force_vocal=None, force_voice=None, no_favorite: bool = False) -> dict:
    cfg = json.loads(CONCEPTS.read_text(encoding="utf-8"))
    pal = json.loads(pv.PALETTE.read_text(encoding="utf-8"))
    fixed = None
    if force_voice:   # 저장된 보이스를 그대로 쓴다(성별은 보이스를 따른다)
        fixed = next((x for x in pal["voices"] if x["id"] == force_voice), None)
        if not fixed:
            sys.exit(f"알 수 없는 보이스 id: {force_voice}")
        force_vocal = fixed["gender"]
    # 찰스님 선호 스타일(2026-11-18): 장르·여성/듀엣을 지정하지 않았으면 약 3/4은 선호 장르(남성 테너 모던 록 발라드), 나머지는 기존 16종 순환
    fav_id, fav_share = favorite_of(cfg)
    favorite = False
    if not force_genre and not no_favorite and fav_id and force_vocal in (None, "male") and r.random() < fav_share:
        force_genre, favorite = fav_id, True
    pool = cfg["genres"] if force_genre else [g for g in cfg["genres"] if g["id"] != fav_id]
    genre, g_why = pick_genre(pool, hist, r, force_genre)
    if favorite:
        g_why = f"찰스님 선호 스타일(일반 노래의 약 {round(fav_share * 100)}%)"
    if genre.get("vocal") and not force_vocal:
        force_vocal = genre["vocal"]
    vtype, v_why = pick_vocal_type(hist, r, force_vocal)
    if genre.get("vocal") and not fixed:
        v_why = f"이 장르는 {genre['vocal']} 보컬 고정"
    if fixed:
        v_why = f"보이스 {force_voice} 고정({fixed['ko']})"
    kw = " ".join(genre["keywords"]).lower()
    theme, theme_why = pick_theme(cfg, genre, hist, r)
    mood = r.choice(genre["mood"])
    lo, hi = genre["bpm"]
    bpm = r.randint(lo, hi)
    hook_en, hook_ko = HOOK_MODE[genre["hook"]]
    cues = pal["common_human_cues"]
    mix = cfg["mix"]

    if vtype in ("female", "male"):
        pool_w = {k: float(w) for k, w in (genre.get("voice_pool") or {}).items()}
        pool_v = [x for x in pal["voices"] if x["id"] in pool_w and x["gender"] == vtype]
        if fixed:
            v = palette_voice(fixed)
        elif pool_v:      # 장르가 정한 목소리 묶음(선호 스타일: 맑은 인디 테너 M6 위주) — 최근 3곡 보이스 제외 규칙을 쓰지 않는다
            v = palette_voice(wchoice(pool_v, [pool_w[x["id"]] for x in pool_v], r))
        else:
            v = voice_for(vtype, kw, hist, r)
        if v.get("mix"):
            mix = v["mix"]
        voices = [{"id": v["voice"], "gender": vtype, "ko": v["ko"], "short": v["short"], "hook_tag": v["hook_tag"]}]
        vocal_part = v["style_only"]
        chorus = genre.get("chorus_tag") or f"[Chorus: {v['hook_tag']}, full arrangement]"
        final = genre.get("final_chorus_tag") or f"[Final Chorus: {v['hook_tag']}, key change up]"
        sections = None
        button = "여성" if vtype == "female" else "남성"
        lead = voices[0]["id"]
        gender_note = f"{vtype} 한 명. 스타일의 성별 단어는 {vtype} 하나만"
        vocal_ko = f"{'여성' if vtype == 'female' else '남성'} 솔로 ({v['ko']})"
    else:
        f = voice_for("female", kw, hist, r)
        m = voice_for("male", kw, hist, r)
        voices = [
            {"id": f["voice"], "gender": "female", "ko": f["ko"], "short": f["short"], "hook_tag": f["hook_tag"]},
            {"id": m["voice"], "gender": "male", "ko": m["ko"], "short": m["short"], "hook_tag": m["hook_tag"]},
        ]
        first, second = (voices[0], voices[1]) if r.random() < 0.5 else (voices[1], voices[0])
        lead = first["id"]
        vocal_part = (f"Korean male and female duet with {first['short']} and {second['short']} "
                      f"trading verses and harmonizing on the hook")
        chorus = f"[Chorus: male and female duet, harmony, {hook_en}, full arrangement]"
        final = f"[Final Chorus: male and female duet, {hook_en}, key change up]"
        a, b = first["gender"], second["gender"]
        sections = [
            f"[Intro: {a} vocal humming]", f"[Verse 1: {a} vocal]", f"[Pre-Chorus: {b} vocal]",
            "[Chorus: male and female duet]", f"[Verse 2: {b} vocal]", f"[Pre-Chorus: {a} vocal]",
            "[Chorus: male and female duet]", f"[Bridge: {a} vocal then {b} vocal trading lines]",
            "[Final Chorus: male and female duet]", "[Outro: male and female duet, fade out]",
        ]
        button = "선택 안 함(남/여 버튼을 모두 해제)"
        gender_note = "남·녀 둘 다. 스타일에 male/female 둘 다 쓴다"
        vocal_ko = f"듀엣 ({first['ko']} + {second['ko']}, {a} 먼저 시작)"

    style_parts = [vocal_part, cues, genre["style"], mood, f"{bpm} BPM", mix]
    style, ok = build_style(style_parts)
    trimmed = False
    if not ok:                       # 300자 초과면 사람다운 연기 묘사를 먼저 뺀다
        style, ok = build_style([vocal_part, genre["style"], mood, f"{bpm} BPM", mix])
        trimmed = True
    exclude = list(dict.fromkeys(genre["exclude"] + pal["common_exclude"]))

    gs = [
        f"장르·무드: {genre['ko']} ({mood}), {bpm} BPM 안팎",
        f"주제: {theme} (20~30대가 공감할 일상 장면으로 구체적으로)",
        f"보컬: {vocal_ko}",
        f"고음 훅: {hook_ko}. 훅 끝 음절은 받침 없는 ㅏ/ㅓ/ㅗ로 끝나게 한다",
    ]
    if genre.get("section_tags") and vtype != "duet":
        gs.append("섹션 태그(연주 지시 포함, 이 순서): " + " ".join(genre["section_tags"]))
    gs += list(genre.get("lyric_rules") or [])
    if vtype == "duet":
        gs.append("듀엣이므로 섹션 태그에 부르는 사람을 적는다: " + " ".join(sections)
                  + " (코러스 태그에는 고음 지시를 덧붙인다). 1절은 한 사람의 시점, 2절은 상대의 시점(주고받는 가사), 후렴은 둘이 함께 같은 훅")
    return {
        "genre": {"id": genre["id"], "ko": genre["ko"], "family": genre["family"], "why": g_why},
        "favorite": favorite,
        "section_tags": genre.get("section_tags") if vtype != "duet" else None,
        "lyric_rules": genre.get("lyric_rules") or [],
        "lyric_rules_short": genre.get("lyric_rules_short") or [],
        "vocal_type": vtype, "vocal_why": v_why,
        "voices": voices, "lead": lead,
        "theme": theme, "theme_why": theme_why, "mood": mood, "bpm": bpm, "hook_mode": genre["hook"],
        "style_draft": style, "style_length": len(style), "style_over_limit": not ok,
        "cues_trimmed": trimmed,
        "style_exclude": ", ".join(exclude[:4]),
        "suno_vocal_button": button, "gender_note": gender_note,
        "chorus_tag": chorus, "final_chorus_tag": final,
        "duet_sections": sections,
        "genspark_requirements": gs,
        "lint_gender_arg": vtype,
        "suno_params": (v.get("suno_params") if vtype in ("female", "male") else None) or {"weirdness": 35, "style_influence": 66, "variety": "보통", "max_mode": True},
    }


def draw_preset(hist: list[dict], r, preset_id: str, force_theme: str | None = None, compact: bool = False) -> dict:
    """이름 붙인 스타일 프리셋(예: hiphop1 = '힙합 스타일1')으로 컨셉을 만든다. 스타일 문구는 사용자 원문 그대로다."""
    presets = json.loads(PRESETS.read_text(encoding="utf-8"))
    p = presets.get(preset_id)
    if not p or preset_id.startswith("_"):
        sys.exit(f"알 수 없는 프리셋: {preset_id}. 있는 것: " + ", ".join(k for k in presets if not k.startswith("_")))
    used = {h.get("theme") for h in hist[-5:]}
    pool = p["themes"]
    if force_theme:
        th = next((x for x in pool if x["id"] == force_theme or x["topic"] == force_theme), None)
        if not th:
            sys.exit(f"알 수 없는 주제: {force_theme}. 있는 것: " + ", ".join(x["id"] for x in pool))
    else:
        th = r.choice([x for x in pool if x["topic"] not in used] or pool)
    lo, hi = p["bpm_range"]
    bpm = r.randint(lo, hi)
    style = p["style_compact"].format(bpm=bpm) if compact else p["style_verbatim"]
    chorus = "[Chorus: soaring high singing C5-D5, falsetto and belt blend, layered doubles, tambourine lift, open resonance]"
    final = "[Final Chorus: key change up, ultimate high belt and falsetto climax, layered doubles, ad-libs]"
    gs = [
        f"프리셋: {p['ko']} (남성 솔로, 랩 벌스 + 고음 후렴, 약 {bpm} BPM 느낌의 트랩 힙합, 밤 도시의 비튼 위로)",
        f"주제: {th['topic']} — 비튼 위로: {th['twist']}",
        *p["lyric_rules"],
    ]
    return {
        "preset": preset_id, "lint_preset": preset_id,
        "genre": {"id": preset_id, "ko": p["ko"], "family": "hiphop", "why": "프리셋 지정"},
        "vocal_type": p["vocal_type"], "vocal_why": f"프리셋 {preset_id} 고정(남성 솔로)",
        "voices": [{"id": "HH1", "gender": p["vocal_type"], "ko": f"{p['ko']} 보컬(랩 + 고음 후렴)", "short": "male rap and high chorus",
                    "hook_tag": "soaring high singing C5-D5, falsetto and belt blend"}],
        "lead": "HH1",
        "theme": th["topic"], "twist": th["twist"], "mood": "night-city comfort", "bpm": bpm, "hook_mode": "soar",
        "style_draft": style, "style_length": len(style), "style_over_limit": len(style) > 1000, "cues_trimmed": False,
        "style_variant": "compact" if compact else "verbatim",
        "style_exclude": p["exclude"],
        "suno_vocal_button": p["suno_vocal_button"], "gender_note": "남성 한 명(랩 + 가성·벨팅 후렴)",
        "chorus_tag": chorus, "final_chorus_tag": final,
        "duet_sections": None,
        "genspark_requirements": gs,
        "lyric_rules": p["lyric_rules"],
        "lint_gender_arg": "male",
        "suno_params": p["suno_params"],
    }


def commit(st: dict, title: str, c: dict) -> None:
    if any(h.get("title") == title for h in st["history"][-10:]):      # 이어서 하기로 같은 곡을 또 기록하지 않는다(2026-11-20 「아직 어른이 되는 중이야」가 두 번 적힘)
        return
    st["history"].append({
        "date": time.strftime("%Y-%m-%d"), "title": title, "gender": c["vocal_type"],
        "voice": "+".join(v["id"] for v in c["voices"]),
        "genre": c["genre"]["id"], "family": c["genre"]["family"], "theme": c["theme"],
    })
    pv.HOME.mkdir(parents=True, exist_ok=True)
    pv.STATE.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")


def simulate(n: int, seed: int) -> None:
    r = random.Random(seed)
    hist: list[dict] = []
    viol = {"같은 장르 연속": 0, "같은 계열 연속": 0, "같은 타입 3연속": 0, "듀엣 연속": 0, "최근 3곡 보이스 재사용": 0}
    fav_n = 0
    from collections import Counter
    gc, tc, fc, vc = Counter(), Counter(), Counter(), Counter()
    for _ in range(n):
        c = draw(hist, r)
        e = {"gender": c["vocal_type"], "voice": "+".join(v["id"] for v in c["voices"]),
             "genre": c["genre"]["id"], "family": c["genre"]["family"], "theme": c["theme"]}
        fav_n += bool(c.get("favorite"))
        if c.get("favorite"):
            hist.append(e)
            gc[e["genre"]] += 1
            tc[e["gender"]] += 1
            fc[e["family"]] += 1
            for v in e["voice"].split("+"):
                vc[v] += 1
            continue
        if hist:
            viol["같은 장르 연속"] += e["genre"] == hist[-1]["genre"]
            viol["같은 계열 연속"] += e["family"] == hist[-1]["family"]
            viol["듀엣 연속"] += e["gender"] == "duet" == hist[-1]["gender"]
        if len(hist) >= 2:
            viol["같은 타입 3연속"] += e["gender"] == hist[-1]["gender"] == hist[-2]["gender"]
        prev = set(recent_voices(hist))
        viol["최근 3곡 보이스 재사용"] += bool(prev & set(e["voice"].split("+")))
        hist.append(e)
        gc[e["genre"]] += 1
        tc[e["gender"]] += 1
        fc[e["family"]] += 1
        for v in e["voice"].split("+"):
            vc[v] += 1
    print(f"추첨 {n}회 (seed {seed}) · 선호 스타일 {fav_n}회({fav_n * 100 // max(n, 1)}%) — 선호 스타일 곡은 반복 규칙 검사에서 뺌")
    print("위반:", json.dumps(viol, ensure_ascii=False))
    print("타입:", dict(tc))
    print("계열:", dict(fc))
    print("장르:", dict(gc))
    print("보이스:", dict(sorted(vc.items())))


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("draw")
    d.add_argument("--genre")
    d.add_argument("--vocal", choices=TYPES)
    d.add_argument("--voice", help="저장된 보이스 id 고정(예: M5 = 허스키 밀착 테너). 성별은 보이스를 따른다")
    d.add_argument("--seed", type=int)
    d.add_argument("--json")
    d.add_argument("--no-favorite", action="store_true", help="찰스님 선호 스타일(약 3/4) 없이 기존 16종 순환만")
    d.add_argument("--preset", help="이름 붙인 스타일 프리셋 id (예: hiphop1 = 힙합 스타일1). 장르 랜덤 대신 이 프리셋을 쓴다")
    d.add_argument("--theme", help="프리셋의 주제 id 고정")
    d.add_argument("--compact", action="store_true", help="프리셋의 compact 스타일(BPM·Korean 명시) 사용")
    c = sub.add_parser("commit")
    c.add_argument("--title", required=True)
    c.add_argument("--concept", required=True)
    sub.add_parser("history")
    sub.add_parser("list")
    s = sub.add_parser("sim")
    s.add_argument("--n", type=int, default=200)
    s.add_argument("--seed", type=int, default=1)
    a = ap.parse_args()

    if a.cmd == "sim":
        simulate(a.n, a.seed)
        return 0
    if a.cmd == "list":
        cfg = json.loads(CONCEPTS.read_text(encoding="utf-8"))
        for g in cfg["genres"]:
            print(f"{g['id']:18} {g['family']:10} {g['ko']}  BPM {g['bpm'][0]}~{g['bpm'][1]}")
        pr = json.loads(PRESETS.read_text(encoding="utf-8"))
        for k, v in pr.items():
            if not k.startswith("_"):
                print(f"[프리셋] {k:14} {v['ko']}  ({', '.join(v['triggers'][:2])})  주제 {len(v['themes'])}개")
        return 0
    st = pv.load_state()
    if a.cmd == "history":
        for h in st["history"][-12:]:
            print(f"{h['date']}  {h['gender']:6} {h['voice']:6} {h.get('genre', '-'):18} {h['title']}")
        return 0
    if a.cmd == "draw":
        if a.preset:
            out = draw_preset(st["history"], rng(a.seed), a.preset, a.theme, a.compact)
        else:
            out = draw(st["history"], rng(a.seed), a.genre, a.vocal, a.voice, a.no_favorite)
        txt = json.dumps(out, ensure_ascii=False, indent=1)
        if a.json:
            Path(a.json).write_text(txt, encoding="utf-8")
        print(txt)
        return 0
    if a.cmd == "commit":
        concept = json.loads(Path(a.concept).read_text(encoding="utf-8"))
        commit(st, a.title, concept)
        print(f"기록: {a.title} ({concept['vocal_type']}, {'+'.join(v['id'] for v in concept['voices'])}, {concept['genre']['id']}). 총 {len(st['history'])}곡")
        return 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
