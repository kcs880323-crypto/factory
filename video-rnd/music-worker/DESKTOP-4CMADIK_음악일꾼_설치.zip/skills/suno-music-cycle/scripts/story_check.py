#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""가사의 이야기 구조 점검(근사치, 표준 라이브러리만). lint_lyrics.py 가 불러 쓴다. 단독 실행도 된다.

  python story_check.py --md 날짜_제목_최종.md [--hook "훅 한 줄"]

여기서 재는 것은 **이야기가 있어 보이게 만드는 구조 신호**뿐이다. 모두 '주의'까지만 낸다(실패 없음).
  1. 프리코러스 복붙      2절 프리코러스가 1절과 거의 같으면 이야기가 안 자란다
  2. 모티프 재등장        1절의 구체적 사물·장소가 2절·브릿지·아웃트로에 다시 나오는가
  3. 훅 예고              프리코러스 마지막 줄이 훅으로 이어지는가(훅 단어나 훅 조각 애드립)
  4. 2번째 코러스 변화    훅이 아닌 줄이 2절 사건에 맞게 한 줄이라도 바뀌었는가
  5. 라스트 코러스 결말   훅이 아닌 줄이 결말에 맞게 바뀌었는가
  6. 브릿지 전환          브릿지에 새로운 말(1절·2절에 없던 구체어)이 있는가, 격언형 문장이 아닌가
  7. 아웃트로 여운        훅 외에 마무리 줄이 있는가
  8. 감정 직접 서술·상투어 '좋아, 사랑, 그립다' 같은 말로 감정을 설명하는 줄이 너무 많지 않은가
한계: 진정성·문장의 자연스러움·이야기의 설득력은 못 잰다. 형태소 분석기 없이 조사만 떼어 낸 단어로 비교하므로 동사는 잘 못 잡는다.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

SECTION_RE = re.compile(r"^\[([^\]]+)\]\s*$")
JOSA = sorted(["에서", "에게", "한테", "으로", "까지", "부터", "처럼", "보다", "이랑", "라도", "만큼", "의", "이", "가", "은", "는", "을", "를", "에", "도", "로", "와", "과", "만", "랑"], key=len, reverse=True)
STOP = set("""오늘 우리 지금 자꾸 자꾸만 아직 다시 그냥 너무 조금 하루 이대로 나도 모두 정말 진짜 이제 그래 그때 그게 이건 그건 모든 한번 항상 같이 함께 어디 언제 누가 무엇 하나 둘이
네가 내가 나는 너는 너를 나를 너도 그대 우린 우리가 너의 나의 크게 같아 것도 아니 사실 이렇게 그렇게 이런 그런 어떤 모든 서로 먼저 다시금 늘 계속 괜히 벌써 제일 가장 많이""".split())
CLICHE = ["영원히", "영원", "운명", "눈물이", "가슴이", "가슴 아", "사랑해", "행복해", "별처럼", "꿈만 같", "내 전부", "하늘만큼", "죽을 만큼", "마음이 아", "그리움이", "내일 걱정", "인생은", "사랑은 원래", "복잡하지 않"]
PAST_END = re.compile(r"(했어|였어|았어|었어|렸어|졌어|쳤어|왔어|갔어|봤어|줬어|췄어|냈어|뒀어|폈어|썼어|랐어|났어|섰어|웠어|켰어|랬어|혔어|렀어)$")
DOC_PROPS = ["편지", "봉투", "주소", "우체국", "우표", "쪽지", "포스트잇", "메모", "엽서"]
TELL = re.compile(r"좋아|좋기|좋은|사랑|행복|슬프|슬퍼|외로|그립|그리워|보고 ?싶|아프|힘들|설레|설렌|미안|고마|기뻐|두려|무서")


def split_sections(lyrics: str) -> list[tuple[str, list[str]]]:
    out: list[tuple[str, list[str]]] = []
    cur = None
    for raw in lyrics.splitlines():
        s = raw.strip()
        m = SECTION_RE.match(s)
        if m:
            cur = (m.group(1).strip(), [])
            out.append(cur)
        elif s and cur is not None:
            cur[1].append(s)
    return out


def bare(line: str) -> str:
    return re.sub(r"\([^)]*\)", "", line).strip()


def norm(line: str) -> str:
    return re.sub(r"\s+", "", bare(line))


def stems(text: str) -> set[str]:
    res: set[str] = set()
    for t in re.findall(r"[가-힣]{2,}", re.sub(r"\([^)]*\)", " ", text)):
        for j in JOSA:
            if t.endswith(j) and len(t) - len(j) >= 2:
                t = t[: -len(j)]
                break
        if len(t) >= 2 and t not in STOP:
            res.add(t)
    return res


def kind(name: str) -> str:
    n = name.lower()
    if n.startswith("pre"):
        return "pre"
    if n.startswith("final"):
        return "final"
    if "chorus" in n:
        return "chorus"
    for k in ("verse", "bridge", "outro", "intro"):
        if n.startswith(k):
            return k
    return "other"


def run(lyrics: str, hook: str | None, add) -> None:
    secs = split_sections(lyrics)
    if not secs:
        return
    # 훅 자동 감지: 가장 많이 반복되는 줄
    if not hook:
        cnt: dict[str, int] = {}
        for _, ls in secs:
            for l in ls:
                cnt[norm(l)] = cnt.get(norm(l), 0) + 1
        top = max(cnt, key=cnt.get) if cnt else ""
        hook = next((bare(l) for _, ls in secs for l in ls if norm(l) == top), "")
    hk = norm(hook)
    hstems = stems(hook)

    def is_hook(l: str) -> bool:
        return norm(l) == hk

    by: dict[str, list[tuple[str, list[str]]]] = {}
    for n, ls in secs:
        by.setdefault(kind(n), []).append((n, ls))

    # 1. 프리코러스 복붙
    pres = by.get("pre", [])
    if len(pres) >= 2:
        a = [norm(l) for l in pres[0][1]]
        b = [norm(l) for l in pres[1][1]]
        same = sum(1 for x in b if x in a)
        ok = same <= max(1, len(b) // 2)
        add("통과" if ok else "주의", f"[이야기] 2절 프리코러스가 1절과 다름 (같은 줄 {same}/{len(b)})",
            "" if ok else "프리코러스를 그대로 반복하면 이야기가 자라지 않는다. 최소 2줄은 2절 상황에 맞게 바꾼다")

    # 2. 모티프 재등장
    scope = []   # (표시이름, 중복 제거용 키, 어휘)
    seen_keys: set[str] = set()
    for n, ls in secs:
        body = [l for l in ls if not is_hook(l)]
        key = "|".join(norm(l) for l in body)
        if not body or key in seen_keys:
            continue
        seen_keys.add(key)
        scope.append((kind(n), n, stems(" ".join(body))))   # 훅 단어도 벌스·브릿지에 다시 나오면 모티프로 인정
    v1 = next((s for s in scope if s[0] == "verse"), None)
    later = [s for s in scope if s is not v1]
    motifs: list[tuple[str, int]] = []
    if v1:
        for w in sorted(v1[2]):
            where = {s[0] for s in later if w in s[2]}
            n_sec = sum(1 for s in later if w in s[2])
            if n_sec >= 1 and where & {"verse", "bridge", "outro", "final", "chorus", "pre"}:   # 한 번이라도 돌아오면 인정(권장 항목)
                motifs.append((w, n_sec + 1))
    motifs.sort(key=lambda x: -x[1])
    add("통과" if motifs else "주의", "[이야기] 1절의 이미지가 뒤에서 다시 나옴(권장, 모티프)",
        ", ".join(f"{w}({n}곳)" for w, n in motifs[:4]) if motifs else
        "1절의 이미지 하나가 2절·브릿지·아웃트로·후렴에서 한 번이라도 돌아오면 곡이 이어진다. 억지로 소품을 늘어놓지는 않는다")

    # 3. 훅 예고
    if pres:
        ok_cnt = 0
        for _, ls in pres:
            last = ls[-1] if ls else ""
            frag = " ".join(re.findall(r"\(([^)]*)\)", last))
            if (stems(bare(last)) & hstems) or (frag and (stems(frag) & hstems or any(w in hook for w in frag.split() if len(w) >= 2))):
                ok_cnt += 1
        add("통과" if ok_cnt == len(pres) else "주의", f"[이야기] 프리코러스 마지막 줄이 훅으로 이어짐 ({ok_cnt}/{len(pres)}곳)",
            "" if ok_cnt == len(pres) else "마지막 줄에 훅 단어를 넣거나 `(훅 첫 조각)` 애드립을 붙이면 훅이 더 기다려진다")

    # 4·5. 코러스 변화
    chs = by.get("chorus", [])
    fin = by.get("final", [])
    if len(chs) >= 2:
        c1 = [norm(l) for l in chs[0][1] if not is_hook(l)]
        c2 = [norm(l) for l in chs[1][1] if not is_hook(l)]
        changed = sum(1 for x in c2 if x not in c1)
        add("통과" if changed >= 1 else "주의", f"[이야기] 2번째 코러스에서 훅 아닌 줄이 바뀜 ({changed}줄)",
            "" if changed >= 1 else "훅(1·3줄)은 그대로 두고 2·4줄 중 한 줄을 2절 사건에 맞게 바꾸면 이야기가 진행된다")
    if chs and fin:
        c1 = [norm(l) for l in chs[0][1] if not is_hook(l)]
        f = [norm(l) for l in fin[0][1] if not is_hook(l)]
        changed = sum(1 for x in f if x not in c1)
        add("통과" if changed >= 1 else "주의", f"[이야기] 라스트 코러스에 결말이 있음 (첫 코러스와 다른 줄 {changed}줄)",
            "" if changed >= 1 else "라스트 코러스의 훅 아닌 줄을 결말(결정·해소·의미 변화)로 바꾼다. 애드립만 붙이면 첫 코러스와 같다")

    # 6. 브릿지 전환 + 격언
    br = by.get("bridge", [])
    if br:
        old: set[str] = set()
        for s in scope:
            if s[0] in ("verse", "pre"):
                old |= s[2]
        bs = stems(" ".join(br[0][1])) - hstems
        new = sorted(bs - old)
        ok = len(new) >= 2
        add("통과" if ok else "주의", f"[이야기] 브릿지에 새로운 말이 있음 (1·2절에 없던 단어 {len(new)}개)",
            ", ".join(new[:5]) if ok else "브릿지는 관점·시간·태도가 바뀌는 구체적 한 장면이어야 한다. 1·2절 말만 되풀이하면 전환이 아니다")

    # 7. 아웃트로 여운
    outs = by.get("outro", [])
    if outs:
        extra = [l for l in outs[0][1] if not is_hook(l)]
        add("통과" if extra else "주의", "[이야기] 아웃트로에 훅 외 마무리 줄이 있음",
            "" if extra else "훅만 반복하면 여운이 없다. 모티프 사물이 들어간 마무리 한 줄을 붙인다")

    # 8. 감정 직접 서술, 상투어
    body = [l for _, ls in secs for l in ls if not is_hook(l)]
    uniq = list(dict.fromkeys(norm(l) for l in body))
    tell = sum(1 for l in dict.fromkeys(body) if TELL.search(bare(l)))
    ratio = tell / max(1, len(set(body)))
    add("통과" if ratio <= 0.25 else "주의", f"[이야기] 감정을 직접 말하는 줄 {tell}/{len(set(body))} ({int(ratio * 100)}%)",
        "" if ratio <= 0.25 else "감정은 말하지 말고 행동·사물·장면으로 보여 준다(좋아한다 대신 무엇을 하는지)")
    txt = "\n".join(body)
    hit = [c for c in CLICHE if c in txt]
    add("통과" if len(hit) <= 1 else "주의", f"[이야기] 상투어·격언형 표현 {len(hit)}개",
        ", ".join(hit) if hit else "")

    # 9. 노래 문체 vs 편지·일기 문체 (2026-10-17: 서술체 가사가 "편지 같다"는 지적을 받았다)
    # 기존 5곡: 과거형 종결 0~10%, 같은 끝글자 연속 최대 2줄, 평균 9.8~11.9음절. 편지 같다던 곡: 52%, 5줄, 12.1음절.
    lines = list(dict.fromkeys(bare(l) for l in body if bare(l)))
    if lines:
        past = sum(1 for l in lines if PAST_END.search(l)) / len(lines)
        add("통과" if past <= 0.30 else "주의", f"[문체] 과거형 서술 종결 {int(past * 100)}% ({sum(1 for l in lines if PAST_END.search(l))}/{len(lines)}줄)",
            "" if past <= 0.30 else "있었던 일을 순서대로 서술하면 편지·일기처럼 읽힌다. 현재형·이미지·부름(너에게 말 걸기)으로 바꾼다")
        # 줄글 어미(-어/-아/-야)가 이어지는 경우만 센다. 후렴의 의도적인 대구(예: ~니까 / ~잖아 반복)는 문제 삼지 않는다.
        run_len = mx = 1
        for a_, b_ in zip(lines, lines[1:]):
            run_len = run_len + 1 if (a_[-1] == b_[-1] and a_[-1] in "어아야") else 1
            mx = max(mx, run_len)
        add("통과" if mx <= 3 else "주의", f"[문체] 줄글 어미(-어/-아/-야)가 이어진 최대 줄 수 {mx}",
            "" if mx <= 3 else "같은 줄글 어미가 줄줄이 이어지면 단조롭고 서술문처럼 들린다. 끝맺음을 섞는다(명사형·의문·부름·끊어 말하기). 후렴의 의도적 대구는 괜찮다")
        avg = sum(len(re.findall(r"[가-힣]", l)) for l in lines) / len(lines)
        add("통과" if avg <= 12.0 else "주의", f"[문체] 평균 {avg:.1f}음절/줄",
            "" if avg <= 12.0 else "줄이 길면 말하듯 길게 풀어 쓴 글이 된다. 한 줄에 이미지 하나, 8~12음절로 줄인다")
        props = [p for p in DOC_PROPS if p in "\n".join(lines)]
        add("통과" if len(props) <= 1 else "주의", f"[문체] 문서·우편 소품 단어 {len(props)}개",
            ", ".join(props) if props else "편지·봉투·주소·우체국·쪽지 같은 문서 소품이 중심이면 가사가 아니라 편지글이 된다")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--md", required=True)
    ap.add_argument("--hook")
    a = ap.parse_args()
    blocks = re.findall(r"```[^\n]*\n(.*?)```", Path(a.md).read_text(encoding="utf-8"), flags=re.S)
    if len(blocks) < 2:
        sys.exit("최종.md 에서 코드 블록 2개(스타일, 가사)를 찾지 못했습니다")
    sys.stdout.reconfigure(encoding="utf-8")
    res: list[tuple[str, str, str]] = []
    run(blocks[1].strip(), a.hook, lambda lv, nm, dt="": res.append((lv, nm, dt)))
    for lv, nm, dt in res:
        print(f"[{lv}] {nm}" + (f" — {dt}" if dt else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
