#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""곡 여러 개의 목소리·믹스를 같은 기준으로 비교한다 (asr-venv 의 파이썬, numpy 필요).

  asr-venv/python -u compare_songs.py --song "새곡=새곡.mp4@14-36@58-76" --song "참고곡=ref.mp4@30-52@53-80" [--json out.json]

각 곡을 `이름=파일@벌스구간@후렴구간`(초)으로 준다. 측정: 길이, 템포 후보(BPM), 전체 스펙트럼 균형(dB), 벌스·후렴의
피치 분포(중앙값·P10·P90·F4/A4/C5 이상 비율), 벌스·후렴 음량, 음색 코사인 유사도(MFCC 평균).
한계: 믹스에서 잰 값이라 악기에 흔들린다. 음색 유사도는 거친 지표라(곡끼리 0.90~0.94가 보통) 목소리 나이·성별·개성은 못 가른다.
같은 모델·같은 스타일로 만든 참고곡끼리의 유사도(기준선)와 비교해서 새 곡이 얼마나 벗어났는지만 본다. 2026-10-18 힙합 스타일1 점검에서 만들었다.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import voice_check as vc  # noqa: E402

SR = vc.SR


def mfcc_mean(seg, n_fft=512, hop=160, n_mels=26, n_ceps=13, fmin=150, fmax=3800):
    win = np.hanning(n_fft).astype(np.float32)
    frames = [seg[i:i + n_fft] * win for i in range(0, len(seg) - n_fft, hop)]
    if not frames:
        return np.zeros(n_ceps - 1)
    P = np.abs(np.fft.rfft(np.array(frames), axis=1)) ** 2
    energy = P.sum(axis=1)
    P = P[energy > np.percentile(energy, 30)]
    f = np.fft.rfftfreq(n_fft, 1 / SR)

    def mel(hz):
        return 2595 * np.log10(1 + hz / 700)

    def inv(m):
        return 700 * (10 ** (m / 2595) - 1)

    pts = inv(np.linspace(mel(fmin), mel(fmax), n_mels + 2))
    fb = np.zeros((n_mels, len(f)))
    for m in range(n_mels):
        lo, c, hi = pts[m], pts[m + 1], pts[m + 2]
        fb[m] = np.clip(np.minimum((f - lo) / (c - lo), (hi - f) / (hi - c)), 0, None)
    logmel = np.log(P @ fb.T + 1e-9)
    n = np.arange(n_mels)
    dct = np.array([np.cos(np.pi * k * (2 * n + 1) / (2 * n_mels)) for k in range(n_ceps)])
    return (logmel @ dct.T).mean(axis=0)[1:]


def cos(a, b):
    a = a - a.mean()
    b = b - b.mean()
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))


def tempo(x):
    n_fft, hop = 1024, 160
    win = np.hanning(n_fft).astype(np.float32)
    S = np.abs(np.array([np.fft.rfft(x[i:i + n_fft] * win) for i in range(0, min(len(x), SR * 90) - n_fft, hop)]))
    flux = np.maximum(0, np.diff(np.log1p(S[:, 2:40]), axis=0)).sum(axis=1)
    flux = flux - flux.mean()
    ac = np.correlate(flux, flux, "full")[len(flux) - 1:]
    best = []
    for bpm in range(60, 200):
        lag = int(round(60 / bpm * SR / hop))
        if lag < len(ac):
            best.append((float(ac[lag]), bpm))
    best.sort(reverse=True)
    return [b for _, b in best[:3]]


def ltas(x):
    n = 2048
    m = np.mean([np.abs(np.fft.rfft(x[i:i + n] * np.hanning(n))) for i in range(0, len(x) - n, n)], axis=0) ** 2
    f = np.fft.rfftfreq(n, 1 / SR)
    bands = {"저음 40-150": (40, 150), "저중음 150-500": (150, 500), "중음 500-2k": (500, 2000),
             "프레전스 2k-5k": (2000, 5000), "고음 5k-8k": (5000, 7990)}
    tot = m.sum()
    return {k: round(10 * math.log10(m[(f >= a) & (f < b)].sum() / tot + 1e-12), 1) for k, (a, b) in bands.items()}


def f0_stats(x, t0, t1):
    vb = vc.bandpass(x, 150, 1800)
    f0 = np.array(vc.f0_track(vb[int(t0 * SR):int(t1 * SR)]))
    if len(f0) < 20:
        return {}
    return {"n": len(f0), "중앙값Hz": round(float(np.median(f0))), "P10": round(float(np.percentile(f0, 10))),
            "P90": round(float(np.percentile(f0, 90))), "F4(349Hz)이상%": round(float((f0 > 349).mean() * 100)),
            "A4(440Hz)이상%": round(float((f0 > 440).mean() * 100)), "C5(523Hz)이상%": round(float((f0 > 523).mean() * 100))}


def rms_db(x, t0, t1):
    return round(20 * math.log10(float(np.sqrt(np.mean(x[int(t0 * SR):int(t1 * SR)] ** 2))) + 1e-9), 1)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--song", action="append", required=True, help="이름=파일@벌스a-b@후렴c-d")
    ap.add_argument("--json")
    a = ap.parse_args()
    songs = {}
    for s in a.song:
        name, rest = s.split("=", 1)
        path, v, c = rest.rsplit("@", 2)
        songs[name] = (path, tuple(float(t) for t in v.split("-")), tuple(float(t) for t in c.split("-")))
    rows, vecs = {}, {}
    for name, (path, vw, cw) in songs.items():
        x = vc.load_mono(path)
        vb = vc.bandpass(x, 150, 3800)
        rows[name] = {"길이초": round(len(x) / SR, 1), "템포후보BPM": tempo(vc.bandpass(x, 40, 600)), "전체 스펙트럼 균형(dB)": ltas(x),
                      "벌스": f0_stats(x, *vw), "후렴": f0_stats(x, *cw), "벌스 음량dB": rms_db(x, *vw), "후렴 음량dB": rms_db(x, *cw)}
        vecs[name] = {"벌스": mfcc_mean(vb[int(vw[0] * SR):int(vw[1] * SR)]), "후렴": mfcc_mean(vb[int(cw[0] * SR):int(cw[1] * SR)])}
    names = list(songs)
    sim = {}
    for part in ("벌스", "후렴"):
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                sim[f"{part}: {names[i]} vs {names[j]}"] = round(cos(vecs[names[i]][part], vecs[names[j]][part]), 3)
    out = {"songs": rows, "timbre_cosine": sim}
    if a.json:
        Path(a.json).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
