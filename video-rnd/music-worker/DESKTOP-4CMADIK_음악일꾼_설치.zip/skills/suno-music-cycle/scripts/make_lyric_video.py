#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""사진 한 장을 배경으로 쓰고 가사를 자막으로 입힌 세로 영상(1080x1920)을 만든다. 표준 파이썬 + Pillow + ffmpeg.

  python -u -I make_lyric_video.py --image cover.jpeg --audio 곡.mp4 --lines 곡_lines.json --out full.mp4 \
      --title "천천히 가도 좋아" [--start 43.1 --end 111.8] [--extra extra_lines.json] [--lufs -14] [--fade 0.25]

- `--lines` 는 `byeongmat-song-maker/scripts/make_subs.py align` 이 만든 JSON(`lines[].start/end/text/kind`)이다.
  `--extra` 는 같은 모양의 줄 목록(인트로·아웃트로처럼 align 이 빼는 줄을 손으로 넣을 때).
- 사진은 Suno 커버(1024x1024)를 쓴다. 검은 필름 테두리를 잘라 내고(`--crop L,T,R,B`), 높이를 1920으로 키운 뒤 폭 1080 창을 가로로 천천히 훑는다.
  위·아래에 어두운 그라데이션을 깔아 글씨를 읽기 쉽게 한다.
- 가사: 현재 줄만 크게(후렴은 크림색·더 크게), 괄호 애드립은 작고 흐리게. 줄이 뜰 때 15px 올라오며 페이드 인. 줄 시각은 음성 인식 값 그대로라 ±0.5초쯤 어긋날 수 있다.
- `--start/--end` 를 주면 그 구간만(릴스·스토리). 시작이 0이면 제목 카드를 첫 줄 전에 보여 준다(`--title`).
- 음량은 건드리지 않는다(원본 true peak 가 -1dBFS 를 넘을 때만 그만큼 낮추는 선형 이득, AAC 320k·48kHz 한 번 인코딩). 폰트는 맑은 고딕(Windows 기본)을 임시 폴더로 복사해 쓴다.
2026-10-18 `천천히 가도 좋아` 고음 개선판에서 만들었다(사용자 지시: 배경은 Suno 커버 사진만, 가사는 직접 입힌다).
"""
from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

W, H = 1080, 1920
FF = shutil.which("ffmpeg") or "ffmpeg"
FP = shutil.which("ffprobe") or "ffprobe"


def ass_time(t: float) -> str:
    t = max(0.0, t)
    cs = int(round(t * 100))
    return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"


def prepare_images(image: str, crop: str, td: Path) -> tuple[Path, Path]:
    from PIL import Image

    im = Image.open(image).convert("RGB")
    l, t, r, b = (int(v) for v in crop.split(","))
    im = im.crop((l, t, r, b))
    side = min(im.size)
    im = im.crop((0, 0, side, side)).resize((H, H), Image.LANCZOS)
    bg = td / "bg.png"
    im.save(bg)

    # 위·아래 그라데이션(글씨 가독성). 아래는 y 700부터 짙어져 가사 자리(약 1330)에서 절반 이상 덮는다.
    grad = Image.new("RGBA", (W, H))
    px = grad.load()

    def smooth(x: float) -> float:
        x = min(1.0, max(0.0, x))
        return x * x * (3 - 2 * x)

    for y in range(H):
        a_bot = 0.72 * smooth((y - 700) / 800)
        a_top = 0.38 * (1 - smooth(y / 420))
        a = max(a_bot, a_top)
        v = (0, 0, 0, int(255 * a))
        for x in range(W):
            px[x, y] = v
    g = td / "grad.png"
    grad.save(g)
    return bg, g


def split_text(text: str, limit: int = 13) -> str:
    """한 줄이 길면 가운데 가까운 공백에서 두 줄로 나눈다(ASS \\N)."""
    plain = text.replace("(", "").replace(")", "")
    if len(plain) <= limit or " " not in text:
        return text
    mid = len(text) / 2
    idx = min((i for i, c in enumerate(text) if c == " "), key=lambda i: abs(i - mid))
    return text[:idx] + "\\N" + text[idx + 1:]


def style_text(text: str, base_size: int) -> str:
    """괄호 애드립을 작고 흐리게. `천천히 가도 (천천히)` → 본문 + 작은 글씨."""
    out, i = [], 0
    small = int(base_size * 0.72)
    while i < len(text):
        c = text[i]
        if c == "(":
            j = text.find(")", i)
            if j < 0:
                j = len(text) - 1
            inner = text[i + 1:j]
            out.append("{\\fs%d\\1c&HD0D0D0&\\alpha&H30&}%s{\\r}" % (small, inner))
            i = j + 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


def build_ass(lines: list[dict], seg_start: float, seg_end: float, title: str, brand: str, y: int, size: int) -> str:
    dur = seg_end - seg_start
    cream = "&H00B3E7FF&"
    head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Lyric,Malgun Gothic,{size},&H00FFFFFF,&H00FFFFFF,&H00202020,&H80000000,-1,0,0,0,100,100,1,0,1,4,2,5,70,70,0,1
Style: Chorus,Malgun Gothic,{int(size * 1.12)},{cream},&H00FFFFFF,&H00202020,&H80000000,-1,0,0,0,100,100,1,0,1,4,2,5,70,70,0,1
Style: Title,Malgun Gothic,{int(size * 1.7)},&H00FFFFFF,&H00FFFFFF,&H00202020,&H80000000,-1,0,0,0,100,100,3,0,1,4,3,5,60,60,0,1
Style: Brand,Malgun Gothic,{int(size * 0.62)},&H00E6E6E6,&H00FFFFFF,&H00202020,&H80000000,0,0,0,0,100,100,4,0,1,3,2,5,60,60,0,1

[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
"""
    ev = []
    vis = [l for l in lines if l["end"] > seg_start and l["start"] < seg_end and l.get("text")]
    vis.sort(key=lambda l: l["start"])
    first = vis[0]["start"] - seg_start if vis else 0.0
    if seg_start <= 0.01 and title and first > 4.0:
        ts, te = 1.0, max(2.5, first - 0.6)
        ev.append(f"Dialogue: 1,{ass_time(ts)},{ass_time(te)},Title,,0,0,0,,{{\\an5\\pos(540,820)\\fad(900,700)}}{title}")
        if brand:
            ev.append(f"Dialogue: 1,{ass_time(ts + 0.4)},{ass_time(te)},Brand,,0,0,0,,{{\\an5\\pos(540,940)\\fad(900,700)}}{brand}")
    for i, l in enumerate(vis):
        s = max(0.0, l["start"] - seg_start - 0.10)
        nxt = vis[i + 1]["start"] - seg_start - 0.05 if i + 1 < len(vis) else dur
        e = min(l["end"] - seg_start + 0.9, nxt, dur - 0.05)
        if e - s < 1.2:
            e = min(s + 1.2, dur - 0.02)
        chorus = l.get("kind") == "chorus"
        sty = "Chorus" if chorus else "Lyric"
        base = int(size * 1.12) if chorus else size
        txt = style_text(split_text(l["text"], int(940 / (base * 0.92))), base)
        ev.append(f"Dialogue: 2,{ass_time(s)},{ass_time(e)},{sty},,0,0,0,,{{\\an5\\move(540,{y + 15},540,{y},0,320)\\fad(260,320)}}{txt}")
    return head + "\n".join(ev) + "\n"


def safe_gain_filter(audio: str, ss: float, dur: float, ceiling: float = -1.0, lufs: float = 0.0) -> str:
    """음질 보존: true peak 가 ceiling 보다 높을 때만 그만큼 낮추는 선형 이득(`volume=XdB`)을 돌려준다. 리미터·압축·loudnorm 없음.
    lufs 를 주면 그 음량까지 선형으로 올리되 ceiling 을 넘지 않는다(최대 +3dB). 이득이 0이면 빈 문자열."""
    r = subprocess.run([FF, "-hide_banner", "-nostats", "-ss", f"{ss:.3f}", "-t", f"{dur:.3f}", "-i", str(Path(audio).resolve()), "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    tail = r.stderr[r.stderr.rfind("Summary"):] if "Summary" in r.stderr else ""
    import re as _re
    mi = _re.search(r"I:\s+(-?\d+\.\d+) LUFS", tail)
    mp = _re.search(r"True peak:\s+Peak:\s+(-?\d+\.\d+) dBFS", tail) or _re.search(r"Peak:\s+(-?\d+\.\d+) dBFS", tail)
    if not mp:
        return ""
    tp = float(mp.group(1))
    gain = min(0.0, ceiling - tp)
    if lufs and mi:
        gain = max(gain, min(lufs - float(mi.group(1)), ceiling - tp, 3.0))
    print(f"오디오: 원본 {mi.group(1) if mi else '?'} LUFS / true peak {tp} dBFS -> 이득 {gain:+.2f} dB만 적용(리미터·압축 없음), AAC 320k 한 번 인코딩")
    return f"volume={gain:.2f}dB" if abs(gain) > 0.005 else ""


def probe(path: str, entry: str) -> float:
    r = subprocess.run([FP, "-v", "error", "-show_entries", entry, "-of", "csv=p=0", path], capture_output=True, text=True)
    return float(r.stdout.strip().split("\n")[0].split(",")[0])


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--image", required=True)
    ap.add_argument("--audio", required=True)
    ap.add_argument("--lines", required=True)
    ap.add_argument("--extra")
    ap.add_argument("--out", required=True)
    ap.add_argument("--title", default="")
    ap.add_argument("--brand", default="찰스뮤직 · CharlesMusic")
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=0.0)
    ap.add_argument("--crop", default="40,32,992,984")
    ap.add_argument("--y", type=int, default=1330)
    ap.add_argument("--size", type=int, default=72)
    ap.add_argument("--lufs", type=float, default=0.0, help="목표 음량. 기본 0=끔(음질 보존: true peak 가 -1dB 를 넘을 때만 이득을 낮춘다)")
    ap.add_argument("--fade", type=float, default=0.25)
    ap.add_argument("--vfade", type=float, default=0.8, help="끝에서 화면이 어두워지는 길이(초)")
    ap.add_argument("--crf", type=int, default=20)
    ap.add_argument("--ass-only", help="영상은 만들지 않고 ASS 파일만 이 경로에 쓴다")
    ap.add_argument("--frame", type=float, help="완성 영상에서 이 시각(초)의 정지 화면 PNG를 --out 옆에 저장")
    a = ap.parse_args()

    data = json.loads(Path(a.lines).read_text(encoding="utf-8"))
    lines = list(data["lines"])
    if a.extra:
        lines += json.loads(Path(a.extra).read_text(encoding="utf-8"))
    total = probe(a.audio, "format=duration")
    seg_start = a.start
    seg_end = a.end if a.end > 0 else total
    dur = seg_end - seg_start
    ass = build_ass(lines, seg_start, seg_end, a.title, a.brand, a.y, a.size)
    if a.ass_only:
        Path(a.ass_only).write_text(ass, encoding="utf-8")
        print(f"ASS: {a.ass_only}")
        return

    out_abs = Path(a.out).resolve()
    out_abs.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tds:
        td = Path(tds)
        bg, grad = prepare_images(a.image, a.crop, td)
        (td / "subs.ass").write_text(ass, encoding="utf-8")
        fdir = td / "fonts"
        fdir.mkdir()
        winfonts = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
        for fn in ("malgun.ttf", "malgunbd.ttf"):
            if (winfonts / fn).exists():
                shutil.copy(winfonts / fn, fdir / fn)
        pan = f"(iw-{W})*(0.5-0.5*cos(PI*t/{dur:.3f}))"
        vf = (f"[0:v]crop={W}:{H}:x='{pan}':y=0[bg];[bg][1:v]overlay=0:0,ass=subs.ass:fontsdir=fonts,"
              f"fade=t=out:st={max(0.0, dur - a.vfade):.2f}:d={a.vfade},format=yuv420p[v]")
        af = []
        sg = safe_gain_filter(a.audio, seg_start, dur, lufs=a.lufs)  # 음질 보존: 필요할 때만 이득을 낮춘다(리미터·loudnorm 없음)
        if sg:
            af.append(sg)
        af.append("afade=t=in:st=0:d=0.04")  # 구간이 곡 중간에서 시작할 때 첫 샘플의 클릭 방지
        if a.fade > 0:
            af.append(f"afade=t=out:st={max(0.0, dur - a.fade):.2f}:d={a.fade}")
        cmd = [FF, "-v", "error", "-y",
               "-loop", "1", "-framerate", "30", "-t", f"{dur:.3f}", "-i", str(bg),
               "-loop", "1", "-framerate", "30", "-t", f"{dur:.3f}", "-i", str(grad),
               "-ss", f"{seg_start:.3f}", "-t", f"{dur:.3f}", "-i", str(Path(a.audio).resolve()),
               "-filter_complex", vf, "-map", "[v]", "-map", "2:a:0",
               "-c:v", "libx264", "-preset", "medium", "-crf", str(a.crf), "-maxrate", "8M", "-bufsize", "16M",
               "-pix_fmt", "yuv420p", "-r", "30", "-c:a", "aac", "-b:a", "320k", "-ar", "48000"]
        if af:
            cmd += ["-af", ",".join(af)]
        cmd += ["-t", f"{dur:.3f}", "-movflags", "+faststart", str(out_abs)]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=td)
        if r.returncode != 0:
            sys.exit("ffmpeg 실패:\n" + r.stderr[-1800:])
    od = probe(str(out_abs), "format=duration")
    print(f"완료: {out_abs}  {od:.1f}초, {out_abs.stat().st_size / 1e6:.1f}MB")
    if a.frame is not None:
        png = out_abs.with_suffix(f".f{int(a.frame)}.png")
        subprocess.run([FF, "-v", "error", "-y", "-ss", f"{a.frame:.2f}", "-i", str(out_abs), "-frames:v", "1", str(png)])
        print(f"프레임: {png}")


if __name__ == "__main__":
    main()
