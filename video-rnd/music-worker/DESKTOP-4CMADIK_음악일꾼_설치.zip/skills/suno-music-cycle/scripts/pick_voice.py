#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""보이스 선택기 (표준 라이브러리만). 여/남을 랜덤하게 번갈아 가며, 개성 있는 보이스 팔레트에서 고른다.

  python pick_voice.py gender [--force male|female]
      다음 곡의 성별을 정한다. 기본은 랜덤이되 같은 성별이 3곡 연속되지 않게 한다(2연속 뒤에는 반대로 강제).
  python pick_voice.py voice --gender male --genre "acoustic band pop, easy listening"
      그 성별의 보이스 중 장르에 맞고 최근 3곡에 안 쓴 것을 가중 랜덤으로 고른다. 스타일 앞에 넣을 영어 묘사와 고음 훅 태그를 출력한다.
  python pick_voice.py commit --title 제목 --gender male --voice M2
      생성이 끝난 곡을 이력에 기록한다(이력은 $SUNO_CYCLE_HOME/voice_state.json).
  python pick_voice.py history      최근 이력 보기

보컬 이력과 선택은 재현 가능하게 하려면 --seed 를 준다. 기본은 시스템 난수.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
import time
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

HOME = Path(os.environ.get("SUNO_CYCLE_HOME") or Path.home() / ".config" / "suno-cycle")
STATE = HOME / "voice_state.json"
PALETTE = Path(__file__).resolve().parent.parent / "config" / "voices.json"
P_OPPOSITE = 0.75   # 직전과 반대 성별이 나올 확률(랜덤 교대). 2연속이면 100%.


def load_state() -> dict:
    if STATE.exists():
        return json.loads(STATE.read_text(encoding="utf-8"))
    return {"history": []}


def rng(seed: int | None):
    return random.Random(seed) if seed is not None else random.SystemRandom()


def pick_gender(hist: list[dict], r, force: str | None) -> dict:
    hist = [h for h in hist if h["gender"] in ("male", "female")]   # 듀엣 곡은 교대 계산에서 뺀다(3종 추첨은 pick_concept.py)
    if force:
        return {"gender": force, "reason": "강제 지정"}
    if not hist:
        return {"gender": r.choice(["female", "male"]), "reason": "이력 없음, 랜덤"}
    last = hist[-1]["gender"]
    run = 0
    for h in reversed(hist):
        if h["gender"] == last:
            run += 1
        else:
            break
    opposite = "male" if last == "female" else "female"
    if run >= 2:
        return {"gender": opposite, "reason": f"{last} {run}곡 연속이라 반대로 강제"}
    g = opposite if r.random() < P_OPPOSITE else last
    return {"gender": g, "reason": f"직전 {last}, 랜덤(반대 확률 {int(P_OPPOSITE * 100)}%) → {g}"}


def pick_voice(gender: str, genre: str, hist: list[dict], r, recent: list[str] | None = None) -> dict:
    pal = json.loads(PALETTE.read_text(encoding="utf-8"))
    if recent is None:
        recent = [h["voice"] for h in hist[-3:]]
    g = genre.lower()
    cands = []
    for v in pal["voices"]:
        if v["gender"] != gender or v["id"] in recent:
            continue
        score = 1 + sum(2 for k in v["genres"] if k in g)   # 장르 일치 가산점, 일치가 없어도 후보로 남긴다
        cands.append((score, v))
    if not cands:  # 모두 최근에 썼으면 최근 제한을 푼다
        cands = [(1 + sum(2 for k in v["genres"] if k in g), v) for v in pal["voices"] if v["gender"] == gender]
    total = sum(s for s, _ in cands)
    x = r.uniform(0, total)
    acc = 0.0
    chosen = cands[-1][1]
    for s, v in cands:
        acc += s
        if x <= acc:
            chosen = v
            break
    return {
        "gender": gender, "voice": chosen["id"], "ko": chosen["ko"], "short": chosen.get("short", ""),
        "style_vocal": chosen["style"] + ", " + pal["common_human_cues"], "style_only": chosen["style"],
        "common_cues": pal["common_human_cues"],
        "hook_tag": chosen["hook_tag"], "mix": chosen.get("mix"), "suno_params": chosen.get("suno_params"),
        "hook_tag_belt": chosen.get("hook_tag_belt"), "user_saved": bool(chosen.get("user_saved")),
        "exclude_common": pal["common_exclude"],
        "suno_vocal_button": "여성" if gender == "female" else "남성",
        "candidates": [{"id": v["id"], "weight": s} for s, v in cands],
        "recent_excluded": recent,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("gender")
    g.add_argument("--force", choices=["male", "female"])
    g.add_argument("--seed", type=int)
    v = sub.add_parser("voice")
    v.add_argument("--gender", required=True, choices=["male", "female"])
    v.add_argument("--genre", default="")
    v.add_argument("--seed", type=int)
    c = sub.add_parser("commit")
    c.add_argument("--title", required=True)
    c.add_argument("--gender", required=True, choices=["male", "female"])
    c.add_argument("--voice", required=True)
    sub.add_parser("history")
    a = ap.parse_args()

    st = load_state()
    if a.cmd == "gender":
        print(json.dumps(pick_gender(st["history"], rng(a.seed), a.force), ensure_ascii=False))
    elif a.cmd == "voice":
        print(json.dumps(pick_voice(a.gender, a.genre, st["history"], rng(a.seed)), ensure_ascii=False, indent=1))
    elif a.cmd == "commit":
        st["history"].append({"date": time.strftime("%Y-%m-%d"), "title": a.title, "gender": a.gender, "voice": a.voice})
        HOME.mkdir(parents=True, exist_ok=True)
        STATE.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"기록: {a.title} ({a.gender}, {a.voice}). 총 {len(st['history'])}곡")
    elif a.cmd == "history":
        for h in st["history"][-10:]:
            print(f"{h['date']}  {h['gender']:6} {h['voice']:3} {h['title']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
