#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""곡에 맞는 일러스트 한 장 + 노래방처럼 차오르는 가사 + 제목·@찰스뮤직 으로 곡 영상을 만든다. Pillow + numpy + ffmpeg.

  # 세로(릴스·스토리·쇼츠, 1080x1920) — 구간만
  asr-venv/python -u -I make_art_lyric_video.py --image art916.png --audio 곡.mp4 --lines 곡_lines.json --md 최종.md \
      --title "늦은 말이라도 닿아라" --out reel.mp4 --start 65.0 --end 148.1 --fade 0.25 [--art-cut 0.658] [--glow 0.28,0.246]
  # 가로(유튜브 풀 영상, 1920x1080) — 곡 전체
  asr-venv/python -u -I make_art_lyric_video.py --landscape --image art169.png --audio 곡.mp4 --lines ... --md ... --title ... --out full.mp4
  # 정지 화면만(확인용):  --stills 67.5,106.5

- 일러스트(Genspark)는 위쪽만 쓸 수 있다(`--art-cut` 비율 아래는 버림 — 모델이 아래를 흐린 띠로 채우며 경계선을 남기는 일이 있다).
  그 아래는 그림 바닥 색을 늘여 흐리고 어둡게 이은 '무대'(가사·제목 자리)가 되고, 경계는 부드럽게 녹인다. 화면이 아주 천천히 다가간다(아핀, 계단 없음).
- 떠다니는 눈·빛 알갱이 두 겹, `--glow`(그림 비율 좌표, 예: 가로등)에 따뜻한 빛 — 소리가 커지면(후렴) 밝아진다.
- 가사: 지금 줄이 부르는 순서대로 차오르고(글자 수 비례 — 실제 발음과 ±0.3초 어긋날 수 있다) 빛이 번진다. 다음 줄은 아래에 흐리게.
  후렴(`--md`의 [Chorus]·[Hook] 계열)은 크림색·더 크게. 괄호 애드립은 줄을 거의 부른 뒤 위에 금색으로 작게.
- 제목 블록(왼쪽 아래): 명조 제목 + 금색 선 + `@찰스뮤직 · AI Music` + 곡 전체 진행 막대.
- 음질 보존: 곡 전체(시작 0·끝 없음)이고 true peak 가 -1dBFS 이하면 소리는 **스트림 복사**(비트 동일). 구간이거나 넘으면 이득만 + AAC 320k·48kHz 한 번(`--fade` 는 구간 앞뒤 0.25초).
- 빠르게: 프레임을 `--workers` 개 프로세스로 나눠 그리고(각자 영상 조각) 이어 붙인다. 첫 프레임부터 그림·제목이 보인다.
2026-10-30 사용자 요청("겉표지를 노래와 어울리는 일러스트 깔고 가사 나오면서 제목 아래 @찰스뮤직, 참고 이미지보다 더 멋지게" → 샘플 확인 뒤 "1번 적용")으로 만들었다.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

sys.stdout.reconfigure(encoding="utf-8")

FPS = 30
SS = 1.15                                  # 배경을 이만큼 크게 만들어 두고 매 프레임 줄여 그린다(최대 확대 1.075보다 커야 흐려지지 않는다)
ZOOM = 0.075
FF = shutil.which("ffmpeg") or "ffmpeg"
FP = shutil.which("ffprobe") or "ffprobe"
FONT_DIR = Path(r"C:\Windows\Fonts")
SANS, SERIF = FONT_DIR / "NotoSansKR-VF.ttf", FONT_DIR / "NotoSerifKR-VF.ttf"
FALLBACK = FONT_DIR / "malgunbd.ttf"
GOLD, CREAM = (231, 196, 128), (255, 236, 200)
# 화면 배치. 세로는 인스타·쇼츠 아래 UI(약 320px)와 오른쪽 버튼을 피한다.
LAYOUTS = {
    "portrait": {"W": 1080, "H": 1920, "lyric_y": 1205, "next_gap": 96, "title_x": 84, "title_y": 1418, "max_w": 900, "title_max": 760,
                 "sizes": (62, 70, 44), "title": 62, "shade_from": 0.50, "shade_span": 0.22, "focus_y": 0.36},
    "landscape": {"W": 1920, "H": 1080, "lyric_y": 760, "next_gap": 82, "title_x": 96, "title_y": 868, "max_w": 1400, "title_max": 900,
                  "sizes": (58, 66, 40), "title": 52, "shade_from": 0.45, "shade_span": 0.38, "focus_y": 0.42},
}


def font(path: Path, size: int, weight: str = "Bold"):
    try:
        f = ImageFont.truetype(str(path), size)
        try:
            names = f.get_variation_names()          # 바이트 이름(b'SemiBold')이라 문자열로 주면 조용히 무시된다
            pick = next((n for n in names if n.lower() == weight.lower().encode()), None)
            if pick:
                f.set_variation_by_name(pick)
        except Exception:  # noqa: BLE001 — 가변 글꼴이 아니면 기본 굵기
            pass
        return f
    except OSError:
        return ImageFont.truetype(str(FALLBACK), size)


# ── 가사 ─────────────────────────────────────────────────────────────────
def norm(s: str) -> str:
    return re.sub(r"[\s,.!?~·…'\"]", "", s)


def chorus_texts(md: str) -> set:
    out, sec = set(), ""
    for raw in md.splitlines():
        s = raw.strip()
        m = re.match(r"^\[([^\]]+)\]$", s)
        if m:
            sec = m.group(1).lower()
            continue
        if s and not s.startswith("```") and ("chorus" in sec or "hook" in sec):
            out.add(norm(re.sub(r"\([^)]*\)", "", s)))
    return out


def load_lines(path: str, md_path: str | None) -> list:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    rows = data.get("lines") if isinstance(data, dict) else data
    ch = chorus_texts(Path(md_path).read_text(encoding="utf-8")) if md_path else set()
    out = []
    for r in rows or []:
        text = str(r.get("text") or "").strip()
        if not text or r.get("start") is None:
            continue
        ad = " ".join(re.findall(r"\(([^)]*)\)", text)).strip()
        main = re.sub(r"\s*\([^)]*\)\s*", " ", text).strip()
        if not main and ad:
            main, ad = ad, ""
        out.append({"start": float(r["start"]), "end": float(r.get("end") or r["start"] + 3), "text": main, "adlib": ad,
                    "chorus": norm(main) in ch or str(r.get("kind", "")).lower() in ("chorus", "hook")})
    out.sort(key=lambda x: x["start"])
    for i, ln in enumerate(out):     # 부르는 구간은 다음 줄이 시작하기 전까지
        nxt = out[i + 1]["start"] if i + 1 < len(out) else ln["end"] + 2
        ln["sing_end"] = max(ln["start"] + 0.6, min(ln["end"], nxt - 0.05))
        ln["show_end"] = min(nxt, ln["sing_end"] + 2.5)
    return out


class LineArt:
    """한 줄을 미리 그려 둔다: 흐린 글씨·밝은 글씨·빛 번짐·그림자 + 글자별 x 위치(차오르기용)."""

    def __init__(self, text: str, chorus: bool, size: int, max_w: int):
        self.f = font(SANS, size, "Bold")
        pad = 40
        tw = int(self.f.getlength(text)) + 2
        while tw > max_w and size > 34:
            size -= 4
            self.f = font(SANS, size, "Bold")
            tw = int(self.f.getlength(text)) + 2
        asc, desc = self.f.getmetrics()
        self.w, self.h, self.pad = tw + pad * 2, asc + desc + pad * 2, pad
        mask = Image.new("L", (self.w, self.h), 0)
        ImageDraw.Draw(mask).text((pad, pad), text, font=self.f, fill=255)
        base = CREAM if chorus else (255, 255, 255)
        self.bright = rgba(base, mask)
        self.dim = rgba((235, 235, 245), mask.point(lambda v: int(v * 0.38)))
        g = mask.filter(ImageFilter.GaussianBlur(14)).point(lambda v: min(255, int(v * 1.6)))
        self.glow = rgba((255, 205, 140) if chorus else (255, 225, 190), g.point(lambda v: int(v * 0.55)))
        self.shadow = rgba((0, 0, 0), mask.filter(ImageFilter.GaussianBlur(6)).point(lambda v: int(v * 0.55)))
        self.base_a = {k: np.asarray(getattr(self, k).getchannel("A"), dtype=np.float32) for k in ("bright", "glow")}
        self.xs, ws = [], []
        for i, ch in enumerate(text):
            self.xs.append(pad + self.f.getlength(text[: i + 1]))
            ws.append(0.35 if ch.isspace() else 0.0 if re.match(r"[,.!?~…·'\"]", ch) else 1.0)
        tot, acc, self.cum = sum(ws) or 1.0, 0.0, []
        for w_ in ws:
            acc += w_
            self.cum.append(acc / tot)
        self.cols = np.arange(self.w, dtype=np.float32)

    def fill_x(self, frac: float) -> float:
        if frac <= 0:
            return self.pad
        for i, c in enumerate(self.cum):
            if c >= frac:
                prev_c = self.cum[i - 1] if i else 0.0
                prev_x = self.xs[i - 1] if i else self.pad
                return prev_x + (self.xs[i] - prev_x) * (frac - prev_c) / max(1e-6, c - prev_c)
        return self.w - self.pad

    def clipped(self, which: str, x: float, feather: int, k: float) -> Image.Image:
        """왼쪽부터 x 까지만(경계는 부드럽게), 투명도 k."""
        ramp = np.clip((x - self.cols) / feather + 0.5, 0, 1) * k
        a = (self.base_a[which] * ramp[None, :]).astype(np.uint8)
        im = getattr(self, which).copy()
        im.putalpha(Image.fromarray(a))
        return im


def rgba(color, alpha: Image.Image) -> Image.Image:
    im = Image.new("RGBA", alpha.size, tuple(color) + (0,))
    im.putalpha(alpha)
    return im


def faded(img: Image.Image, k: float) -> Image.Image:
    if k >= 0.999:
        return img
    out = img.copy()
    out.putalpha(img.getchannel("A").point(lambda v: int(v * max(0.0, k))))
    return out


# ── 배경 ─────────────────────────────────────────────────────────────────
def build_canvas(image: str, cut: float, W: int, H: int) -> tuple[Image.Image, float]:
    """(배경, 그림 높이 비율). 그림을 캔버스 폭에 맞추고, 남는 아래는 그림 바닥을 늘인 어두운 무대."""
    src = Image.open(image).convert("RGB")
    sw, sh = src.size
    top = src.crop((0, 0, sw, max(2, int(sh * cut))))
    BW, BH = int(W * SS), int(H * SS)
    th = int(top.height * BW / top.width)
    top = top.resize((BW, th), Image.LANCZOS).filter(ImageFilter.UnsharpMask(radius=2, percent=60, threshold=2))
    canvas = Image.new("RGB", (BW, BH), (6, 8, 14))
    if th < BH:
        blend = min(240, th // 3)
        strip = top.crop((0, th - max(8, int(th * 0.12)), BW, th)).resize((BW, BH - th + blend), Image.BICUBIC).filter(ImageFilter.GaussianBlur(38))
        dark = np.asarray(strip, dtype=np.float32)
        ramp = np.linspace(0.75, 0.16, dark.shape[0])[:, None, None]
        dark = (dark * ramp + np.array([6, 8, 14], dtype=np.float32) * (1 - ramp)).clip(0, 255).astype(np.uint8)
        canvas.paste(Image.fromarray(dark), (0, th - blend))
        m = np.ones((th, BW), dtype=np.float32)
        m[th - blend:, :] = np.linspace(1, 0, blend)[:, None] ** 1.4
        canvas.paste(top, (0, 0), Image.fromarray((m * 255).astype(np.uint8)))
    else:                                    # 그림이 화면보다 길면(정사각 커버·세로 그림을 가로 화면에 쓸 때) 그림 높이 42% 언저리(보통 주인공 자리)를 가운데로
        y0 = max(0, min(th - BH, int(th * 0.42 - BH / 2)))
        canvas.paste(top.crop((0, y0, BW, y0 + BH)), (0, 0))
    a = np.asarray(canvas, dtype=np.float32) / 255.0
    lum = a.mean(axis=2, keepdims=True)
    a = a + (1 - lum) * np.array([-0.012, 0.010, 0.030]) + lum * np.array([0.028, 0.010, -0.020])
    yy, xx = np.mgrid[0:BH, 0:BW]
    d = np.sqrt(((xx - BW / 2) / (BW * 0.72)) ** 2 + ((yy - BH * 0.42) / (BH * 0.62)) ** 2)
    a *= (1 - np.clip(d - 0.55, 0, 1) * 0.55)[..., None]
    return Image.fromarray((a.clip(0, 1) * 255).astype(np.uint8)), min(1.0, th / BH)


def particle_sprites():
    out = []
    for r, blur in ((3, 1.2), (5, 2.2), (9, 4.5), (14, 7)):
        s = r * 6
        im = Image.new("L", (s, s), 0)
        ImageDraw.Draw(im).ellipse((s / 2 - r, s / 2 - r, s / 2 + r, s / 2 + r), fill=255)
        out.append(im.filter(ImageFilter.GaussianBlur(blur)))
    return out


def make_particles(n: int, W: int, H: int, seed: int = 7) -> list:
    rng = np.random.default_rng(seed)
    ps = []
    for _ in range(n):
        layer = int(rng.choice([0, 0, 1, 1, 1, 2, 3]))
        ps.append({"x": rng.uniform(0, W), "y": rng.uniform(-H * 0.1, H), "vy": [16, 26, 44, 70][layer] * rng.uniform(0.7, 1.3) * H / 1920,
                   "sway": rng.uniform(8, 30), "ph": rng.uniform(0, 6.28), "fr": rng.uniform(0.15, 0.45), "a": [0.55, 0.5, 0.32, 0.18][layer] * rng.uniform(0.6, 1.0),
                   "layer": layer, "warm": bool(rng.random() < 0.25)})
    return ps


def glow_sprite(r: int) -> Image.Image:
    s = r * 2
    yy, xx = np.mgrid[0:s, 0:s]
    a = np.clip(1 - np.sqrt((xx - r) ** 2 + (yy - r) ** 2) / r, 0, 1) ** 2.2
    im = np.zeros((s, s, 4), dtype=np.uint8)
    im[..., 0], im[..., 1], im[..., 2], im[..., 3] = 255, 190, 120, (a * 255).astype(np.uint8)
    return Image.fromarray(im, "RGBA")


# ── 소리 ─────────────────────────────────────────────────────────────────
def envelope(audio: str, start: float, dur: float) -> np.ndarray:
    cmd = [FF, "-v", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", audio, "-ac", "1", "-ar", "12000", "-f", "s16le", "-"]
    x = np.frombuffer(subprocess.run(cmd, capture_output=True, check=True).stdout, dtype=np.int16).astype(np.float32) / 32768.0
    hop = 12000 // FPS
    n = max(1, len(x) // hop)
    db = 20 * np.log10(np.sqrt(np.array([np.mean(x[i * hop:(i + 1) * hop] ** 2) + 1e-9 for i in range(n)])))
    lo, hi = np.percentile(db, 10), np.percentile(db, 97)
    v = np.clip((db - lo) / max(1e-3, hi - lo), 0, 1)
    sm, acc = np.zeros_like(v), (v[0] if len(v) else 0.0)
    for i, s in enumerate(v):           # 올라갈 땐 빠르게, 내려갈 땐 천천히
        acc = acc + (s - acc) * (0.25 if s > acc else 0.04)
        sm[i] = acc
    return sm


def true_peak(audio: str, start: float, dur: float | None) -> float:
    cmd = [FF, "-hide_banner", "-nostats", *(["-ss", f"{start:.3f}"] if start else []), *(["-t", f"{dur:.3f}"] if dur else []), "-i", audio, "-af", "ebur128=peak=true", "-f", "null", "-"]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    m = re.findall(r"Peak:\s+(-?[\d.]+)\s+dBFS", r.stderr)
    return float(m[-1]) if m else -2.0


def duration(path: str) -> float:
    r = subprocess.run([FP, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path], capture_output=True, text=True)
    return float(r.stdout.strip() or 0)


def fmt(t: float) -> str:
    t = max(0, int(t))
    return f"{t // 60}:{t % 60:02d}"


# ── 그리기 ────────────────────────────────────────────────────────────────
class Renderer:
    def __init__(self, a, total: float):
        self.a, self.total = a, total
        L = LAYOUTS["landscape" if a.landscape else "portrait"]
        self.L, self.W, self.H = L, L["W"], L["H"]
        self.canvas, art_frac = build_canvas(a.image, a.art_cut, self.W, self.H)
        cw, ch = self.canvas.size
        gx, gy = (float(v) for v in a.glow.split(",")) if a.glow else (None, None)
        self.glow_pt = (gx * cw, (gy / a.art_cut) * art_frac * ch) if gx is not None else None
        self.focus = (cw * (gx if gx is not None else 0.5), ch * L["focus_y"])
        self.sprites = particle_sprites()
        self.parts = make_particles(70 if not a.landscape else 80, self.W, self.H)
        self.spr_cache = {}
        self.glow = glow_sprite(300 if not a.landscape else 260)
        self.glow_cache = {}
        self.lines = load_lines(a.lines, a.md)
        self.cache = {}
        self.static = self.static_overlay()
        self.small = font(SANS, 20, "Regular")
        self.ad_font = font(SANS, 30, "Medium")

    def static_overlay(self) -> Image.Image:
        """화면에 고정된 것: 아래쪽 어둡게 + 제목 블록(진행 막대 자리 기록)."""
        W, H, L = self.W, self.H, self.L
        g = np.zeros((H, W, 4), dtype=np.uint8)
        y = np.arange(H)
        g[..., 3] = (np.clip((y - H * L["shade_from"]) / (H * L["shade_span"]), 0, 1) ** 1.3 * 150)[:, None].astype(np.uint8)
        if self.a.landscape:            # 가로는 왼쪽 아래도 조금 더(제목 자리)
            x = np.arange(W)
            g[..., 3] = np.maximum(g[..., 3], (np.clip(1 - x / (W * 0.55), 0, 1)[None, :] * np.clip((y - H * 0.6) / (H * 0.4), 0, 1)[:, None] * 110).astype(np.uint8))
        im = Image.fromarray(g, "RGBA")
        d = ImageDraw.Draw(im)
        tx, ty = L["title_x"], L["title_y"]
        tf = font(SERIF, L["title"], "SemiBold")
        while tf.getlength(self.a.title) > L["title_max"] and tf.size > 34:
            tf = font(SERIF, tf.size - 4, "SemiBold")
        sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(sh).text((tx, ty), self.a.title, font=tf, fill=(0, 0, 0, 170))
        im.alpha_composite(sh.filter(ImageFilter.GaussianBlur(7)))
        d.text((tx, ty), self.a.title, font=tf, fill=(250, 246, 238, 255))
        y2 = ty + sum(tf.getmetrics()) + 14
        d.line((tx + 2, y2, tx + 58, y2), fill=GOLD + (230,), width=3)
        hf, sf = font(SANS, 30, "Medium"), font(SANS, 22, "Regular")
        d.text((tx, y2 + 16), self.a.handle, font=hf, fill=(245, 240, 230, 235))
        d.text((tx + hf.getlength(self.a.handle) + 18, y2 + 23), "·  AI Music", font=sf, fill=(220, 214, 200, 150))
        self.bar_y = y2 + 72
        return im

    def sprite(self, layer: int, warm: bool, a: float) -> Image.Image:
        key = (layer, warm, int(a * 20))
        if key not in self.spr_cache:
            self.spr_cache[key] = rgba((255, 214, 160) if warm else (235, 240, 255), self.sprites[layer].point(lambda v, k=key[2] / 20: int(v * k)))
        return self.spr_cache[key]

    def glow_at(self, amp: float) -> Image.Image:
        key = int(amp * 40)
        if key not in self.glow_cache:
            self.glow_cache[key] = faded(self.glow, key / 40)
        return self.glow_cache[key]

    def line_art(self, i: int, small: bool = False) -> LineArt:
        key = (i, small)
        if key not in self.cache:
            ln = self.lines[i]
            s_norm, s_ch, s_small = self.L["sizes"]
            self.cache[key] = LineArt(ln["text"], ln["chorus"], s_small if small else (s_ch if ln["chorus"] else s_norm), self.L["max_w"])
            if len(self.cache) > 12:
                self.cache.pop(next(iter(self.cache)))
        return self.cache[key]

    def frame(self, t_song: float, k: float, env: float, ti: float) -> Image.Image:
        W, H = self.W, self.H
        cw, ch = self.canvas.size
        z = 1.0 + ZOOM * k
        fx, fy = self.focus
        x0, y0 = fx * (1 - 1 / z), fy * (1 - 1 / z)
        sx, sy = cw / W / z, ch / H / z
        bg = self.canvas.transform((W, H), Image.AFFINE, (sx, 0, x0, 0, sy, y0), resample=Image.BILINEAR).convert("RGBA")
        if self.glow_pt:
            g = self.glow_at(min(1.0, 0.30 + 0.55 * env + 0.05 * math.sin(ti * 2.1)))
            gx, gy = (self.glow_pt[0] - x0) / sx, (self.glow_pt[1] - y0) / sy
            bg.alpha_composite(g, (int(gx - g.width / 2), int(gy - g.height / 2)))
        boost = 0.8 + 0.4 * env
        for p in self.parts:
            y = (p["y"] + p["vy"] * ti) % (H * 1.1) - H * 0.05
            x = (p["x"] + p["sway"] * math.sin(ti * p["fr"] * 2 + p["ph"])) % W
            s = self.sprite(p["layer"], p["warm"], min(1.0, p["a"] * boost))
            px, py = int(x - s.width / 2), int(y - s.height / 2)
            if -s.width < px < W and -s.height < py < H:
                bg.alpha_composite(s, (max(0, px), max(0, py)), (max(0, -px), max(0, -py)))
        bg.alpha_composite(self.static)
        self.draw_lyrics(bg, t_song)
        d = ImageDraw.Draw(bg)
        tx, bw = self.L["title_x"], 300
        frac = min(1.0, max(0.0, t_song / max(1.0, self.total)))
        d.line((tx, self.bar_y, tx + bw, self.bar_y), fill=(255, 255, 255, 70), width=3)
        d.line((tx, self.bar_y, tx + int(bw * frac), self.bar_y), fill=GOLD + (235,), width=3)
        d.text((tx + bw + 16, self.bar_y - 13), f"{fmt(t_song)} / {fmt(self.total)}", font=self.small, fill=(230, 226, 215, 150))
        return bg.convert("RGB")

    def draw_lyrics(self, bg: Image.Image, t: float) -> None:
        W, LY, NG = self.W, self.L["lyric_y"], self.L["next_gap"]
        cur = None
        for i, ln in enumerate(self.lines):
            if ln["start"] - 0.25 <= t < ln["show_end"]:
                cur = i
        if cur is None:        # 간주: 곧 부를 줄을 흐리게 미리
            nxt = next((i for i, ln in enumerate(self.lines) if 0 < ln["start"] - t <= 2.5), None)
            if nxt is not None:
                la = self.line_art(nxt)
                bg.alpha_composite(faded(la.dim, 1 - (self.lines[nxt]["start"] - t) / 2.5), (int(W / 2 - la.w / 2), int(LY - la.h / 2)))
            return
        ln, la = self.lines[cur], self.line_art(cur)
        appear = min(1.0, (t - (ln["start"] - 0.25)) / 0.3)
        k = min(appear, min(1.0, max(0.0, (ln["show_end"] - t) / 0.25)))
        x, y = int(W / 2 - la.w / 2), int(LY - la.h / 2) + int((1 - appear) * 18)
        frac = (t - ln["start"]) / max(0.3, ln["sing_end"] - ln["start"])
        fx = la.fill_x(min(1.0, max(0.0, frac)))
        bg.alpha_composite(faded(la.shadow, k), (x, y + 3))
        bg.alpha_composite(faded(la.dim, k), (x, y))
        bg.alpha_composite(la.clipped("glow", fx + 10, 60, k * 0.9), (x, y))
        bg.alpha_composite(la.clipped("bright", fx, 26, k), (x, y))
        if ln["adlib"] and frac > 0.55:     # 괄호 애드립은 본 줄을 거의 부른 뒤의 메아리
            aw = self.ad_font.getlength(ln["adlib"])
            ka = min(1.0, (frac - 0.55) / 0.15) * k
            ImageDraw.Draw(bg).text((W / 2 - aw / 2, y - 6), ln["adlib"], font=self.ad_font, fill=GOLD + (int(190 * ka),))
        if cur + 1 < len(self.lines):
            nb = self.line_art(cur + 1, small=True)
            bg.alpha_composite(faded(nb.dim, k * 0.9), (int(W / 2 - nb.w / 2), int(LY + NG - nb.h / 2 + 10)))


_ENC_CACHE: dict[str, str] = {}


def _ffmpeg_has_encoder(name: str) -> bool:
    if "list" not in _ENC_CACHE:
        try:
            r = subprocess.run([FF, "-hide_banner", "-encoders"], capture_output=True, text=True, timeout=6)
            _ENC_CACHE["list"] = r.stdout or ""
        except Exception:  # noqa: BLE001
            _ENC_CACHE["list"] = ""
    return f" {name} " in _ENC_CACHE["list"]


def _probe_nvenc() -> bool:
    if "nvenc" in _ENC_CACHE:
        return _ENC_CACHE["nvenc"] == "1"
    ok = False
    if _ffmpeg_has_encoder("h264_nvenc"):
        try:
            r = subprocess.run(
                [FF, "-hide_banner", "-v", "error", "-f", "lavfi", "-i", "color=black:s=128x128:d=0.1",
                 "-c:v", "h264_nvenc", "-f", "null", "-"],
                capture_output=True, text=True, timeout=5,
            )
            ok = r.returncode == 0
        except Exception:  # noqa: BLE001
            ok = False
    _ENC_CACHE["nvenc"] = "1" if ok else "0"
    return ok


def pick_vcodec(dur: float) -> list[str]:
    """H.264 인코더 자동 선택(SUNO_FFMPEG_ENC=auto|nvenc|qsv|cpu).
    - NVIDIA GPU(h264_nvenc): 초기화 지연 없이 전 구간 초고속 가속.
    - Intel Arc(h264_qsv): 실측 초기화 지연(~74초)이 있어 90초 이상 풀영상(또는 SUNO_FFMPEG_ENC=qsv 지정 시)에만 사용.
    - CPU 폴백: libx264 -preset fast (기존 medium 대비 인코딩 속도 개선)."""
    want = (os.environ.get("SUNO_FFMPEG_ENC") or "auto").strip().lower()
    if want == "nvenc" or (want == "auto" and _probe_nvenc()):
        return ["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "18", "-pix_fmt", "yuv420p"]
    if want == "qsv" or (want == "auto" and dur >= 90.0 and _ffmpeg_has_encoder("h264_qsv")):
        return ["-c:v", "h264_qsv", "-preset", "medium", "-global_quality", "18", "-look_ahead", "0", "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "fast", "-crf", "17", "-pix_fmt", "yuv420p"]


# ── 실행 ─────────────────────────────────────────────────────────────────
def render_chunk(a, total: float, i0: int, i1: int, out: str, dur: float) -> None:
    """프레임 i0..i1-1 을 그려 영상 조각(소리 없음)으로."""
    r = Renderer(a, total)
    env = envelope(a.audio, a.start, dur)
    vcodec = pick_vcodec(dur)
    cmd = [FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{r.W}x{r.H}", "-r", str(FPS), "-i", "-",
           *vcodec, out]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(i0, i1):
        ti = i / FPS
        proc.stdin.write(r.frame(a.start + ti, ti / dur, float(env[min(i, len(env) - 1)]), ti).tobytes())
    proc.stdin.close()
    if proc.wait() != 0:
        if "h264_qsv" in vcodec or "h264_nvenc" in vcodec:
            # 하드웨어 인코딩 실패 시 CPU libx264로 자동 재시도
            r2 = Renderer(a, total)
            cmd2 = [FF, "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{r2.W}x{r2.H}", "-r", str(FPS), "-i", "-",
                    "-c:v", "libx264", "-preset", "fast", "-crf", "17", "-pix_fmt", "yuv420p", out]
            proc2 = subprocess.Popen(cmd2, stdin=subprocess.PIPE)
            for i in range(i0, i1):
                ti = i / FPS
                proc2.stdin.write(r2.frame(a.start + ti, ti / dur, float(env[min(i, len(env) - 1)]), ti).tobytes())
            proc2.stdin.close()
            if proc2.wait() == 0:
                return
        raise SystemExit(f"조각 인코딩 실패: {out}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--audio", required=True)
    ap.add_argument("--lines", required=True)
    ap.add_argument("--md")
    ap.add_argument("--title", required=True)
    ap.add_argument("--handle", default="@찰스뮤직")
    ap.add_argument("--out", required=True)
    ap.add_argument("--landscape", action="store_true", help="가로 1920x1080(유튜브 풀 영상)")
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float)
    ap.add_argument("--fade", type=float, default=0.0, help="구간 앞뒤 소리 페이드(초) — 릴스·스토리 0.25")
    ap.add_argument("--art-cut", type=float, default=1.0, help="그림에서 쓸 위쪽 비율(아래를 버린다)")
    ap.add_argument("--glow", help="빛을 둘 곳(그림 비율 좌표 x,y), 예: 0.28,0.246")
    ap.add_argument("--stills", help="쉼표로 구분한 곡 시각(초) — 정지 화면 PNG 만 뽑는다")
    ap.add_argument("--workers", type=int, default=max(1, min(6, (os.cpu_count() or 4) // 3)))
    ap.add_argument("--chunk", help=argparse.SUPPRESS)          # 내부용: i0:i1:조각파일
    a = ap.parse_args()
    total = duration(a.audio)
    end = a.end if a.end else total
    dur = max(0.5, end - a.start)
    n = int(round(dur * FPS))
    if a.chunk:
        i0, i1, out = a.chunk.split(":", 2)
        render_chunk(a, total, int(i0), int(i1), out, dur)
        return 0
    if a.stills:
        r = Renderer(a, total)
        env = envelope(a.audio, 0, total)
        outp = Path(a.out)
        for s in [float(v) for v in a.stills.split(",")]:
            img = r.frame(s, (s - a.start) / dur, float(env[min(int(s * FPS), len(env) - 1)]), s - a.start)
            p = outp.with_name(f"{outp.stem}_still_{s:06.2f}.png")
            img.save(p)
            print(p)
        return 0
    t0 = time.time()
    tmp = Path(tempfile.mkdtemp(prefix="artlyric_"))
    try:
        k = max(1, min(a.workers, n // (FPS * 5) or 1))
        bounds = [round(n * j / k) for j in range(k + 1)]
        me = [sys.executable, "-u", *(["-I"] if sys.flags.isolated else []), str(Path(__file__).resolve())]
        passthru = [x for x in sys.argv[1:]]
        procs = []
        for j in range(k):
            part = tmp / f"part{j:02d}.mp4"
            procs.append((part, subprocess.Popen(me + passthru + ["--chunk", f"{bounds[j]}:{bounds[j + 1]}:{part}"])))
        print(f"{n}프레임을 {k}개로 나눠 그리는 중…", flush=True)
        for part, p in procs:
            if p.wait() != 0 or not part.is_file():
                print(f"조각 실패: {part}")
                return 1
        lst = tmp / "parts.txt"
        lst.write_text("".join(f"file '{p.as_posix()}'\n" for p, _ in procs), encoding="utf-8")
        video = tmp / "video.mp4"
        subprocess.run([FF, "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(lst), "-c", "copy", str(video)], check=True)
        whole = a.start == 0 and not a.end and a.fade <= 0
        tp = true_peak(a.audio, a.start if not whole else 0, None if whole else dur)
        gain = min(0.0, -1.0 - tp)
        if whole and gain == 0:      # 곡 전체·안전한 소리 → 소리는 비트 그대로
            audio_args = ["-map", "1:a:0", "-c:a", "copy"]
            src = ["-i", a.audio]
        else:
            af = [f"volume={gain:.2f}dB"] if gain < 0 else []
            if a.fade > 0:
                af += [f"afade=t=in:st=0:d={a.fade}", f"afade=t=out:st={max(0.0, dur - a.fade):.3f}:d={a.fade}"]
            src = ["-ss", f"{a.start:.3f}", "-t", f"{dur:.3f}", "-i", a.audio]
            audio_args = ["-map", "1:a:0", *(["-af", ",".join(af)] if af else []), "-c:a", "aac", "-b:a", "320k", "-ar", "48000"]
        copy = whole and gain == 0      # 소리 복사일 때 -shortest 를 쓰면 마지막 AAC 패킷(21ms)이 잘려 비트 동일이 깨진다(2026-10-31 실측 12,132/12,133)
        subprocess.run([FF, "-y", "-v", "error", "-i", str(video), *src, "-map", "0:v:0", *audio_args, "-c:v", "copy", *([] if copy else ["-shortest"]), "-movflags", "+faststart", a.out], check=True)
        print(f"완료 {a.out} ({dur:.1f}초, {'소리 복사' if whole and gain == 0 else f'소리 이득 {gain:.2f}dB·AAC 320k'}, {k}개 병렬, {time.time() - t0:.0f}초)")
        return 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
