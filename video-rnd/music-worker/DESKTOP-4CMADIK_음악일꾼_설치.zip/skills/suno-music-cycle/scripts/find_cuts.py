#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""릴스·스토리 컷 구간을 자동으로 찾고, 자른 결과를 검증한다. asr-venv 의 파이썬으로 실행(faster-whisper, numpy).

  python find_cuts.py find   --media 곡.mp4 --md 최종.md [--model small] [--json out.json]
  python find_cuts.py verify --cut reel.mp4 --md 최종.md --kind reel|story

find   : 가사 줄을 음성 인식 결과(단어 시간)에 순서대로 맞춰 후렴1 시작·끝, 후렴2 끝, 브리지 시작을 찾고,
         오디오 에너지의 '숨 고르기 → 타격'으로 박자를 맞춰서 make-reel 명령에 넣을 값을 출력한다.
verify : 자른 영상을 다시 전사해 첫 줄이 후렴 첫 줄인지, 끝 줄이 후렴 마지막 줄인지, 브리지(릴스)·2절(스토리)가 섞이지 않았는지 확인한다.
음성 인식 시간은 노래에서 ±1초 어긋나므로 에너지 타격(±1.3초 안)으로 보정한다. 보정 실패 시 인식 시간을 그대로 쓰고 표시한다.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
import wave
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import quality_check as qc  # noqa: E402  (jamo, ratio, read_lyrics, tool)

sys.stdout.reconfigure(encoding="utf-8")


def transcribe_words(media: str, model_name: str, prompt: str | None = None, chunk: float = 36.0,
                     _cache: dict = {}) -> list[tuple[str, float, float]]:
    key = (media, model_name)
    if key not in _cache:   # 모델·오디오는 한 번만 읽는다. 조각은 동시에 전사한다(qc.make_model — 같은 결과, 시간만 줄어든다).
        _cache.clear()
        _cache[key] = (qc.make_model(model_name), qc.load_audio_16k(media))
    model, audio = _cache[key]
    # 조각 전사(중간 누락 방지) + temperature=0.0(재현성).
    # initial_prompt: 가사를 힌트로 줘서 반복 후렴을 덜 놓치게 한다. 구간 찾기 전용이다(품질 채점에는 쓰지 않는다. 힌트가 점수를 부풀린다).
    return qc.chunk_transcribe(model, audio, words=True, prompt=prompt, chunk=chunk)


def char_timeline(words: list[tuple[str, float, float]]) -> tuple[str, list[float]]:
    """자모 문자열과 문자별 시간(단어 구간 안에서 선형 보간)."""
    chars: list[str] = []
    times: list[float] = []
    for text, t0, t1 in words:
        j = qc.jamo(text)
        n = len(j)
        for k, ch in enumerate(j):
            chars.append(ch)
            times.append(t0 + (t1 - t0) * (k / max(1, n)))
    return "".join(chars), times


def align(sections, asr_j: str, times: list[float], start_pos: int = 0, min_ratio: float = 0.55):
    """가사 줄을 순서대로 인식 결과에 맞춘다(앞으로만 진행). 결과: {(섹션 번호, 줄 번호): (시작, 끝, 유사도)}"""
    import bisect
    out: dict[tuple[int, int], tuple[float, float, float]] = {}
    pos = start_pos
    prev_end = 0.0
    missed = 0
    for si, (_, lines) in enumerate(sections):
        for li, line in enumerate(lines):
            tj = qc.jamo(line)
            n = len(tj)
            if n == 0:
                continue
            # 다음 줄은 앞 줄이 끝난 뒤 일정 시간 안에 나온다(놓친 줄이 있으면 창을 넓힌다). 반복 후렴이 뒤쪽과 짝지어지는 것을 막는다.
            lo = max(pos - 4, bisect.bisect_left(times, prev_end - 1.5))
            hi = min(len(asr_j), bisect.bisect_right(times, prev_end + 14.0 + 8.0 * missed))
            cands: list[tuple[int, int, float]] = []  # (시작, 길이, 유사도)
            for w in sorted({max(1, int(n * 0.85)), n, int(n * 1.25)}):
                for i in range(lo, max(lo + 1, hi - w + 1)):
                    cands.append((i, w, qc.ratio(asr_j[i:i + w], tj)))
            top = max((c[2] for c in cands), default=0.0)
            if top < min_ratio:
                missed += 1
                continue
            # 최고 유사도에 가까운 후보 중 가장 앞의 것
            bi, bw, best = min((c for c in cands if c[2] >= top - 0.06), key=lambda c: (c[0], -c[2]))
            end_i = min(len(times) - 1, bi + bw - 1)
            out[(si, li)] = (times[bi], times[end_i], best)
            pos = bi + bw
            prev_end = times[end_i]
            missed = 0
    return out


def rms_series(media: str) -> list[tuple[float, float]]:
    r = subprocess.run([qc.tool("ffmpeg"), "-hide_banner", "-nostats", "-v", "error", "-i", media, "-vn", "-af",
                        "asetnsamples=n=11025:p=0,astats=metadata=1:reset=1,ametadata=print:key=lavfi.astats.Overall.RMS_level:file=-",
                        "-f", "null", "-"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    rows, pt = [], 0.0
    for line in r.stdout.splitlines():
        m = re.search(r"pts_time:([\d.]+)", line)
        if m:
            pt = float(m.group(1))
            continue
        m = re.search(r"RMS_level=(\S+)", line)
        if m:
            v = -90.0 if m.group(1) == "-inf" else float(m.group(1))
            rows.append((pt, v))
    return rows


def snap_hit(rms: list[tuple[float, float]], t: float, span: float = 1.3) -> tuple[float, bool]:
    """t 근처에서 '숨 고르기(저에너지) 직후의 강한 타격' 시각. 못 찾으면 (t, False)."""
    best, best_t = 0.0, None
    for i, (ti, db) in enumerate(rms):
        if not (t - span <= ti <= t + span) or i < 4:
            continue
        prev_min = min(v for _, v in rms[i - 4:i])
        contrast = db - prev_min
        if contrast >= 5 and db >= -17 and contrast > best:
            best, best_t = contrast, ti
    return (best_t, True) if best_t is not None else (t, False)


def snap_dip(rms: list[tuple[float, float]], t: float, lo: float = -0.2, hi: float = 1.8) -> tuple[float, bool]:
    """후렴이 끝난 뒤 에너지가 처음 떨어지는 시각(다음 섹션 직전). 못 찾으면 (t + 0.35, False)."""
    for i, (ti, db) in enumerate(rms):
        if t + lo <= ti <= t + hi and i >= 4:
            base = sum(v for _, v in rms[i - 4:i]) / 4
            if db <= -20 and db <= base - 4:
                return ti, True
    return t + 0.35, False


MAX_REEL = 90.0


def find(a) -> int:
    sections, _ = qc.read_lyrics(Path(a.md))
    names0 = [n.lower() for n, _ in sections]
    ch0 = next((i for i, n in enumerate(names0) if "chorus" in n and "pre" not in n and "final" not in n), None)
    prompt = " ".join(sections[ch0][1]) if ch0 is not None else None
    # 음성 인식은 방식에 따라 구간을 통째로 놓친다(힌트가 있을 때 2차 후렴 누락, 없을 때 반복 후렴 누락 등).
    # 세 방식을 시도해서 가장 많은 줄이 정렬되는 결과를 쓴다. 95% 이상 정렬되면 거기서 멈춘다.
    total_lines = sum(len(l) for _, l in sections)
    best = None
    for label, pr, ck in (("힌트 없음 36초", None, 36.0), ("가사 힌트 36초", prompt, 36.0), ("힌트 없음 24초", None, 24.0)):
        words = transcribe_words(a.media, a.model, pr, ck)
        aj, tm = char_timeline(words)
        cand = align(sections, aj, tm)
        print(f"[전사 방식] {label}: {len(cand)}/{total_lines}줄 정렬")
        if best is None or len(cand) > len(best[0]):
            best = (cand, aj, tm, label)
        if len(cand) >= 0.95 * total_lines:
            break
    al, asr_j, times, used = best
    print(f"[사용] {used}")
    rms = rms_series(a.media)

    names = [n.lower() for n, _ in sections]
    ch = [i for i, n in enumerate(names) if "chorus" in n and "pre" not in n and "final" not in n]
    br = next((i for i, n in enumerate(names) if "bridge" in n), None)
    if len(ch) < 2 or br is None:
        print("후렴 2개와 브리지를 가사에서 찾지 못했습니다")
        return 1

    def first(si):
        k = [(li, v) for (s, li), v in al.items() if s == si]
        return min(k)[1] if k else None

    def last(si):
        k = [(li, v) for (s, li), v in al.items() if s == si]
        return max(k)[1] if k else None

    c1s, c2e, brs = first(ch[0]), last(ch[1]), first(br)
    v2s = first(ch[0] + 1)
    # 후렴1 끝: 마지막 줄이 인식됐으면 그 끝, 놓쳤으면 2절 첫 줄 시작에서 역산(없으면 마지막으로 인식된 줄 + 3초)
    last_li = len(sections[ch[0]][1]) - 1
    if (ch[0], last_li) in al:
        c1e = al[(ch[0], last_li)]
    elif v2s is not None:
        c1e = (v2s[0] - 0.8, v2s[0] - 0.6, 0.0)
        print("[주의] 후렴1 마지막 줄을 못 찾아 2절 시작에서 역산했습니다")
    else:
        lw = last(ch[0])
        c1e = (lw[1], lw[1] + 3.0, 0.0) if lw else None
    v1i = next((i for i, n in enumerate(names) if n.startswith("verse")), None)
    v1s, v1e = (first(v1i), last(v1i)) if v1i is not None else (None, None)
    miss = [n for n, v in (("후렴1 시작", c1s), ("후렴1 끝", c1e), ("후렴2 끝", c2e), ("브리지 시작", brs)) if v is None]
    if miss:
        print("정렬 실패: " + ", ".join(miss) + " — 가사 인식이 약합니다. quality_check 결과를 먼저 확인하세요.")
        return 1

    hit_s, ok_s = snap_hit(rms, c1s[0])
    hit_b, ok_b = snap_hit(rms, brs[0])
    reel_start = round(hit_s - 0.10, 2) if ok_s else round(c1s[0] - 0.3, 2)
    reel_end = round(hit_b - 0.08, 2) if ok_b else round(brs[0] - 0.5, 2)   # 타격을 못 찾으면 인식 오차(±1초)를 고려해 더 일찍 끊는다
    # 느린 곡은 `후렴1~후렴2`가 90초를 넘는다(2026-10-17, 75 BPM 발라드 94초). 후렴2의 줄 끝 중 90초 안에 들어오는 가장 뒤쪽 줄에서 끊는다.
    trim_line = None
    if reel_end - reel_start > MAX_REEL:
        n2 = len(sections[ch[1]][1])
        cand = [(li, al[(ch[1], li)]) for li in range(n2) if (ch[1], li) in al and al[(ch[1], li)][1] <= reel_start + MAX_REEL - 0.8]
        if cand:
            li, v = max(cand)
            dip_e, ok_e = snap_dip(rms, v[1])
            reel_end = round(min(reel_start + MAX_REEL - 0.2, (dip_e + 0.05) if ok_e else (v[1] + 0.35)), 2)
            trim_line = li
    dip_t, ok_d = snap_dip(rms, c1e[1])
    story_end = round(dip_t + 0.05, 2) if ok_d else round(c1e[1] + 0.35, 2)
    info = {
        "chorus1_start_asr": round(c1s[0], 2), "chorus1_start_hit": round(hit_s, 2), "hit_start_found": ok_s,
        "chorus1_end_asr": round(c1e[1], 2), "verse2_start_asr": round(v2s[0], 2) if v2s else None,
        "chorus2_end_asr": round(c2e[1], 2), "bridge_start_asr": round(brs[0], 2),
        "bridge_start_hit": round(hit_b, 2), "hit_bridge_found": ok_b,
        "reel": {"start": reel_start, "end": reel_end, "duration": round(reel_end - reel_start, 2), "last_chorus_line": trim_line},
        "story": {"start": reel_start, "end": story_end, "duration": round(story_end - reel_start, 2)},
        "aligned_lines": f"{len(al)}/{sum(len(l) for _, l in sections)}",
        # 목소리 점검(voice_check.py)이 1절과 후렴1을 비교할 때 쓴다
        "verse1": {"start": round(v1s[0], 2), "end": round(v1e[1], 2)} if v1s and v1e else None,
        "chorus1": {"start": round(c1s[0], 2), "end": round(c1e[1], 2)},
    }
    print(json.dumps(info, ensure_ascii=False, indent=1))
    warn = []
    if not ok_s:
        warn.append("후렴1 시작의 에너지 타격을 못 찾아 음성 인식 시간을 썼습니다(±1초 오차 가능)")
    if not ok_b:
        warn.append("브리지 시작의 에너지 타격을 못 찾아 음성 인식 시간을 썼습니다")
    if not ok_d:
        warn.append("후렴1 끝의 에너지 하락을 못 찾아 음성 인식 끝 + 0.35초를 썼습니다")
    if trim_line is not None:
        warn.append(f"릴스를 90초에 맞추려고 후렴2의 {trim_line + 1}번째 줄까지만 쓴다(마지막 줄 앞에서 끊음). verify 에 --cuts-json 을 준다")
    if info["reel"]["duration"] > 90:
        warn.append(f"릴스가 90초를 넘습니다({info['reel']['duration']}초)")
    if info["story"]["duration"] > 60:
        warn.append(f"스토리가 60초를 넘습니다({info['story']['duration']}초)")
    for w in warn:
        print("[주의]", w)
    print("\nmake-reel 인자:")
    print(f"  릴스   --start {reel_start} --end {reel_end} --fade 0.25")
    print(f"  스토리 --start {reel_start} --end {story_end} --fade 0.25")
    if a.json:
        Path(a.json).write_text(json.dumps(info, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


def verify(a) -> int:
    sections, _ = qc.read_lyrics(Path(a.md))
    names = [n.lower() for n, _ in sections]
    ch = [i for i, n in enumerate(names) if "chorus" in n and "pre" not in n and "final" not in n]
    br = next((i for i, n in enumerate(names) if "bridge" in n), None)
    words = transcribe_words(a.cut, a.model)
    asr_j, times = char_timeline(words)
    dur = qc.probe_duration(a.cut)
    c1 = sections[ch[0]][1]
    last_chorus = sections[ch[1]][1] if a.kind == "reel" else sections[ch[0]][1]
    after = (sections[br][1] if a.kind == "reel" else sections[ch[0] + 1][1])[0]
    trim = None
    if a.kind == "reel" and getattr(a, "cuts_json", None):
        trim = ((json.loads(Path(a.cuts_json).read_text(encoding="utf-8")).get("reel")) or {}).get("last_chorus_line")
    if trim is not None and trim + 1 < len(last_chorus):   # 90초에 맞추려고 후렴2 중간 줄에서 끊은 릴스
        after = last_chorus[trim + 1]
        last_chorus = last_chorus[: trim + 1]

    def best_at(window_j: str, line: str) -> float:
        tj = qc.jamo(line)
        return qc.best_window(window_j, tj)[0] if window_j else 0.0

    head_j = "".join(c for c, t in zip(asr_j, times) if t <= 3.0)
    tail_j = "".join(c for c, t in zip(asr_j, times) if t >= dur - 4.0)
    pre_last = sections[ch[0] - 1][1][-1] if ch[0] > 0 and sections[ch[0] - 1][1] else None
    first_ok = best_at(head_j, c1[0]) >= 0.6
    first_clean = (best_at("".join(c for c, t in zip(asr_j, times) if t <= 1.0), pre_last) < 0.7) if pre_last else True
    last_ok = best_at(tail_j, last_chorus[-1]) >= 0.6
    clean_end = best_at(tail_j, after) < 0.7
    for ok, name in ((first_ok, "첫 3초에 후렴 첫 줄이 들린다"), (first_clean, "첫 1초에 앞 섹션(프리코러스) 끝 줄이 섞이지 않았다"),
                     (last_ok, "마지막 4초에 후렴 마지막 줄이 들린다"),
                     (clean_end, "끝에 다음 섹션(" + ("브리지" if a.kind == "reel" else "2절") + ") 첫 줄이 섞이지 않았다")):
        print(f"[{'통과' if ok else '실패'}] {name}")
    return 0 if all((first_ok, first_clean, last_ok, clean_end)) else 1


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("find")
    f.add_argument("--media", required=True)
    f.add_argument("--md", required=True)
    f.add_argument("--model", default="small")
    f.add_argument("--json")
    f.set_defaults(fn=find)
    v = sub.add_parser("verify")
    v.add_argument("--cut", required=True)
    v.add_argument("--md", required=True)
    v.add_argument("--kind", choices=["reel", "story"], required=True)
    v.add_argument("--model", default="small")
    v.add_argument("--cuts-json", help="find 의 JSON. 릴스를 후렴2 중간에서 끊었으면 그 줄을 마지막 줄로 본다")
    v.set_defaults(fn=verify)
    a = ap.parse_args()
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
