#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""다운로드한 곡의 품질을 숫자로 채점한다 (음성 인식 + ffmpeg). 사람이 듣지 못해도 쓸 수 있는 1차 관문.

  asr-venv 의 파이썬으로 실행한다 (faster-whisper, numpy 필요):
  python quality_check.py --media 곡.mp4 --md 날짜_제목_최종.md [--model small] [--json out.json]

측정: 길이, 음량(LUFS/true peak/LRA), 앞뒤 무음, 가사 인식률(줄 단위·자모 유사도), 훅 청취 횟수, 섹션별 인식률.
판정은 통과/주의/실패. 실패가 있으면 종료 코드 1 (재생성 판단 근거).
인식률은 '사람이 알아듣는 정도'의 근사치다. 노래라 인식이 흔들리므로 절대값보다 곡끼리 비교와 임계값 아래 여부를 본다.
"""
from __future__ import annotations

import argparse
import difflib
import glob
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

# ---- 임계값 (곡 2개 보정, 2026-10-16). 바꾸면 SKILL.md 의 값도 함께 갱신한다.
# 대조군 실험: 정답 가사는 줄 인식률 96~97%(기준 0.7), 평균 유사도 0.91~0.94.
#              다른 곡의 가사로 채점하면 줄 인식률 0%, 평균 유사도 0.47~0.49. (기준 0.5는 대조군도 27~48% 통과해서 쓰지 않는다)
MIN_DURATION = 120.0        # 초. 90 미만이면 실패
LINE_MATCH = 0.70           # 한 줄이 '인식됨'이 되는 자모 유사도
LINE_HIT_FAIL = 0.60        # 줄 인식률이 이 값 미만이면 실패
LINE_HIT_WARN = 0.80        # 이 값 미만이면 주의
SIM_FAIL = 0.65             # 평균 최고 유사도
SIM_WARN = 0.80
HOOK_RATIO_WARN = 0.6       # 훅 청취 횟수 / 가사 속 훅 줄 수
HOOK_MATCH = 0.60


def tool(name: str) -> str:
    p = shutil.which(name)
    if p:
        return p
    pattern = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WinGet", "Packages",
                           "Gyan.FFmpeg*", "**", "bin", name + ".exe")
    hits = glob.glob(pattern, recursive=True)
    if hits:
        return hits[0]
    sys.exit(f"{name} 를 찾을 수 없습니다")


# ---- 한글 자모 분해 (노래 인식 오류가 모음·받침에서 흔해서 음절이 아니라 자모로 비교한다)
CHO = "ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ"
JUNG = "ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ"
JONG = " ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ"
DIGIT_KO = {"0": "영", "1": "일", "2": "이", "3": "삼", "4": "사", "5": "오", "6": "육", "7": "칠", "8": "팔", "9": "구"}
# 시간 표현 "세 시"처럼 고유어 수사는 숫자로 인식되는 경우가 많아 대표 매핑만 둔다
HOUR_KO = {"1": "한", "2": "두", "3": "세", "4": "네", "5": "다섯", "6": "여섯", "7": "일곱", "8": "여덟", "9": "아홉", "10": "열", "11": "열한", "12": "열두"}


def jamo(s: str) -> str:
    s = re.sub(r"(\d{1,2})\s*시", lambda m: HOUR_KO.get(m.group(1), m.group(1)) + "시", s)
    s = re.sub(r"\d", lambda m: DIGIT_KO[m.group(0)], s)
    out = []
    for ch in s:
        o = ord(ch)
        if 0xAC00 <= o <= 0xD7A3:
            o -= 0xAC00
            out.append(CHO[o // 588] + JUNG[(o % 588) // 28] + JONG[o % 28].strip())
    return "".join(out)


def ratio(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a, b, autojunk=False).ratio()


def best_window(text: str, target: str, lo: float = 0.8, hi: float = 1.3) -> tuple[float, int]:
    """text 안에서 target 과 가장 비슷한 구간의 (유사도, 시작 위치)."""
    n = len(target)
    if n == 0 or len(text) == 0:
        return 0.0, 0
    best, pos = 0.0, 0
    for w in sorted({max(1, int(n * lo)), n, int(n * hi)}):
        for i in range(0, max(1, len(text) - w + 1), 2):
            r = ratio(text[i:i + w], target)
            if r > best:
                best, pos = r, i
    return best, pos


# ---- 가사 읽기
def read_lyrics(md: Path) -> tuple[list[tuple[str, list[str]]], str | None]:
    blocks = re.findall(r"```[^\n]*\n(.*?)```", md.read_text(encoding="utf-8"), flags=re.S)
    if len(blocks) < 2:
        sys.exit("최종.md 에서 가사 코드 블록을 찾지 못했습니다")
    sections: list[tuple[str, list[str]]] = []
    for l in blocks[1].splitlines():
        t = l.strip()
        m = re.match(r"^\[([^\]]+)\]$", t)
        if m:
            sections.append((m.group(1), []))
        elif t and sections:
            line = re.sub(r"\([^)]*\)", "", t).strip()
            if line:
                sections[-1][1].append(line)
    flat = [re.sub(r"\s+", "", l) for _, ls in sections for l in ls]
    hook = max(set(flat), key=flat.count) if flat else None
    hook_line = next((l for _, ls in sections for l in ls if re.sub(r"\s+", "", l) == hook), None)
    return sections, hook_line


# ---- 측정
def probe_duration(path: str) -> float:
    out = subprocess.run([tool("ffprobe"), "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", path],
                         capture_output=True, text=True).stdout.strip()
    return float(out)


def loudness(path: str) -> dict:
    r = subprocess.run([tool("ffmpeg"), "-hide_banner", "-nostats", "-i", path, "-vn", "-af",
                        "loudnorm=I=-14:TP=-1.5:LRA=11:print_format=json", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    m = re.search(r"\{[^{}]*\"input_i\"[^{}]*\}", r.stderr, flags=re.S)
    if not m:
        return {}
    j = json.loads(m.group(0))
    return {"lufs": float(j["input_i"]), "true_peak_db": float(j["input_tp"]), "lra": float(j["input_lra"])}


def silences(path: str, dur: float) -> dict:
    r = subprocess.run([tool("ffmpeg"), "-hide_banner", "-nostats", "-i", path, "-vn", "-af",
                        "silencedetect=noise=-45dB:d=0.4", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    starts = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", r.stderr)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", r.stderr)]
    lead = ends[0] if starts and starts[0] < 0.2 and ends else 0.0
    trail = dur - starts[-1] if starts and (len(starts) > len(ends) or (ends and ends[-1] >= dur - 0.3)) else 0.0
    return {"leading_silence": round(lead, 2), "trailing_silence": round(max(0.0, trail), 2)}


def load_audio_16k(media: str):
    import numpy as np
    with tempfile.TemporaryDirectory() as td:
        wav = os.path.join(td, "a.wav")
        subprocess.run([tool("ffmpeg"), "-v", "error", "-y", "-i", media, "-vn", "-ac", "1", "-ar", "16000", wav], check=True)
        with wave.open(wav, "rb") as w:
            return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0


def asr_layout() -> tuple[int, int]:
    """(동시에 전사할 조각 수, 조각 하나가 쓰는 스레드 수).
    조각은 서로 독립이라 동시에 돌려도 시간만 준다. **스레드는 4로 고정한다(CTranslate2 기본값과 같다).** 스레드 수가 다르면 같은 곡도 전사가 달라진다 —
    2026-10-20 같은 곡을 재 보니 스레드 4(작업자 5개·7개)는 예전 순차 결과와 27구간 모두 같았고, 스레드 3(작업자 7개)은 구간 7곳의 글이 달라져
    줄 인식률 70%→62%, 컷 시작이 3.4초 달라졌다(음성 인식은 노래에서 이렇게 흔들린다. 그래서 품질 채점·컷 찾기의 결과가 바뀌지 않게 4로 둔다).
    이 PC(22 논리 코어) 실측: 곡 전체(36초 조각 7개) 순차 약 10~13분 → 작업자 7개×스레드 4 = 4분 19초(작업자 5개 6분 24초). 스레드 16은 오히려 느리다.
    환경변수 SUNO_ASR_WORKERS · SUNO_ASR_THREADS 로 바꾼다. WORKERS=1 이면 예전과 똑같이 순차."""
    cores = os.cpu_count() or 4

    def env_int(name: str, default: int) -> int:
        try:
            return int(os.environ.get(name, "").strip() or default)
        except ValueError:
            return default

    workers = max(1, env_int("SUNO_ASR_WORKERS", max(1, min(8, cores // 3))))
    threads = max(0, env_int("SUNO_ASR_THREADS", 4))
    return workers, threads


def asr_device() -> tuple[str, str]:
    """(device, compute_type) 자동 판정 — NVIDIA GPU(CUDA)가 있으면 자동 가속, 없으면 CPU int8.
    환경변수 SUNO_ASR_DEVICE(auto|cuda|cpu, 기본 auto) · SUNO_ASR_COMPUTE(선택)로 강제 지정 가능."""
    want = (os.environ.get("SUNO_ASR_DEVICE") or "auto").strip().lower()
    comp = (os.environ.get("SUNO_ASR_COMPUTE") or "").strip().lower()
    has_cuda = False
    if want in ("auto", "cuda"):
        try:
            import ctranslate2
            has_cuda = int(ctranslate2.get_cuda_device_count() or 0) > 0
        except Exception:  # noqa: BLE001
            has_cuda = False
    if want == "cuda" or (want == "auto" and has_cuda):
        return "cuda", comp or "float16"
    return "cpu", comp or "int8"


def make_model(model_name: str):
    """faster-whisper 모델(GPU 자동 감지 → 없으면 CPU·int8). GPU는 단일 워커 고속 전사, CPU는 조각 병렬(asr_layout)."""
    from faster_whisper import WhisperModel
    device, compute = asr_device()
    workers, threads = asr_layout()
    if device == "cuda":
        try:
            model = WhisperModel(model_name, device="cuda", compute_type=compute, num_workers=1)
            model.suno_workers = 1
            model.suno_device = "cuda"
            print(f"[ASR] device=cuda compute={compute}", flush=True)
            return model
        except Exception as exc:  # noqa: BLE001 — CUDA 드라이버/cuDNN 미설치 시 안전 폴백
            print(f"[ASR] CUDA 초기화 실패({type(exc).__name__}) → CPU int8 폴백", flush=True)
            device, compute = "cpu", "int8"
    model = WhisperModel(model_name, device="cpu", compute_type=compute, cpu_threads=threads, num_workers=workers)
    model.suno_workers = workers
    model.suno_device = "cpu"
    print(f"[ASR] device=cpu compute={compute} workers={workers} threads={threads}", flush=True)
    return model


class _Seg:
    """18초 창으로 다시 전사한 결과를 원래 조각의 시각으로 옮겨 담는다."""

    def __init__(self, s, off):
        self.start, self.end, self.text = s.start + off, s.end + off, s.text
        self.words = [type("W", (), {"word": w.word, "start": w.start + off, "end": w.end + off}) for w in (s.words or [])]


def chunk_transcribe(model, audio, words: bool = False, prompt: str | None = None, chunk: float = 36.0, overlap: float = 6.0):
    """곡을 조각(기본 36초, 6초 겹침)으로 나눠 따로 전사한다.
    곡 전체를 한 번에 전사하면 음성 인식이 중간 수십 초를 통째로 건너뛰는 경우가 있다(2026-10-16, 56~88초 누락).
    temperature=0.0 으로 무작위 폴백을 끄고, 조각의 겹친 경계는 한쪽만 쓴다. words=True 면 (단어, 시작, 끝), 아니면 (시작, 끝, 문장).
    조각들은 서로 영향을 주지 않아 make_model 로 만든 모델이면 동시에 전사하고(2026-10-20), 합치는 순서는 예전과 같다."""
    from concurrent.futures import ThreadPoolExecutor
    sr = 16000
    dur = len(audio) / sr
    out: list = []

    def degenerate(text: str) -> bool:
        """같은 말이 수십 번 반복되는 환각(예: `흠 흠 흠 …`)인지. 노래가 없는 척하며 30초를 채우는 경우가 있다(2026-10-17)."""
        toks = text.split()
        return (len(toks) >= 8 and len(set(toks)) <= max(2, len(toks) // 8)) or (len(text) > 150 and len(set(text.replace(" ", ""))) < 12)

    def run(a_: int, b_: int):
        segs_, _ = model.transcribe(audio[a_:b_], language="ko", word_timestamps=words, beam_size=5, vad_filter=False,
                                    condition_on_previous_text=False, temperature=0.0, initial_prompt=prompt,
                                    compression_ratio_threshold=None, log_prob_threshold=None, no_speech_threshold=None)
        return list(segs_)

    def one_chunk(t: float):
        a, b = int(t * sr), int(min(dur, t + chunk) * sr)
        segs = run(a, b)
        if any(degenerate(s.text) for s in segs):
            # 환각이 섞인 조각은 18초 창으로 다시 전사한다. 그래도 환각인 창의 결과는 버린다.
            fixed, sub, sub_len, span = [], 0.0, 18.0, (b - a) / sr
            while sub < span - 1.0:
                sa, sb = a + int(sub * sr), min(b, a + int((sub + sub_len) * sr))
                part = run(sa, sb)
                last = sub + sub_len >= span
                if not any(degenerate(s.text) for s in part):
                    for s in part:
                        mid = (s.start + s.end) / 2        # 창 안의 시각
                        if (sub == 0 or mid >= 1.5) and (last or mid < sub_len - 1.5):   # 겹친 3초는 한쪽만
                            fixed.append((sub, s))
                sub += sub_len - 3.0
            segs = [_Seg(s, off) for off, s in fixed]
        return segs

    starts: list[float] = []
    t = 0.0
    while t < dur - 1.0:
        starts.append(t)
        t += chunk - overlap
    workers = max(1, int(getattr(model, "suno_workers", 1)))
    if workers > 1 and len(starts) > 1:
        with ThreadPoolExecutor(max_workers=min(workers, len(starts))) as pool:
            results = list(pool.map(one_chunk, starts))        # 결과는 조각 순서대로
    else:
        results = [one_chunk(t) for t in starts]
    for t, segs in zip(starts, results):
        lo = t + (overlap / 2 if t > 0 else 0.0)
        hi = (t + chunk - overlap / 2) if (t + chunk) < dur else dur + 1.0
        for s in segs:
            if words:
                for w in s.words or []:
                    if lo <= w.start + t < hi:
                        out.append((w.word, w.start + t, w.end + t))
            else:
                mid = (s.start + s.end) / 2 + t
                if lo <= mid < hi:
                    out.append((s.start + t, s.end + t, s.text.strip()))
    return out


def transcribe(media: str, model_name: str) -> list[tuple[float, float, str]]:
    return chunk_transcribe(make_model(model_name), load_audio_16k(media), words=False)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--media", required=True)
    ap.add_argument("--md", required=True)
    ap.add_argument("--model", default="small")
    ap.add_argument("--json")
    ap.add_argument("--min-dur", type=float, default=MIN_DURATION, help="권장 최소 길이(초). 이 값의 75%% 미만이면 실패")
    ap.add_argument("--max-dur", type=float, default=0.0, help="권장 최대 길이(초). 0이면 검사 안 함. 넘으면 주의, 60초 넘게 넘으면 실패")
    a = ap.parse_args()

    dur = probe_duration(a.media)
    loud = loudness(a.media)
    sil = silences(a.media, dur)
    segs = transcribe(a.media, a.model)
    sections, hook_line = read_lyrics(Path(a.md))

    asr_j = jamo("".join(t for _, _, t in segs))
    per_section: list[dict] = []
    line_hits = line_total = 0
    sims: list[float] = []
    for name, lines in sections:
        hits = 0
        for l in lines:
            r, _ = best_window(asr_j, jamo(l))
            sims.append(r)
            line_total += 1
            if r >= LINE_MATCH:
                hits += 1
                line_hits += 1
        per_section.append({"section": name, "lines": len(lines), "recognized": hits})
    line_rate = line_hits / max(1, line_total)
    mean_sim = sum(sims) / max(1, len(sims))

    # 훅 청취 횟수
    hook_found = hook_expected = 0
    if hook_line:
        hj = jamo(hook_line)
        hook_expected = sum(1 for _, ls in sections for l in ls if jamo(l) == hj)
        cands = []
        w = len(hj)
        for i in range(0, max(1, len(asr_j) - w + 1)):
            r = ratio(asr_j[i:i + w], hj)
            if r >= HOOK_MATCH:
                cands.append((r, i))
        taken: list[int] = []
        for r, i in sorted(cands, reverse=True):
            if all(abs(i - j) >= w * 0.8 for j in taken):
                taken.append(i)
        hook_found = len(taken)

    checks: list[tuple[str, str, str]] = []

    def add(level: str, name: str, detail: str = "") -> None:
        checks.append((level, name, detail))

    dur_fail = a.min_dur * 0.75
    dur_level = "실패" if dur < dur_fail else ("주의" if dur < a.min_dur else "통과")
    dur_note = f"{a.min_dur:.0f}초 이상 권장"
    if a.max_dur > 0:
        dur_note = f"{a.min_dur:.0f}~{a.max_dur:.0f}초 권장"
        if dur > a.max_dur + 60:
            dur_level = "실패"
        elif dur > a.max_dur:
            dur_level = "주의"
    add(dur_level, f"곡 길이 {dur:.0f}초", dur_note)
    if loud:
        add("통과" if -18 <= loud["lufs"] <= -8 else "주의", f"음량 {loud['lufs']:.1f} LUFS", "-18~-8 범위")
        add("통과" if loud["true_peak_db"] <= 0.0 else "주의", f"true peak {loud['true_peak_db']:.1f} dBTP", "0 초과는 클리핑 위험")
        add("통과", f"다이내믹 레인지(LRA) {loud['lra']:.1f} LU")
    add("통과" if sil["leading_silence"] <= 2.5 else "주의", f"앞 무음 {sil['leading_silence']}초")
    add("통과" if sil["trailing_silence"] <= 8 else "주의", f"뒤 무음 {sil['trailing_silence']}초")
    add("실패" if line_rate < LINE_HIT_FAIL else ("주의" if line_rate < LINE_HIT_WARN else "통과"),
        f"가사 인식률 {line_rate * 100:.0f}% ({line_hits}/{line_total}줄)", f"실패 {LINE_HIT_FAIL * 100:.0f}% 미만, 주의 {LINE_HIT_WARN * 100:.0f}% 미만")
    add("실패" if mean_sim < SIM_FAIL else ("주의" if mean_sim < SIM_WARN else "통과"),
        f"가사 평균 유사도 {mean_sim:.2f}", f"실패 {SIM_FAIL} 미만, 주의 {SIM_WARN} 미만 (정답 곡 0.91~0.94, 엉뚱한 가사 0.47~0.49)")
    if hook_expected:
        ok = hook_found >= hook_expected * HOOK_RATIO_WARN
        add("통과" if ok else "주의", f"훅 청취 {hook_found}/{hook_expected}회", f"훅: {hook_line}")
    weak = [s for s in per_section if s["lines"] >= 2 and s["recognized"] / s["lines"] < 0.3]
    add("통과" if not weak else "주의", "섹션별 인식 (모든 섹션이 불림)",
        ", ".join(f"{s['section']} {s['recognized']}/{s['lines']}" for s in weak))

    fails = sum(1 for c in checks if c[0] == "실패")
    warns = sum(1 for c in checks if c[0] == "주의")
    for level, name, detail in checks:
        print(f"[{level}] {name}" + (f" — {detail}" if detail else ""))
    print("섹션별: " + ", ".join(f"{s['section']} {s['recognized']}/{s['lines']}" for s in per_section))
    print(f"\n실패 {fails}, 주의 {warns}")
    if a.json:
        Path(a.json).write_text(json.dumps({
            "duration": dur, **loud, **sil, "line_recognition": round(line_rate, 3), "mean_similarity": round(mean_sim, 3),
            "lines": line_total, "hook_found": hook_found, "hook_expected": hook_expected,
            "sections": per_section, "fails": fails, "warns": warns,
            "transcript": [{"start": round(s, 2), "end": round(e, 2), "text": t} for s, e, t in segs],
        }, ensure_ascii=False, indent=1), encoding="utf-8")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
