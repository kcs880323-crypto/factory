#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""목소리 점검(근사치). numpy + ffmpeg 만 쓴다. asr-venv 의 파이썬으로 실행.

  python voice_check.py --media 곡.mp4 --cuts-json 날짜_제목_cuts.json [--expect male|female] [--json out.json]

cuts.json 은 `find_cuts.py find --json` 의 결과(1절·후렴1 구간 포함)다.
재는 것: 1절과 후렴1 구간의 RMS, 스펙트럼 중심, 지배적 피치(F0) 중앙값·P90·P98(자기상관).
판정: ① 성별 일치 추정(1절 F0 중앙값) ② 후렴 도약(고음 훅 추정): 후렴 대비 1절의 P90 피치 차(반음), RMS 차(dB), 스펙트럼 중심 차(Hz).
한계: 믹스에서 잰 값이라 악기(베이스·기타)에 흔들린다. **같은 곡의 1절과 후렴을 비교하는 상대값으로만 본다.**
목소리가 '개성 있는지', 'AI틱한지'는 재지 못한다. 사람이 듣고 판단해야 한다.
"""
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
import wave
import os
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import quality_check as qc  # noqa: E402  (tool)

sys.stdout.reconfigure(encoding="utf-8")
SR = 16000


def load_mono(media: str) -> np.ndarray:
    with tempfile.TemporaryDirectory() as td:
        wav = os.path.join(td, "a.wav")
        subprocess.run([qc.tool("ffmpeg"), "-v", "error", "-y", "-i", media, "-vn", "-ac", "1", "-ar", str(SR), wav], check=True)
        with wave.open(wav, "rb") as w:
            return np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0


def bandpass(x: np.ndarray, lo: float, hi: float) -> np.ndarray:
    X = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    X[(f < lo) | (f > hi)] = 0
    return np.fft.irfft(X, len(x)).astype(np.float32)


def f0_track(x: np.ndarray, fmin: float = 80.0, fmax: float = 1000.0, frame: int = 1024, hop: int = 320) -> list[float]:
    """프레임별 지배적 피치(Hz). 자기상관 최대 피크 대비 85% 이상인 가장 짧은 지연을 골라 옥타브 오류를 줄인다."""
    lag_min, lag_max = int(SR / fmax), int(SR / fmin)
    out: list[float] = []
    win = np.hanning(frame).astype(np.float32)
    for i in range(0, len(x) - frame, hop):
        seg = x[i:i + frame] * win
        e = float(np.dot(seg, seg))
        if e < 1e-4:
            continue
        spec = np.fft.rfft(seg, 2 * frame)
        ac = np.fft.irfft(spec * np.conj(spec))[:lag_max + 2]
        ac = ac / (ac[0] + 1e-9)
        seg_ac = ac[lag_min:lag_max]
        if len(seg_ac) < 3:
            continue
        peak = float(seg_ac.max())
        if peak < 0.45:
            continue
        cand = [k for k in range(1, len(seg_ac) - 1) if seg_ac[k] >= seg_ac[k - 1] and seg_ac[k] >= seg_ac[k + 1] and seg_ac[k] >= 0.85 * peak]
        if not cand:
            continue
        out.append(SR / (lag_min + cand[0]))
    return out


def semis(f: float) -> float:
    return 12 * math.log2(f / 440.0)


def window_stats(x: np.ndarray, vocal_band: np.ndarray, t0: float, t1: float) -> dict:
    a, b = int(t0 * SR), int(t1 * SR)
    seg = x[a:b]
    rms_db = 20 * math.log10(float(np.sqrt(np.mean(seg ** 2))) + 1e-9)
    n = 2048
    mags, freqs = [], np.fft.rfftfreq(n, 1 / SR)
    for i in range(0, len(seg) - n, n // 2):
        mags.append(np.abs(np.fft.rfft(seg[i:i + n] * np.hanning(n))))
    m = np.mean(mags, axis=0) if mags else np.zeros(len(freqs))
    centroid = float(np.sum(freqs * m) / (np.sum(m) + 1e-9))
    f0 = f0_track(vocal_band[a:b])
    if len(f0) < 20:
        return {"rms_db": rms_db, "centroid_hz": centroid, "voiced_frames": len(f0)}
    arr = np.array(f0)
    # 0.24초(12프레임) 이상 유지된 가장 높은 음: 짧게 튀는 값·옥타브 오류에 강한 '고음 포인트'
    k = 12
    peak = float(np.max(np.median(np.lib.stride_tricks.sliding_window_view(arr, k), axis=1))) if len(arr) >= k else float(arr.max())
    return {
        "rms_db": round(rms_db, 2), "centroid_hz": round(centroid, 0), "voiced_frames": len(f0),
        "f0_median_hz": round(float(np.median(arr)), 1),
        "f0_p90_hz": round(float(np.percentile(arr, 90)), 1),
        "peak_sustained_hz": round(peak, 1),
    }




def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--media", required=True)
    ap.add_argument("--cuts-json", required=True)
    ap.add_argument("--expect", choices=["male", "female"])
    ap.add_argument("--json")
    a = ap.parse_args()

    cuts = json.loads(Path(a.cuts_json).read_text(encoding="utf-8"))
    v, c = cuts.get("verse1"), cuts.get("chorus1")
    if not v or not c:
        print("cuts.json 에 verse1/chorus1 구간이 없습니다. find_cuts.py find 를 최신 버전으로 다시 실행하세요")
        return 1
    x = load_mono(a.media)
    vb = bandpass(x, 150, 1800)           # 보컬이 많이 있는 대역
    sv = window_stats(x, vb, v["start"], v["end"])
    sc = window_stats(x, vb, c["start"], c["end"])
    res = {"verse1": sv, "chorus1": sc}
    checks: list[tuple[str, str, str]] = []

    def add(level: str, name: str, detail: str = "") -> None:
        checks.append((level, name, detail))

    # 성별은 판정하지 않는다. 믹스에서 잰 지배적 피치는 베이스·기타·신스에 흔들려서 남녀를 가르지 못한다
    # (2026-10-16 검증: 여성 곡 3개도 1절의 26~42%가 165Hz 아래로 잡혀 남성 곡과 구별되지 않았다).
    # 성별은 Suno 옵션(보컬 성별 버튼)과 스타일의 성별 단어로 지시하고, 실제 목소리는 사람이 귀로 확인한다.
    if "f0_median_hz" in sv:
        want = {"male": "남성", "female": "여성"}.get(a.expect or "", "미지정")
        res["verse_f0_median_hz"] = sv["f0_median_hz"]
        add("주의", f"성별은 이 방법으로 판별할 수 없음 (요청: {want}, 1절 F0 중앙값 {sv['f0_median_hz']}Hz는 참고용)",
            "귀로 확인 필요. 자동 판별은 보컬 분리 모델(Demucs 등)로 보컬만 뽑아야 가능")
    else:
        add("주의", "1절에서 피치를 충분히 못 잡음", f"유성 프레임 {sv.get('voiced_frames')}개")

    d_rms = sc["rms_db"] - sv["rms_db"]
    d_cent = sc["centroid_hz"] - sv["centroid_hz"]
    res["lift"] = {"rms_db": round(d_rms, 2), "centroid_hz": round(d_cent, 0)}
    add("통과" if d_rms >= 1.0 else "주의", f"후렴 음량 도약 {d_rms:+.1f} dB (1절 대비)", "1 dB 이상이면 후렴이 커지는 구조")
    add("통과" if d_cent >= 100 else "주의", f"후렴 밝기 도약 {d_cent:+.0f} Hz (스펙트럼 중심)", "100 Hz 이상이면 후렴이 더 밝다")
    if "f0_p90_hz" in sc and "f0_p90_hz" in sv:
        d90 = semis(sc["f0_p90_hz"]) - semis(sv["f0_p90_hz"])
        dpk = semis(sc["peak_sustained_hz"]) - semis(sv["peak_sustained_hz"])
        res["lift"].update({"p90_semitones": round(d90, 2), "peak_vs_verse_semitones": round(dpk, 2)})
        add("통과" if d90 >= 2.0 else "주의", f"후렴이 더 높게 불림: P90 {d90:+.1f} 반음 (1절 대비)", "+2 반음 이상이면 후렴이 높은 음역으로 올라감")
        # 절대 음높이는 보고하지 않는다: 믹스에서 잰 값은 추정기 상한 근처에서 포화돼 세 곡 모두 같은 값(889Hz)이 나왔다
        add("통과" if dpk >= 3.0 else "주의",
            f"고음 포인트(상대): 후렴의 최고 유지음이 1절의 최고 유지음보다 {dpk:+.1f} 반음",
            "0.24초 이상 유지된 가장 높은 음끼리 비교. +3 반음 이상이면 고음 훅이 있다고 본다. 절대 음높이는 믹스에서 믿을 수 없다")
    for level, name, detail in checks:
        print(f"[{level}] {name}" + (f" — {detail}" if detail else ""))
    print(json.dumps(res, ensure_ascii=False))
    if a.json:
        Path(a.json).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    return 1 if any(c[0] == "실패" for c in checks) else 0


if __name__ == "__main__":
    sys.exit(main())
