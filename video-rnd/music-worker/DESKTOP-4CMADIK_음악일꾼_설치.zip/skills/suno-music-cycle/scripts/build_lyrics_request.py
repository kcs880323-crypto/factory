#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Genspark `suno-lyrics-writer` 스킬에 보낼 짧은 요청문을 만든다 (표준 라이브러리만).

  python build_lyrics_request.py --concept publish/날짜_concept.json [--fix-hook "훅 한 줄"] [--slash] [--out 요청.txt]

0단계(pick_concept.py draw)의 결과 JSON과 곡 이력(voice_state.json)을 읽어 한 줄짜리 요청을 출력한다.
규칙·예시·출력 형식은 Genspark 스킬 쪽에 이미 들어 있어서 요청문은 컨셉 값과 피할 훅만 담는다(약 400~600자).
스킬은 Genspark 화면에서 먼저 골라 둔다(Skills 페이지 → `Skill 선택하기` → suno-lyrics-writer `사용`, 입력창에 칩이 뜸). 이 방식으로 검증했다(2026-10-17, 약 39초).
`--slash` 를 주면 맨 앞에 `/suno-lyrics-writer `를 붙인다(입력창에서 `/`로 스킬을 고르는 방식, 미검증).
줄바꿈 없는 한 줄이라 입력창에 그대로 붙여 넣거나 타이핑해도 중간에 전송되지 않는다.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
HOME = Path(os.environ.get("SUNO_CYCLE_HOME") or Path.home() / ".config" / "suno-cycle")
HOOK_KO = {"belt": "지르는 고음(belt)", "falsetto": "가성으로 올리는 고음(falsetto)", "soar": "두성으로 높게 뻗는 고음(soar)",
           "strain": "목이 살짝 갈라질 만큼 힘준 감정 고음(strained)"}


def build(c: dict, titles: list[str], slash: bool = True, fix_hook: str | None = None) -> str:
    vt = c["vocal_type"]
    if vt == "duet":
        first = next((v for v in c["voices"] if v["id"] == c["lead"]), c["voices"][0])
        names = " + ".join(f"{v['ko']}({v['gender']})" for v in c["voices"])
        vocal = f"듀엣 ({first['gender']} 먼저 시작) {names}"
    else:
        v = c["voices"][0]
        vocal = f"{'여성' if vt == 'female' else '남성'} 솔로 ({v['ko']})"
    parts = [
        f"장르·무드: {c['genre']['ko']} ({c['mood']}), {c['bpm']} BPM",
        f"주제: {c['theme']}",
        f"보컬: {vocal}",
        f"고음 훅: {HOOK_KO.get(c['hook_mode'], c['hook_mode'])}",
        f"스타일 초안: {c['style_draft']}",
    ]
    if c.get("section_tags"):
        parts.append("섹션 태그: " + " ".join(c["section_tags"]))
    if c.get("lyric_rules_short"):
        parts.append("구조 규칙: " + " · ".join(c["lyric_rules_short"]))
    parts.append("작사 품질: 2005-2020 명곡 발라드·팝 기준(보편적 감각·시적 여백·입에 붙는 구어·킬링 후렴)")
    parts.append("절대 금지 클리셰: 신발장·센서등·식은 밥·전자레인지·현관 불빛·반찬통·삼각김밥·달걀 하나")
    if fix_hook:
        parts.append(f"제목·훅 고정: {fix_hook}")
    if titles:
        parts.append("피할 이전 훅·제목: " + ", ".join(titles[-8:]))
    head = "/suno-lyrics-writer " if slash else ""
    return head + " / ".join(parts)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--concept", required=True)
    ap.add_argument("--slash", action="store_true")
    ap.add_argument("--fix-hook", help="제목과 훅을 이 문장으로 고정(재작업할 때)")
    ap.add_argument("--out")
    a = ap.parse_args()
    c = json.loads(Path(a.concept).read_text(encoding="utf-8"))
    state = HOME / "voice_state.json"
    titles = [h["title"] for h in json.loads(state.read_text(encoding="utf-8"))["history"]] if state.exists() else []
    txt = build(c, titles, a.slash, a.fix_hook)
    print(txt)
    if a.out:
        Path(a.out).write_text(txt, encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
