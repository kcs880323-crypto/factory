#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""힙합 스타일1 가사를 Genspark 에게 쓰게 할 요청문을 만든다 (표준 라이브러리만).

  python build_hiphop_request.py --concept publish/날짜_concept.json [--out request.txt]
  (concept.json 은 pick_concept.py draw --preset hiphop1 --json 의 결과)

템플릿: config/saved_styles/hiphop1_genspark_request.txt ({TOPIC} {TWIST} {SCENES} 치환).
사용자 지시 2026-10-18: 힙합 가사는 Genspark 가 쓴다. 주제별 일상 장면(scenes)을 요청문에 넣어 공감대를 높인다.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--concept", required=True)
    ap.add_argument("--out")
    a = ap.parse_args()
    c = json.loads(Path(a.concept).read_text(encoding="utf-8"))
    presets = json.loads((ROOT / "config" / "presets.json").read_text(encoding="utf-8"))
    p = presets[c.get("preset", "hiphop1")]
    th = next((t for t in p["themes"] if t["topic"] == c["theme"]), None)
    scenes = ", ".join(th["scenes"]) if th and th.get("scenes") else "(주제에 맞는 일상 장면을 직접 고르세요)"
    tpl = (ROOT / "config" / "saved_styles" / "hiphop1_genspark_request.txt").read_text(encoding="utf-8")
    text = tpl.replace("{TOPIC}", c["theme"]).replace("{TWIST}", c.get("twist", "")).replace("{SCENES}", scenes)
    if a.out:
        Path(a.out).write_text(text, encoding="utf-8")
        print(f"저장: {a.out} ({len(text)}자)")
    else:
        print(text)


if __name__ == "__main__":
    main()
