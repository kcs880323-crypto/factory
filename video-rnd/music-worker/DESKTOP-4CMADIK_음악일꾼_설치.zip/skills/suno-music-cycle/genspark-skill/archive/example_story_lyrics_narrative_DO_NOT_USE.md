# 모범 가사 (기승전결 + 모티프 + 훅 복선 + 훅 의미 변화) — 스킬 예시용, 곡으로 만들지 않음

```
warm sincere Korean female alto with gentle vibrato and close-mic intimacy, natural breaths, acoustic pop-folk with fingerpicked guitar, soft piano and brushed drums, heartfelt, 96 BPM, clean mix with wide stereo
```

```
[Intro: fingerpicked guitar, soft hum]
(음 음 음)

[Verse 1: soft, intimate]
이삿짐 트럭이 시동을 걸 때까지
엄마는 현관에 서서 안 들어가고
김치 담은 반찬통 세 개를 쥐여 주며
벌써 다 싸놨다고 괜히 큰소리쳐

[Pre-Chorus: drums build]
차 문을 닫기 전에 뭐라 말해야 할지
어제 연습한 말이 하나도 안 나와
고개만 끄덕이다 창문을 올리는데
(다녀올게) 그 한마디가 왜 이렇게 무거워

[Chorus: belted high note, full arrangement]
다녀올게 엄마
백미러에 작아지는 하얀 머리가
다녀올게 엄마
이번엔 울지 않고 웃으면서 갈게

[Verse 2: soft, intimate]
첫날 밤 불 꺼진 원룸 바닥에 앉아
반찬통 뚜껑을 하나씩 열다가
맨 아래 통에 붙은 노란 포스트잇
밥 거르지 마 그리고 미안하다고

[Pre-Chorus: drums build]
불을 끄면 현관 불빛이 자꾸 생각나
엄마도 오늘은 안 자고 있을 텐데
전화기를 들었다 몇 번이고 놓았어
(다녀올게) 그 말이 아직도 입에 남아

[Chorus: belted high note, full arrangement]
다녀올게 엄마
백미러에 작아지던 하얀 머리가
다녀올게 엄마
그래도 오늘은 밥부터 먹을게

[Bridge: stripped back, guitar and voice]
엄마는 한 번도 잘 가라고 안 했어
언제나 다녀오라고만 했었어
그 말은 돌아올 자리를 비워둔다는 뜻
나는 이제야 현관 불을 이해했어

[Final Chorus: belted high note, key change up]
다녀올게 엄마 (다녀올게)
불 켜 둔 현관으로 돌아갈 테니까
다녀올게 엄마 (다녀올게)
주말엔 빈 반찬통 들고 갈게

[Outro: fade out]
다녀올게 엄마
다녀올게 엄마
현관 불은 꺼지지 않았어
```
