# 저장된 목소리 스타일: 허스키 밀착 테너 (보이스 M5)

사용자가 2026-10-17에 직접 준 스타일입니다. "해당 목소리 스타일도 저장해줘" 지시로 저장했고, 곡 6 `네 우산 아직 여기 있어`(피아노 발라드)와 곡 8 `천천히 가도 좋아`(네오 소울 R&B)에서 같은 목소리로 썼습니다.

## 1. 사용자가 붙여 준 원문 (곡 6의 Suno 스타일, 그대로 보존)

```
Emotional piano ballad, piano-led verses with sweeping strings rising through the choruses and a stripped-back piano-and-voice bridge; clean, wide stereo mix with natural room tone; restrained 75 BPM build; Korean male tenor, raspy and gritty with a slightly strained edge, raw expressive phrasing, natural breaths, hushed close-mic intimacy and unprocessed delivery, ‑EDM drop, ‑autotune, ‑robotic vocals
```

- Weirdness 35%
- Style Influence 66%
- Variety Normal
- Max Mode On

## 2. 재사용하는 부분 (장르·BPM과 상관없는 목소리·믹스 부분만 뽑은 것)

| 항목 | 값 |
|---|---|
| 목소리 | `raspy gritty Korean male tenor with a slightly strained edge, raw expressive phrasing and hushed close-mic intimacy` |
| 공통 연기 지시 | `natural breaths` (팔레트 공통 `natural breaths and expressive phrasing`) |
| 믹스 | `clean wide stereo mix with natural room tone` |
| 스타일 제외 | `EDM drop, autotune, robotic vocals` |
| Suno 옵션 | 보컬 성별 남성 / Max 켬 / 기이함 35% / 스타일 영향 66% / 다양성 보통(기본) |
| 고음 훅 | 가성: `falsetto lift on the hook` (곡 8) / 지르기: `belted high note with rasp` (곡 6) |

장르·악기·무드·BPM은 곡마다 바꾼다. 아래가 실제 곡에서 이 목소리를 쓴 방식이다.

- 곡 6 (피아노 발라드 75 BPM): `...Korean male tenor with raw energy and a slightly strained edge, natural breaths and expressive phrasing, emotional piano ballad with sweeping strings and a restrained build, heartbreaking, 75 BPM, clean mix with wide stereo`(M3 표기)
- 곡 8 (네오 소울 88 BPM): `raspy gritty Korean male tenor with a slightly strained edge, raw expressive phrasing and hushed close-mic intimacy, natural breaths, warm modern R&B with Rhodes piano, soft finger snaps and a mellow bass groove, sunny relaxed afternoon, 88 BPM, clean wide stereo mix with natural room tone`

## 3. 불러 쓰는 방법

```
python -u -I scripts/pick_concept.py draw --voice M5 [--genre rnb-neosoul] --json publish/날짜_concept.json
```

`--voice M5`를 주면 성별은 남성 솔로로 고정되고, 스타일 초안의 목소리·믹스가 위 값으로 채워지며, 결과 JSON의 `suno_params`에 슬라이더 값이 들어갑니다. "그 목소리로 만들어줘"라고 하면 이 옵션을 씁니다.

## 4. 주의

- 목소리의 실제 음색은 사람이 들어야 합니다. 이 스타일은 사용자가 곡 6에서 만족해서 저장한 것이고, 같은 글 지시어가 다른 장르에서도 같은 음색을 보장하지는 않습니다.
- 곡 6과 곡 8의 스타일 문구는 완전히 같지 않습니다. 곡 6은 M3 팔레트 표기였고, 곡 8부터 사용자 원문 표현(`hushed close-mic intimacy`, `natural room tone`)을 반영한 M5 표기입니다.
