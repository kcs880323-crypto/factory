# 힙합 스타일1 예시 가사 (린트 시험용 원본 / 구조 참고)

주제 막차를 놓친 밤(비튼 위로). 구조·훅·고음·영어 혼합 규칙을 보여 주는 예시다. 실제 제작은 새 주제·새 가사로 쓴다.

## 스타일 (Suno 스타일 칸, 사용자 원문)

```
Genre/Vibe:
Urban Warm Hip-Hop With High Vocal Hooks, Trap-Influenced Beats, Tight 808 Bass, Minimal Piano Chords, Warm Atmospheric Pads, Male Vocal: Rap Verses (Conversational, Slightly Off-Beat Phrasing) + Soaring High Singing In Chorus (C5-D5 Range, Falsetto/Belt Blend), Night-City Comfort, Unconventional Consolation, Groove With Soul, Instrumentation:
Tight Trap Drums (Crisp Hi-Hats, Punchy Kick, 808 Sub-Bass Slides), Minimal Rhodes Or Electric Piano (Sparse Chord Stabs), Warm Synth Pad (Low In Mix, Ambient), Subtle Guitar Plucks (Occasional Texture), Tambourine (Chorus Lift), Vocal:
Male, Clear-Power Style, Verse: Rap Delivery, Conversational, Unexpected Phrasing, Slight Off-Rhythm Syncopation, Emotional Undertone, Pre-Chorus: Build Tension, Half-Sung/Half-Rap Transition, Chorus: High Note Singing (C5-D5 Falsetto Or Full Voice), Repetitive Hook, Open Resonance, Emotional Release, Layered Doubles, Bridge: Quiet Falsetto Whisper, Final Chorus: Ultimate High Belt/Falsetto Climax
```

## 가사 (Suno 가사 칸)

```
[Intro: ambient city night, soft Rhodes, vocal hum previewing the hook]
(mm, stay with me)

[Verse 1: male rap, conversational, slightly off-beat, low register]
막차 떠난 정류장에 나 혼자야, still
편의점 불빛 하나가 오늘의 친구야
안 읽은 알림만 쌓여, 근데 다 안 궁금해 (okay)
괜찮냐는 말보다 옆자리가 필요해, you know
위로 같은 건 됐어, 그건 너무 뻔하잖아
힘내라는 말 한마디가 오늘은 무거워 (breathe)
그냥 같이 걸어 줘, 아무 말 안 해도 돼
이 밤은 길고, 우린 느려, let it be

[Pre-Chorus: build tension, half-sung half-rap, rising]
괜찮아지지 않아도 돼, 그게 오늘의 정답
무너진 채로 걸어도 넌 아직 걷고 있잖아
한 걸음, 두 걸음
어둠이 깊어질수록 별은 더 또렷해, rise

[Chorus: soaring high singing C5-D5, falsetto and belt blend, layered doubles, tambourine lift, open resonance]
Stay with me, 아직 여기 있어
막차는 가도 밤은 남아
Stay with me, 아직 여기 있어
더 높이 날아올라, 아아아

[Verse 2: male rap, conversational, slightly off-beat, low register]
지하철 유리창에 비친 내 얼굴이 낯설어
웃는 연습을 하다가 그냥 관뒀어, honest
성공한 사람들 얘기는 오늘은 안 들려 (yeah)
나는 그냥 오늘을 살아남은 걸로 충분해
잘 못 한 날도 내 하루야, 지우지 마
실패라고 부르면 그것도 나의 history
어제의 내가 버틴 덕에 오늘이 있잖아 (let it go)
박수는 없어도 돼, I'm still here

[Pre-Chorus: build tension, half-sung half-rap, rising]
위로받지 못해도 돼, 그냥 숨만 쉬어
오늘 밤 이 도시는 너를 안 잊었어
한 걸음, 두 걸음
어둠이 깊어질수록 별은 더 또렷해, rise

[Chorus: soaring high singing C5-D5, falsetto and belt blend, layered doubles, tambourine lift, open resonance]
Stay with me, 아직 여기 있어
막차는 가도 밤은 남아
Stay with me, 아직 여기 있어
더 높이 날아올라, 아아아

[Bridge: quiet falsetto whisper, stripped back, Rhodes only]
작게 말해도 돼
나 오늘 많이 힘들었다고
그 한마디면 충분해 (I know)
내일은 내일의 내가

[Final Chorus: key change up, ultimate high belt and falsetto climax, layered doubles, ad-libs]
Stay with me, 아직 여기 있어
막차는 가도 밤은 남아
Stay with me, 아직 여기 있어
더 높이 날아올라, 아아아
밤은 길어도 우린 여기 있어
Stay with me, 아직 여기 있어

[Outro: half-sung fade, soft hum]
(mm, stay with me)
```

## 옵션

- 보컬 성별: 남성
- 스타일 제외: heavy EDM drop, distorted guitar, screaming
- 기이함 40%, 스타일 영향 65%, 다양성 보통, Max 켬, 길이 커스텀 3:30
