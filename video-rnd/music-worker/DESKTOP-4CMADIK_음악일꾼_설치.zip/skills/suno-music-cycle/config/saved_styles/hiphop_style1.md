# 저장된 스타일: 힙합 스타일1 (hiphop1)

사용자가 2026-10-18에 "일반 음악을 만들 때 Hip-Hop 스타일 하나를 저장해 줘. 내가 **힙합 스타일1로 만들어줘**라고 하면 아래 내용을 적용해 줘"라고 해서 저장했다. 이 스타일은 사용자가 Suno에서 만든 `내 뜻대로`의 스타일이고, `너를 믿어봐`도 참고용이다.

## 부르는 방법

사용자가 `힙합 스타일1로 만들어줘`(또는 `힙합 스타일 1`)라고 하면 **되묻지 않고** 아래로 진행한다.

```
python -u -I scripts/pick_concept.py draw --preset hiphop1 [--theme last-bus] [--compact] --json publish/날짜_concept.json
```

- 주제는 `config/presets.json` 의 10개(막차 놓친 밤, 야근 끝 편의점, 아무것도 못 한 하루 …)에서 최근 5곡을 피해 뽑는다. 사용자가 주제를 말하면 그 주제로 쓴다.
- 기본 스타일은 사용자 원문(995자). `--compact`는 BPM·F minor·Korean 을 명시한 변형(796자).
- 남성 솔로 고정, Suno `보컬 성별`은 남성, 스타일 제외 `heavy EDM drop, distorted guitar, screaming`, 옵션 기이함 40 / 스타일 영향 65 / 다양성 보통 / **Max 켬 / 길이 커스텀 3:30**.
- **가사는 Genspark가 쓴다**(사용자 지시 2026-10-18, 1호곡 가사가 별로라는 평가 뒤). 처음엔 Claude가 직접 썼는데 `공감대가 약하고 훅이 약하다`는 평가를 받았다. 요청문은 스크립트가 만든다: `python -u -I scripts/build_hiphop_request.py --concept publish/날짜_concept.json --out publish/날짜_genspark_request.txt` (템플릿 `config/saved_styles/hiphop1_genspark_request.txt`, 주제별 일상 장면 `presets.json`의 `scenes`). 요청문을 Genspark 대화(스킬 없이)에 붙이면 훅 후보 3개·제목 후보·전체 가사를 코드 블록으로 준다. Claude는 PD로서 공감대(구체적 장면·말투)·훅(한 줄, 따라 부를 수 있는지)·길이(54~60줄)를 검수하고 점검기를 돌린다.
  ```
  python -u -I scripts/lint_lyrics.py --md publish/날짜_제목_최종.md --preset hiphop1
  ```
- 이력에는 장르 `hiphop1`(계열 `hiphop`)로 기록되어 다음 `오늘의 노래` 랜덤 추첨이 힙합 계열을 피한다.

## Suno 스타일 칸 (기본, 사용자 원문 그대로)

```
Genre/Vibe:
Urban Warm Hip-Hop With High Vocal Hooks, Trap-Influenced Beats, Tight 808 Bass, Minimal Piano Chords, Warm Atmospheric Pads, Male Vocal: Rap Verses (Conversational, Slightly Off-Beat Phrasing) + Soaring High Singing In Chorus (C5-D5 Range, Falsetto/Belt Blend), Night-City Comfort, Unconventional Consolation, Groove With Soul, Instrumentation:
Tight Trap Drums (Crisp Hi-Hats, Punchy Kick, 808 Sub-Bass Slides), Minimal Rhodes Or Electric Piano (Sparse Chord Stabs), Warm Synth Pad (Low In Mix, Ambient), Subtle Guitar Plucks (Occasional Texture), Tambourine (Chorus Lift), Vocal:
Male, Clear-Power Style, Verse: Rap Delivery, Conversational, Unexpected Phrasing, Slight Off-Rhythm Syncopation, Emotional Undertone, Pre-Chorus: Build Tension, Half-Sung/Half-Rap Transition, Chorus: High Note Singing (C5-D5 Falsetto Or Full Voice), Repetitive Hook, Open Resonance, Emotional Release, Layered Doubles, Bridge: Quiet Falsetto Whisper, Final Chorus: Ultimate High Belt/Falsetto Climax
```

줄바꿈이 있는 긴 문자열이라 `form_input`으로 스타일 `textarea`에 넣는다(995자, 1000자 한도 안).

## 두 참고곡의 평가와 적용 (사용자 판단 2026-10-18)

| | 내 뜻대로 | 너를 믿어봐 |
|---|---|---|
| 아쉬운 점 | 훅이 약함(같은 어절 반복), 고음 없음 | 훅이 약함(흔한 위로 문구 4줄 동일 무게), 고음 없음 |
| 좋았던 점 | 영어 애드립이 알맞게 들어감, 랩 벌스의 대화체·엇박 | 영어 애드립, 부르기 쉬운 짧은 줄 |
| 공통 원인(내 판단) | 고음 지시를 **가사 줄의 괄호**로 넣었다(`(high note / C5–D5)`, `(higher~)`, `(belt F5/G5)`). 괄호는 불리는 말이라 지시로 작동하지 않는다 | 〃 |

원문은 `config/saved_styles/refs/hiphop1_ref_내뜻대로.md`, `hiphop1_ref_너를믿어봐.md`.

## 가사 규칙 (힙합 스타일1, 점검기가 기계로 확인)

1. **구조(3분 30초)**: `[Intro]`(허밍으로 훅 맛보기) → `[Verse 1: male rap]` 8줄 → `[Pre-Chorus]` 4줄 → `[Chorus]` 4줄 → `[Verse 2]` 8줄 → `[Pre-Chorus]` → `[Chorus]` → `[Bridge: quiet falsetto whisper]` 4줄 → `[Final Chorus]` 6줄 → `[Outro]`.
2. **훅**: 코러스 첫 줄 = 한 줄 훅. 한글 4~7음절 + 쉬운 영어 1~2단어(`Stay with me, 아직 여기 있어`). 첫 줄과 셋째 줄에 같은 훅, 끝 음절은 받침 없는 ㅏ/ㅓ/ㅗ. 같은 어절을 세 번 외치는 반복(`살 거야, 살 거야, 살 거야`)은 쓰지 않는다. 훅 반복 합계 6회 이상.
3. **고음**: 코러스·파이널 코러스 **섹션 태그**에 `soaring high singing C5-D5, falsetto and belt blend, layered doubles, tambourine lift`. 코러스 마지막 줄은 10음절 이하 정점 줄, 열린 모음(아/오)으로 끝낸다(`더 높이 날아올라, 아아아`). **가사 줄에 고음 지시 금지.**
4. **영어**: 전체 노래 줄의 20~30%. 벌스 줄 끝 라임 단어, 프리코러스 끝 한 단어(`rise`), 훅 안의 1~2단어, 괄호 애드립 6~10개(`(yeah)`, `(okay)`, `(breathe)`, `(let it go)`, `(my way)`). 영어 단독 줄 6줄 이하, 어려운 영어 금지.
5. **랩 벌스**: 12~16음절, 대화체, 엇박, 줄 끝 라임. 비튼 위로(`괜찮아지지 않아도 돼`, `위로보다 옆자리`). 뻔한 위로(`힘내`, `괜찮아질 거야`) 그대로는 쓰지 않는다.
6. 따옴표·줄표·숫자·이모지 금지(Suno가 박자를 흘린다. 내 뜻대로에는 `“적당히 해”`, `808`이 있었다).

예시(린트 시험용 원본 가사): `config/saved_styles/refs/hiphop1_example_최종.md`.

## 1호곡 사용자 평가와 점검 (2026-10-18)

사용자 평가: **별로**. ① 가사에 공감대가 부족하다 ② 훅이 약하다 ③ 노래 길이가 기존 곡들처럼 3분대로 안 나오는 느낌 ④ 스타일이 잘 적용됐는지, 목소리가 참고곡과 많이 다른지 점검해 달라.

점검 결과(측정 가능한 것만):
- **스타일 적용: 됐다.** Suno가 이번 곡의 스타일을 이렇게 해석했다(곡 페이지 `Show full styles`): `Warm trap-influenced hip-hop; sparse Rhodes chord stabs, sliding 808 bass, crisp hi-hats, punchy kick, occasional guitar plucks, low ambient synth pads with soft reverb tails, tambourine lifting the chorus ... conversational off-kilter rap verses, rising half-sung pre-chorus, Korean male vocals soaring from C5 to D5 in falsetto-belt blend, stacked hook harmonies and layered octave doubles, quiet falsetto whisper bridge, final chorus climbing to an open high belt, -heavy EDM drop, -distorted guitar, -screaming`. 원문 요소(트랩·808·Rhodes·앰비언트 패드·탬버린·랩 벌스·프리코러스·고음 후렴·속삭임 브릿지·파이널 클라이맥스·제외어)가 모두 들어 있다.
- **목소리·믹스 비교(`compare_songs.py`)**: 음색 코사인 유사도는 새 곡↔내 뜻대로 벌스 0.910 / 후렴 0.936, 새 곡↔너를 믿어봐 0.931 / 0.942로, **참고곡끼리의 기준선(0.903 / 0.935)과 같은 수준**이다. 즉 이 지표로는 `목소리가 크게 다르다`는 것이 확인되지 않는다. 다만 이 지표는 거칠어서(곡끼리 0.90~0.94가 보통) 목소리의 나이·질감·개성 차이는 못 가린다. 아래 차이는 있었다: ① **모델**: 두 참고곡은 **V5**, 새 곡은 **v6**이고 지금 Suno 모델 목록은 `v6 / v6-wild / v6-mini`뿐이라 **V5를 고를 수 없다**. 모델이 다르면 같은 스타일 문구라도 목소리 질감이 달라질 수 있다(이것이 가장 유력한 원인으로 본다). ② 템포: 새 곡 약 99 BPM(검출 199의 절반), 참고곡 약 97·94로 비슷. ③ 스펙트럼: 새 곡이 `내 뜻대로`보다 저음이 +1.9 dB 많고 저중음·중음이 −2.2 dB 적다(보컬 몸통이 덜 두껍게 들릴 수 있음). ④ 후렴 음역: 새 곡은 P90 444 Hz(A4)로 참고곡 후렴(364, 262 Hz)보다 오히려 높다(고음 요청은 반영됨, C5 이상은 4%뿐).
- **길이**: 새 곡 3:34로 설정한 3:35와 맞았다. 참고곡은 도입이 길었다(`내 뜻대로` 약 50초). 새 곡은 노래 줄 44줄로 짧은 편이라 **다음부터는 길이 커스텀 4:00 + 노래 줄 54~60줄(Verse 3 추가)** 로 한다.
- **가사**: 측정으로 못 잰다. 사용자 평가대로 `괜찮은 척` 주제가 추상적이었고 훅 `I'm not fine, 그래도 좋아`가 일상 장면과 이어지지 않았다. → 요청문에 **주제별 일상 장면 5개**와 **훅이 주제 장면과 직접 이어질 것**을 넣었다.
- **음색을 참고곡에 가깝게 하는 방법(시도 예정)**: Suno의 `Inspo`(내 곡 플레이리스트의 소리를 참고해 만드는 기능, Pro)에 참고곡 2개를 담은 플레이리스트를 쓴다.

## 1호곡 시험 결과 (2026-10-18, `안 괜찮아도 좋아`)

주제 `괜찮은 척이 지친 날`(안 괜찮아도 된다고 내가 나에게 허락한다), 훅 `I'm not fine, 그래도 좋아`, 가사 44줄, 점검기 `--preset hiphop1` 실패 0·주의 5(랩 줄 길이·이야기 점검의 힙합 부적합 항목). Suno: 사용자 원문 스타일 995자, 남성, Max 켬, 길이 커스텀 3:35(슬라이더 3:35·기이함 38%·스타일 영향 67%로 맞춰짐), 맨 위 곡 **3:34(213.6초)**.
- **품질 채점**: 인식률 88%(37/42줄), 평균 유사도 0.91, 훅 청취 11/7회, -14.2 LUFS, true peak -0.0(통과).
- **고음 근사 점검(`voice_check.py`)**: 후렴이 1절보다 **+3.9 dB 크고 높은 음역(P90 +7.0반음)** 으로 올라간다. 최고 유지음 비교는 +0.0반음(상한 포화라 판단 불가). **실제 C5~D5 고음이 나오는지는 귀로 확인해야 한다.**
- **컷(릴스 78.3초, 스토리 19.3초)**: 후렴 첫 줄이 **영어 `I'm not` 피크업으로 시작해 박자 타격(58.4초)이 그 뒤에 온다.** `find_cuts`의 시작 58.24초는 피크업을 놓친다. 에너지 바닥(57.2~57.5초)과 단어 시각으로 **57.45초**에 잡았다. 후렴 끝은 `숨 쉬어 높이 날아` 뒤에 **`아아아` 고음 유지(75.0~76.7초)** 가 이어지므로 스토리 끝 76.75초(2절 시작 직전 에너지 바닥), 릴스 끝 135.7초(브릿지 직전 에너지 하락)로 잡았다. `find_cuts`의 135.1초는 고음 유지 중간이라 잘랐을 것이다. **고음 줄이 `아아아`처럼 가사가 없는 음이면 ASR이 못 들어서 `find_cuts verify`의 `마지막 줄` 항목이 실패하고, 컷 머리 5초 전사는 `구독과 좋아요…` 환각이 나온다.** 컷 전체를 전사해(릴스 0초 `I'm not fine 그래도 좋아 웃지 않아도 내 편이야`, 끝 `숨 쉬어 높이 날아`) 확인했다.
- **발행**: 인스타 릴스 https://www.instagram.com/reel/Den-CsnjmXD/ (공개), 스토리, 유튜브 풀·쇼츠 비공개. **하트는 못 눌렀다**(새 브라우저 세션에서 인스타가 로그아웃 상태).

## 주의

- 고음이 실제로 나오는지, 영어 발음이 자연스러운지는 사람이 들어야 한다(`quality_check.py`는 가사 인식률만 잰다). 곡이 나오면 "후렴 정점(C5~D5 고음)이 나오는지 들어 봐 달라"고 안내한다.
- 스타일 원문에는 BPM·Korean 이 없다. 두 참고곡이 한국어로 불렸으므로 원문 그대로 쓰되, 영어 비중이 너무 커지면 `--compact`(Korean 명시)로 바꾼다.

## 2차 시도: Genspark 가사 `월요일 안 왔어` (2026-10-18, 업로드 보류 중)

Genspark(앱 브라우저 창에서 사용자가 로그인, 약 1~2분)가 `build_hiphop_request.py` 요청문으로 훅 후보 3개·제목 후보 3개·가사 56줄을 줬다. 훅 `월요일 안 왔어, not yet`(6음절+영어 2단어, 끝 `어`), 정점 줄 `일요일이 아직 남아아아`. PD 수정 4곳(두 번째 코러스 태그에 고음 지시, 2절 프리코러스 2줄을 자소서 장면으로, 코러스2 둘째 줄 변주, 마지막 줄 10음절로) 후 `lint_lyrics.py --preset hiphop1` 실패 0·주의 2. Suno v6, 4:00 커스텀, 기이함 39 / 스타일 영향 68 / Max / 남성(첫 곡 `cee0aa08`).
측정(1호곡 `안 괜찮아도 좋아` 대비): 길이 **240초**(3:34→4:00), 가사 인식률 92%(48/52줄), 유사도 0.88, 훅 13회, -13.6 LUFS, **후렴 F0 P90 516Hz**(1호곡 444, V5 참고곡 364·262; A4 이상 37%, 3개 후렴 모두 같은 수준), 벌스 음색 코사인 1호곡과 0.982·참고곡 0.92~0.97, 후렴 0.91(1호곡)·0.81~0.86(참고곡: 고음이 더 높아서 달라짐). Suno가 **2절 후렴을 두 번 반복**하고 아웃트로 가사를 `If you're with me, it's all right`로 즉흥으로 바꿨으며 마지막 줄 `월요일은 내일이 알아아`는 잡히지 않았다. 사용자 확인 전까지 업로드하지 않는다.
