#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""병맛 노래 제작: 컨셉 추첨 (표준 라이브러리만 사용).

  python pick_byeongmat.py draw [--theme ID] [--form ID] [--vocal ID] [--seed N] [--json out.json]
  python pick_byeongmat.py commit --title "제목" --concept out.json
  python pick_byeongmat.py history
  python pick_byeongmat.py list

뽑는 것: 소재(일상 공감 주제 + 가상의 신) x 형식(기도문/선포/간증/선창후창) x 보컬 x BPM.
최근 소재 10개·최근 형식 2개는 피한다. 이력은 ~/.config/suno-cycle/byeongmat_state.json (SUNO_CYCLE_HOME 로 위치 변경).
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sys
from datetime import date
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
CFG = json.loads((ROOT / "config" / "themes.json").read_text(encoding="utf-8"))


def state_path() -> Path:
    home = Path(os.environ.get("SUNO_CYCLE_HOME") or (Path.home() / ".config" / "suno-cycle"))
    home.mkdir(parents=True, exist_ok=True)
    return home / "byeongmat_state.json"


def load_state() -> dict:
    p = state_path()
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {"songs": []}


def pick(rng: random.Random, pool: list[dict], recent_ids: list[str], block: int, forced: str | None, label: str) -> dict:
    if forced:
        hit = next((x for x in pool if x["id"] == forced), None)
        if not hit:
            sys.exit(f"{label} '{forced}' 를 찾을 수 없습니다 (list 로 확인)")
        return hit
    blocked = set(recent_ids[-block:]) if block else set()
    cands = [x for x in pool if x["id"] not in blocked] or pool
    return rng.choice(cands)


def josa(word: str, pair: str) -> str:
    """받침 유무로 을/를, 이/가 를 붙인다(마지막 글자가 한글일 때)."""
    ch = word.strip()[-1]
    has_final = (ord(ch) - 0xAC00) % 28 != 0 if "가" <= ch <= "힣" else False
    return word + (pair[0] if has_final else pair[1])


def build(args) -> dict:
    rng = random.Random(args.seed)
    songs = load_state()["songs"]
    theme = pick(rng, CFG["themes"], [s["theme"] for s in songs], CFG["recent_theme_block"], args.theme, "소재")
    form = pick(rng, CFG["forms"], [s["form"] for s in songs], CFG["recent_form_block"], args.form, "형식")
    vocal_pool = CFG["vocals"]
    last_vocals = [s["vocal"] for s in songs][-1:]
    vocal = pick(rng, vocal_pool, last_vocals, 1, args.vocal, "보컬")
    lo, hi = CFG["bpm_range"]
    bpm = rng.randrange(lo, hi + 1, 2)
    style = CFG["style_base"].format(bpm=bpm, vocal=vocal["style"])
    tr = CFG["title_rules"]
    paren_hint = f"{theme['items'][0]} {rng.choice(form['paren_tails'])}"   # 예: 에어컨 간구가
    brief = (
        f"소재: {theme['topic']}\n"
        f"등장시킬 가상의 신: {theme['persona']} (실제 종교의 이름·경전 구절·기도문은 쓰지 않는다)\n"
        f"일상 소품 단어(벌스마다 3개 이상 쓴다): {', '.join(theme['items'])}\n"
        f"형식: {form['name']} - {form['brief']}\n"
        f"보컬: {vocal['name']}\n"
        f"BPM {bpm}\n"
        + f"제목 형식: {tr['format']} — " + tr["main_title"][0] + " 괄호 안은 " + f"`{paren_hint}` 처럼(소재 핵심 단어 + 찬송가 이름). 예시: " + ", ".join(tr["examples"][:3])
    )
    cs = CFG["character_style"]
    chara = (getattr(args, "character", None) or theme.get("character") or "이 곡의 상황에 어울리는 외모·옷차림·표정의 둥근 머리 치비 만화 캐릭터")
    video = (
        f"{josa(chara, '이가')} {josa(theme['prop'], '을를')} 두 손으로 받들고 있다. {theme['visual']}. "
        f"{cs['feel_main'].format(particles=theme.get('particles', '봉투·김·지폐·하트 등'))}. "
        "캐릭터가 박자에 맞춰 두 팔을 올렸다 내렸다 반복한다. 카메라 고정, 장면 전환 없음, 글자와 자막 없음, 소리 없음, "
        "처음과 끝의 자세가 같아서 반복 재생해도 자연스럽게 이어진다. 세로 9:16"
    )
    # 풀 영상 맨 앞 3.8초에 쓰는 임팩 오프닝 클립(5초). 같은 곡의 메인 클립과 같은 캐릭터 문구를 써서 모습을 맞춘다.
    opener = (
        f"{josa(chara, '이가')} 하늘에서 내려오는 눈부신 빛줄기와 번개 속에서 {josa(theme['prop'], '을를')} 두 손으로 번쩍 치켜든다. "
        f"카메라가 빠르게 줌인하며 화면이 번쩍 폭발하고 불꽃과 충격파가 사방으로 퍼진다. {cs['feel_opener']}. "
        "글자와 자막 없음, 소리 없음. 세로 9:16"
    )
    return {
        "drawn_on": date.today().isoformat(),
        "theme": theme["id"], "topic": theme["topic"], "persona": theme["persona"], "items": theme["items"],
        "form": form["id"], "form_name": form["name"], "title_rules": tr, "paren_name_hint": paren_hint,
        "vocal": vocal["id"], "vocal_name": vocal["name"], "suno_vocal_button": vocal["suno_gender"],
        "bpm": bpm,
        "style_draft": style, "style_exclude": CFG["style_exclude"], "suno_params": CFG["suno_params"],
        "lyric_brief": brief, "character": chara, "video_prompt": video, "opener_prompt": opener, "prop": theme["prop"],
        "hashtags": theme["tags"] + ["병맛노래", "병맛", "찬양가", "AI음악", "AIMusic", "shorts"],
    }


def cmd_draw(a) -> None:
    c = build(a)
    print(f"소재   : {c['topic']} (신: {c['persona']})")
    print(f"형식   : {c['form_name']}  /  보컬: {c['vocal_name']}  /  BPM {c['bpm']}")
    print(f"스타일 : {c['style_draft']} ({len(c['style_draft'])}자)")
    print(f"제외   : {c['style_exclude']}")
    print(f"제목   : {c['title_rules']['format']} — " + c["title_rules"]["main_title"][0])
    print(f"          괄호 안 예) {c['paren_name_hint']}  /  전체 예) " + ", ".join(c["title_rules"]["examples"][:3]))
    print(f"Suno 성별 버튼: {c['suno_vocal_button'] or '선택 안 함(듀엣)'}")
    print("\n[가사 요구]\n" + c["lyric_brief"])
    print("\n[Genspark 메인 반복 클립 프롬프트 (9:16, 10초)]\n" + c["video_prompt"])
    print("\n[Genspark 임팩 오프닝 클립 프롬프트 (9:16, 5초)]\n" + c["opener_prompt"])
    if a.json:
        Path(a.json).write_text(json.dumps(c, ensure_ascii=False, indent=1), encoding="utf-8")
        print(f"\n저장: {a.json}")


def cmd_commit(a) -> None:
    c = json.loads(Path(a.concept).read_text(encoding="utf-8"))
    st = load_state()
    st["songs"].append({"title": a.title, "date": date.today().isoformat(), "theme": c["theme"], "form": c["form"],
                        "vocal": c["vocal"], "bpm": c["bpm"]})
    state_path().write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"이력 기록: {a.title} (총 {len(st['songs'])}곡)")


def cmd_history(_a) -> None:
    songs = load_state()["songs"]
    if not songs:
        print("이력 없음")
    for i, s in enumerate(songs, 1):
        print(f"{i}. {s['date']} {s['title']} | {s['theme']} / {s['form']} / {s['vocal']} / {s['bpm']} BPM")


def cmd_list(_a) -> None:
    print("소재: " + ", ".join(t["id"] for t in CFG["themes"]))
    print("형식: " + ", ".join(f"{f['id']}({f['name']})" for f in CFG["forms"]))
    print("보컬: " + ", ".join(f"{v['id']}({v['name']})" for v in CFG["vocals"]))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("draw")
    d.add_argument("--theme")
    d.add_argument("--character", help="이 곡의 캐릭터를 직접 지정(상황에 맞게 구체적으로: 성별·나이·머리·옷차림·표정·자세). 없으면 소재의 character 를 쓴다")
    d.add_argument("--form")
    d.add_argument("--vocal")
    d.add_argument("--seed", type=int)
    d.add_argument("--json")
    d.set_defaults(fn=cmd_draw)
    c = sub.add_parser("commit")
    c.add_argument("--title", required=True)
    c.add_argument("--concept", required=True)
    c.set_defaults(fn=cmd_commit)
    sub.add_parser("history").set_defaults(fn=cmd_history)
    sub.add_parser("list").set_defaults(fn=cmd_list)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
