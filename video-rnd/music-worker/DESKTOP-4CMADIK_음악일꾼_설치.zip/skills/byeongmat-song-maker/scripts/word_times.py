#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""곡의 한 구간을 음성 인식해서 줄·단어 시각을 뽑는다 (컷 경계를 수동 보정할 때 쓴다).

  asr-venv/python -u word_times.py --media 곡.mp3 --start 24 --end 52 --out 병맛/_words.txt

find_cuts.py 가 벌스1을 못 맞추면 후렴1 시작을 1~2초 일찍 잡는다(에어컨 간구가, 2026-10-17: 31.67초로 잡았으나 실제 후렴 첫 줄은 약 33.1초).
단어 시각은 ±0.3초 오차가 있고 줄 첫 단어는 앞 구간까지 늘어나 보일 수 있다. 같은 후렴의 다른 줄에서 '냉풍의' 같은 첫 단어 길이(약 0.8초)를 보고 시작을 정한다.
결과는 UTF-8 파일(--out)로 쓰고 Read 로 읽는다(콘솔 출력은 한글이 깨져 보일 수 있다).
"""
from __future__ import annotations

import os
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(os.environ.get("SUNO_CYCLE_SCRIPTS") or (Path(__file__).resolve().parents[2] / "suno-music-cycle" / "scripts"))))
import quality_check as qc  # noqa: E402
from faster_whisper import WhisperModel  # noqa: E402


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--media", required=True)
    ap.add_argument("--start", type=float, required=True)
    ap.add_argument("--end", type=float, required=True)
    ap.add_argument("--model", default="small")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    audio = qc.load_audio_16k(a.media)
    sr = 16000
    model = WhisperModel(a.model, device="cpu", compute_type="int8")
    seg, _ = model.transcribe(audio[int(a.start * sr):int(a.end * sr)], language="ko", temperature=0.0,
                              condition_on_previous_text=False, word_timestamps=True)
    lines = []
    for s in seg:
        lines.append(f"SEG {s.start + a.start:7.2f}-{s.end + a.start:7.2f}  {s.text.strip()}")
        for w in s.words:
            lines.append(f"      {w.start + a.start:7.2f}-{w.end + a.start:7.2f}  {w.word.strip()}")
    Path(a.out).write_text("\n".join(lines), encoding="utf-8")
    print(f"완료: {a.out} ({len(lines)}줄)")


if __name__ == "__main__":
    main()
