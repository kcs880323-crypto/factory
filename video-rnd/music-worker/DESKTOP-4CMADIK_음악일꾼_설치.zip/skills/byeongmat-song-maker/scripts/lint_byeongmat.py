#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""병맛 노래 제작: Suno 입력 사전 점검 (표준 라이브러리만 사용).

  python lint_byeongmat.py --md 날짜_제목_최종.md [--concept concept.json] [--min-sec 180] [--max-sec 300]

--md 는 첫 번째 코드 블록=스타일, 두 번째 코드 블록=가사 (suno-music-cycle 의 최종.md 와 같은 형식).
실패가 있으면 종료 코드 1. 주의는 사람이 판단한다.
예상 길이는 첫 실곡이 나오기 전까지는 근사치다(줄당 초 = 음절/5, 줄 사이·섹션 사이 간격을 더함). 실곡으로 보정한다.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

TAG_RE = re.compile(r"^\[([^\]]+)\]\s*$")
HANGUL = re.compile(r"[가-힣]")
LATIN = re.compile(r"[A-Za-z]")
# 찬송가 말투 종결. 문장 끝(구두점 제거 후)이 이 중 하나면 '찬송 말투'로 센다.
ARCHAIC = ("하소서", "소서", "리라", "지어다", "나이다", "이로다", "로다", "도다", "리니", "하니", "이오며", "이요", "오며",
           "시니", "나니", "하라", "옵니다", "이니라", "니라", "노라", "도소서", "시옵소서", "지니", "이여", "이시여", "여")
# 실제 종교·경전을 직접 건드리는 말. 가상의 신만 쓴다.
FORBIDDEN = ("아멘", "할렐루야", "예수", "그리스도", "하나님", "하느님", "여호와", "성령", "성경", "성서", "십자가", "부처", "불경", "알라", "코란", "천지창조")
EMOJI = re.compile("[\U0001F300-\U0001FAFF☀-➿]")
QUOTES = "\"'“”‘’「」『』"
DASHES = "-–—~"

results: list[tuple[str, str, str]] = []


def add(level: str, name: str, detail: str = "") -> None:
    results.append((level, name, detail))


def syl(line: str) -> int:
    return len(HANGUL.findall(re.sub(r"\([^)]*\)", "", line)))


def norm(line: str) -> str:
    return re.sub(r"\s+", "", re.sub(r"\([^)]*\)", "", line))


def parse_md(path: Path) -> tuple[str, str]:
    blocks = re.findall(r"```[^\n]*\n(.*?)```", path.read_text(encoding="utf-8"), flags=re.S)
    if len(blocks) < 2:
        sys.exit("최종.md 에서 코드 블록 2개(스타일, 가사)를 찾지 못했습니다")
    return blocks[0].strip(), blocks[1].strip()


def parse_sections(lyrics: str) -> list[dict]:
    secs: list[dict] = []
    for raw in lyrics.splitlines():
        t = raw.strip()
        m = TAG_RE.match(t)
        if m:
            full = m.group(1)
            name = full.split(":")[0].strip().lower()
            secs.append({"tag": full, "name": name, "lines": []})
        elif t:
            if not secs:
                secs.append({"tag": "(태그 없음)", "name": "none", "lines": []})
            secs[-1]["lines"].append(t)
    return secs


def kind(name: str) -> str:
    if "final" in name and "chorus" in name:
        return "final"
    if "pre" in name and "chorus" in name:
        return "pre"
    if "chorus" in name:
        return "chorus"
    for k in ("intro", "outro", "verse", "bridge", "chant", "call", "instrumental", "interlude", "break"):
        if k in name:
            return {"call": "chant", "interlude": "instrumental", "break": "instrumental"}.get(k, k)
    return "other"


def lint_style(style: str) -> None:
    n = len(style)
    add("실패" if n > 1000 else ("통과" if n <= 300 else "주의"), f"스타일 길이 {n}자", "300자 이내 권장, 1000자 초과는 잘림")
    parts = [p.strip() for p in style.split(",") if p.strip()]
    add("통과" if 5 <= len(parts) <= 9 else "주의", f"스타일 항목 {len(parts)}개", "5~8개 권장")
    add("통과" if re.search(r"korean", style, re.I) else "실패", "Korean 보컬 명시")
    add("통과" if re.search(r"choir|gang|chorus", style, re.I) else "주의", "합창(choir/gang) 명시", "찬송가 느낌의 핵심")
    add("통과" if re.search(r"gospel|hymn|anthem", style, re.I) else "주의", "gospel/hymn/anthem 명시")
    m = re.search(r"(\d{2,3})\s*BPM", style, re.I)
    if not m:
        add("실패", "BPM 명시 없음", "빠른 박자감이 요구사항이다")
    else:
        bpm = int(m.group(1))
        add("통과" if 138 <= bpm <= 165 else "주의", f"BPM {bpm}", "138~165 (빠른 박자)")


def lint_lyrics(lyrics: str, min_sec: float, max_sec: float, concept: dict | None) -> None:
    secs = parse_sections(lyrics)
    kinds = [kind(s["name"]) for s in secs]
    add("통과" if 11 <= len(secs) <= 16 else ("주의" if 9 <= len(secs) <= 20 else "실패"), f"섹션 {len(secs)}개", "3~5분을 채우려면 11~16개")
    unknown = [s["tag"] for s, k in zip(secs, kinds) if k == "other" or k == "none"]
    add("통과" if not unknown else "실패", "섹션 태그 인식", ", ".join(unknown))

    all_lines = [l for s in secs for l in s["lines"]]
    sung = [(s, k, l) for s, k in zip(secs, kinds) for l in s["lines"] if k not in ("intro", "outro", "instrumental")]
    total = len(sung)
    add("통과" if 48 <= total <= 90 else ("주의" if 36 <= total <= 110 else "실패"), f"노래 줄 수 {total}줄", "48~90줄 (3~5분 분량)")

    # 후렴(리프레인)
    chorus = [s for s, k in zip(secs, kinds) if k == "chorus"]
    finals = [s for s, k in zip(secs, kinds) if k == "final"]
    add("통과" if len(chorus) >= 3 else "실패", f"[Chorus] {len(chorus)}개 + [Final Chorus] {len(finals)}개", "후렴 3회 + 라스트 1회 이상 (찾기 쉬운 반복이 병맛의 핵심)")
    add("통과" if finals else "주의", "[Final Chorus] 있음")
    refrain: list[str] = []
    if chorus:
        bodies = [tuple(norm(l) for l in s["lines"]) for s in chorus]
        refrain = [l for l in chorus[0]["lines"]]
        same = all(b == bodies[0] for b in bodies)
        add("통과" if same else "실패", "모든 [Chorus] 가사가 글자 그대로 같음", "리프레인은 매번 똑같아야 머리에 박힌다")
        add("통과" if 3 <= len(refrain) <= 5 else "실패", f"리프레인 {len(refrain)}줄", "4줄 권장(3~5)")
        for f in finals:
            ok = bool(f["lines"]) and norm(f["lines"][0]) == bodies[0][0]
            add("통과" if ok else "실패", "[Final Chorus] 첫 줄이 리프레인 첫 줄과 같음")
        hook = refrain[0] if refrain else ""
        h = syl(hook)
        add("통과" if 8 <= h <= 16 else "주의", f"훅(리프레인 첫 줄) {h}음절", hook)
        hn = norm(hook)
        cnt = sum(1 for l in all_lines if norm(l) == hn)
        add("통과" if cnt >= 5 else "실패", f"훅 반복 {cnt}회", "5회 이상")
    uniq = len({norm(l) for _, _, l in sung})
    ratio = uniq / max(1, total)
    add("통과" if ratio <= 0.55 else ("주의" if ratio <= 0.65 else "실패"), f"고유 줄 {uniq}/{total} ({ratio:.0%})", "샘플은 소수의 줄을 반복한다. 55% 이하 권장")
    ch_lines = sum(len(s["lines"]) for s, k in zip(secs, kinds) if k in ("chorus", "final"))
    share = ch_lines / max(1, total)
    add("통과" if share >= 0.35 else ("주의" if share >= 0.25 else "실패"), f"리프레인 비중 {share:.0%}", "35% 이상 권장")

    # 줄 길이
    long_ = [(l, syl(l)) for _, k, l in sung if syl(l) > 24]
    add("통과" if not long_ else "실패", "줄당 24음절 이하", "; ".join(f"{l}({n})" for l, n in long_[:4]))
    body = [syl(l) for _, k, l in sung if k in ("verse", "bridge", "pre")]
    if body:
        avg = sum(body) / len(body)
        add("통과" if 13 <= avg <= 22 else "주의", f"벌스·브릿지 평균 {avg:.1f}음절", "13~22 (찬송 나열체)")
    chant = [syl(l) for _, k, l in sung if k == "chant"]
    if chant:
        add("통과" if max(chant) <= 10 else "주의", f"[Chant] 최대 {max(chant)}음절", "짧은 외침 10음절 이하")
    else:
        add("주의", "[Chant]/콜앤리스폰스 섹션 없음", "임팩트용 짧은 외침 섹션을 한 번은 넣는다")

    # 찬송 말투
    judge = [l for _, k, l in sung if k in ("verse", "bridge", "pre", "chorus", "final")]
    ar = 0
    for l in judge:
        t = re.sub(r"[\s.,!?]+$", "", re.sub(r"\([^)]*\)", "", l).strip())
        if t.endswith(ARCHAIC):
            ar += 1
    rate = ar / max(1, len(judge))
    add("통과" if rate >= 0.6 else ("주의" if rate >= 0.4 else "실패"), f"찬송 말투 종결 {ar}/{len(judge)}줄 ({rate:.0%})", "하소서/리라/지어다/나이다 등. 60% 이상")

    # 금지어·글자
    text = "\n".join(all_lines)   # 섹션 태그(Verse 1 같은 영어·숫자)는 빼고 부르는 가사만 본다
    bad = sorted({w for w in FORBIDDEN if w in text})
    add("통과" if not bad else "실패", "실제 종교·경전 직접 언급 없음", ", ".join(bad))
    add("통과" if not re.search(r"\d", text) else "실패", "아라비아 숫자 없음 (한글로 쓴다)")
    add("통과" if not any(c in text for c in QUOTES + DASHES) and not EMOJI.search(text) else "실패", "따옴표·줄표·물결·이모지 없음")
    eng = [l for l in all_lines if LATIN.search(re.sub(r"\([^)]*\)", "", l)) and HANGUL.search(l)]
    add("통과" if not eng else "주의", "한국어 줄에 영어 없음", "; ".join(eng[:3]))
    shouts = re.findall(r"\(([^)]*)\)", text)
    longs = [x for x in shouts if len(x) > 12]
    add("통과" if not longs else "주의", "괄호는 짧은 외침만 (노래로 불린다)", "; ".join(longs[:3]))
    dirs = [x for x in shouts if re.search(r"반복|코러스|합창|간주|속삭|x2", x)]
    add("통과" if not dirs else "실패", "괄호에 연출 지시어 없음", "; ".join(dirs[:3]))

    # 예상 길이
    sec = 0.0
    for s, k in zip(secs, kinds):
        if k in ("intro", "outro", "instrumental"):
            sec += 8.0
            continue
        for l in s["lines"]:
            sec += max(2.0, syl(l) / 5.0) + 0.4
        sec += 1.5
    lvl = "통과" if min_sec <= sec <= max_sec else ("주의" if min_sec * 0.8 <= sec <= max_sec * 1.2 else "실패")
    add(lvl, f"예상 길이 약 {sec:.0f}초 ({int(sec // 60)}분 {int(sec % 60)}초)", f"목표 {min_sec:.0f}~{max_sec:.0f}초. 근사치(±30%), 실곡으로 보정")

    if concept:
        items = concept.get("items", [])
        hit = [w for w in items if w in lyrics]
        add("통과" if len(hit) >= 4 else "주의", f"소재 소품 단어 {len(hit)}/{len(items)}개 사용", ", ".join(hit))
        persona = concept.get("persona", "")
        add("통과" if persona and persona in lyrics else "주의", "가상의 신 이름이 가사에 등장", persona)


TITLE_TAILS = ("찬가", "찬양가", "기도문", "강림가", "간구가", "은혜송", "송가", "청원가", "선언가", "간증가", "합창가", "응답가", "고행가", "찬송")


def lint_title(md: Path) -> None:
    """최종.md 첫 줄 `# 제목` 검사. 사용자 지시 2026-10-18: `주제목 (소재 + 찬송가 이름)` 형식.
    주제목은 찬송가 꼬리 없이 신선한 구어체, 괄호 안에 `에어컨 간구가` 같은 찬송가식 이름."""
    text = md.read_text(encoding="utf-8").strip()
    first = text.splitlines()[0] if text else ""
    m = re.match(r"^#\s+(.+?)\s*$", first)
    if not m:
        add("주의", "최종.md 첫 줄에 `# 제목`이 없음", "제목 규칙 검사를 건너뜀")
        return
    title = m.group(1)
    pm = re.match(r"^(.*?)\s*\(([^)]*)\)\s*$", title)
    if not pm:
        add("주의", f"제목 `{title}`에 괄호가 없음", "형식은 `주제목 (소재 + 찬송가 이름)` 예: 한 칸만 더 낮춰 주세요 (에어컨 간구가)")
        main, paren = title, ""
    else:
        main, paren = pm.group(1).strip(), pm.group(2).strip()
        has_tail = any(paren.replace(" ", "").endswith(t) for t in TITLE_TAILS)
        add("통과" if has_tail else "주의", f"괄호 안 `{paren}`에 찬송가식 이름", "소재 핵심 단어 + 찬가/찬양가/기도문/강림가/간구가/은혜송 등" if not has_tail else "")
    bad = [t for t in TITLE_TAILS if main.replace(" ", "").endswith(t)]
    add("통과" if not bad else "실패", f"주제목 `{main}`에 찬송가 꼬리 없음",
        ("주제목에는 찬송가 꼬리를 붙이지 않는다(괄호 안에만): " + ", ".join(bad)) if bad else "")
    n = len(main.replace(" ", ""))
    add("통과" if 2 <= n <= 16 else "주의", f"주제목 길이 {n}자", "2~14자 안팎의 짧고 센 문장 권장")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--md", required=True)
    ap.add_argument("--concept")
    ap.add_argument("--min-sec", type=float, default=180.0)
    ap.add_argument("--max-sec", type=float, default=300.0)
    a = ap.parse_args()
    style, lyrics = parse_md(Path(a.md))
    concept = json.loads(Path(a.concept).read_text(encoding="utf-8")) if a.concept else None
    lint_title(Path(a.md))
    lint_style(style)
    lint_lyrics(lyrics, a.min_sec, a.max_sec, concept)
    fails = sum(1 for r in results if r[0] == "실패")
    warns = sum(1 for r in results if r[0] == "주의")
    for level, name, detail in results:
        print(f"[{level}] {name}" + (f" — {detail}" if detail else ""))
    print(f"\n실패 {fails}, 주의 {warns}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
