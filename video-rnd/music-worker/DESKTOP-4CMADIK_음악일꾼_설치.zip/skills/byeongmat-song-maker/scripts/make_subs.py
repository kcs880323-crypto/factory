#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""병맛 스타일 자막(ASS) 만들기: 가사 줄의 시각을 곡에 맞추고(align), 큰 글씨 팝업 자막과 오프닝 연출을 입힌다(ass).

  # 1) 곡에서 가사 줄 시각 찾기 (asr-venv 의 파이썬, 곡당 한 번)
  asr-venv/python -u make_subs.py align --media 곡.mp3 --md 최종.md --json 곡_lines.json
  # 2) ASS 만들기 (venv 어느 쪽이든 됨, 표준 라이브러리만 사용)
  python make_subs.py ass --lines 곡_lines.json --md 최종.md --out full.ass --intro full --title "라면 강림가"
  python make_subs.py ass --lines 곡_lines.json --md 최종.md --out reel.ass --start 33.1 --end 85.4 --intro punch --title "라면 강림가"

스타일(샘플 병맛 영상의 큰 자막을 참고한 것):
- 일반 줄: 흰 글씨 + 굵은 검정 테두리 + 줄마다 바뀌는 형광색 스티커 외곽(분홍·하늘·연두·주황), 소재 소품 단어는 노란색, 줄이 뜰 때 커졌다 줄어드는 팝업.
- 후렴 줄: 노란 글씨 + 빨간 외곽, 더 크게, 좌우로 살짝 기울어 튄다.
- 외침 `(괄호)`: 화면 윗쪽에 아주 크게, 빨강 + 흰 테두리, 부르르 떤다.
- 오프닝(--intro full): 시작 0.07초 뒤 흰색 번쩍(첫 프레임은 흰색이 아니라 장면이 보인다), 제목이 확대되며 쾅 하고 박히고 흔들린다. --intro punch(릴스·스토리): 번쩍 + 첫 줄 크게 + 위쪽 제목 띠.
폰트는 맑은 고딕 Bold(Windows 기본). 자막 위치 y 기본 1330(1080x1920 기준, 인스타·쇼츠 하단 UI를 피함).
"""
from __future__ import annotations

import os
import argparse
import json
import math
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

HANGUL = re.compile(r"[가-힣]")
TAG_RE = re.compile(r"^\[([^\]]+)\]\s*$")
PAREN_RE = re.compile(r"\(([^)]*)\)")

# ASS 색은 &HBBGGRR& (파랑 초록 빨강 순서)
C_WHITE, C_BLACK = "FFFFFF", "000000"
C_YELLOW, C_RED = "00E5FF", "2D2DFF"
GLOWS = ["952DFF", "FFE500", "7CFF00", "008AFF"]   # 분홍, 하늘, 연두, 주황 (RGB 로는 FF2D95, 00E5FF, 00FF7C, FF8A00)
FONT = "Malgun Gothic"


def syl(s: str) -> int:
    return len(HANGUL.findall(s))


def read_md(md: Path) -> tuple[str, str]:
    blocks = re.findall(r"```[^\n]*\n(.*?)```", md.read_text(encoding="utf-8"), flags=re.S)
    if len(blocks) < 2:
        sys.exit("최종.md 에서 코드 블록 2개(스타일, 가사)를 찾지 못했습니다")
    return blocks[0].strip(), blocks[1].strip()


def parse_lines(lyrics: str) -> list[dict]:
    """가사의 노래 줄만(Intro/Outro/Instrumental 제외) 순서대로."""
    out: list[dict] = []
    sec = ""
    for raw in lyrics.splitlines():
        t = raw.strip()
        m = TAG_RE.match(t)
        if m:
            sec = m.group(1).split(":")[0].strip().lower()
            continue
        if not t or any(k in sec for k in ("intro", "outro", "instrumental")):
            continue
        kind = "chorus" if "chorus" in sec and "pre" not in sec else ("chant" if "chant" in sec else "verse")
        pieces = []
        pos = 0
        for pm in PAREN_RE.finditer(t):
            if t[pos:pm.start()].strip():
                pieces.append((t[pos:pm.start()].strip(), False))
            if pm.group(1).strip():
                pieces.append((pm.group(1).strip(), True))
            pos = pm.end()
        if t[pos:].strip():
            pieces.append((t[pos:].strip(), False))
        out.append({"text": t, "section": sec, "kind": kind, "pieces": pieces, "n": max(1, syl(t))})
    return out


# ------------------------------------------------------------------ 정렬
def align(args) -> None:
    sys.path.insert(0, str(Path(os.environ.get("SUNO_CYCLE_SCRIPTS") or (Path(__file__).resolve().parents[2] / "suno-music-cycle" / "scripts"))))
    import quality_check as qc
    from faster_whisper import WhisperModel

    _, lyrics = read_md(Path(args.md))
    lines = parse_lines(lyrics)
    targets = [qc.jamo(re.sub(r"[()!?.,]", "", ln["text"])) for ln in lines]
    audio = qc.load_audio_16k(args.media)
    sr = 16000
    dur = len(audio) / sr
    model = qc.make_model(args.model)        # 조각을 동시에 전사(스레드 4 고정 — 예전과 같은 결과, 시간만 줄어든다. 2026-10-20)
    prev = Path(args.json)
    if args.reuse and prev.exists() and "words" in json.loads(prev.read_text(encoding="utf-8")):
        words = [tuple(w) for w in json.loads(prev.read_text(encoding="utf-8"))["words"]]   # 이미 전사한 단어를 재사용(정렬 규칙만 다시 돌릴 때)
    else:
        words = qc.chunk_transcribe(model, audio, words=True)
    print(f"전사 단어 {len(words)}개")

    def greedy(ws, idxs, lo_t=0.0, hi_t=1e9):
        """ws: [(word,start,end)], idxs: 맞출 줄 번호들(순서대로).
        줄 순서를 지키면서 '줄-연속 단어 구간' 짝의 유사도 합(0.5 초과분)이 최대가 되도록 동적 계획법으로 맞춘다.
        (앞쪽 줄을 못 맞춰도 뒤쪽이 연쇄로 틀어지지 않고, 반복되는 후렴이 다른 후렴과 짝지어지지 않는다.)"""
        W, L = len(ws), len(idxs)
        wj = [qc.jamo(w[0]) for w in ws]
        # 후보: (줄 k, 시작 단어 s) -> [(끝 단어 e(포함 안 함), 점수)]
        cand: dict[tuple[int, int], list[tuple[int, float]]] = {}
        for k, i in enumerate(idxs):
            tgt = targets[i]
            n = len(tgt)
            for s in range(W):
                acc = ""
                lst = []
                for e in range(s, min(W, s + 14)):
                    acc += wj[e]
                    if len(acc) < n * 0.6:
                        continue
                    if len(acc) > n * 1.5:
                        break
                    if ws[e][2] - ws[s][1] > 14.0:
                        break
                    r = qc.ratio(acc, tgt)
                    if r >= 0.55:
                        lst.append((e + 1, r))
                if lst:
                    cand[(k, s)] = lst
        # best[k][j]: 앞 k줄을 단어 j개 안에서 맞춘 최대 점수
        NEG = -1e9
        best = [[NEG] * (W + 1) for _ in range(L + 1)]
        back = [[None] * (W + 1) for _ in range(L + 1)]
        for j in range(W + 1):
            best[0][j] = 0.0
        for k in range(1, L + 1):
            for j in range(W + 1):
                v, b = NEG, None
                if j > 0 and best[k][j - 1] > v:
                    v, b = best[k][j - 1], ("w",)
                if best[k - 1][j] > v:
                    v, b = best[k - 1][j], ("l",)
                best[k][j], back[k][j] = v, b
            # 매칭 전이: 이 줄(k-1)이 단어 [s, e) 와 짝지어진다
            for s in range(W):
                if best[k - 1][s] <= NEG / 2:
                    continue
                for e, r in cand.get((k - 1, s), []):
                    v = best[k - 1][s] + (r - 0.5)
                    if v > best[k][e]:
                        best[k][e], back[k][e] = v, ("m", s, r)
            # 단어 건너뛰기 전이를 다시 전파(매칭으로 갱신된 값이 오른쪽으로 번지게)
            for j in range(1, W + 1):
                if best[k][j - 1] > best[k][j]:
                    best[k][j], back[k][j] = best[k][j - 1], ("w",)
        res = {}
        k, j = L, W
        while k > 0:
            b = back[k][j]
            if b is None:
                break
            if b[0] == "w":
                j -= 1
            elif b[0] == "l":
                k -= 1
            else:
                _, s, r = b
                i = idxs[k - 1]
                res[i] = (ws[s][1], ws[j - 1][2], r)
                k -= 1
                j = s
        return res

    first = greedy(words, list(range(len(lines))))
    times: dict[int, tuple[float, float, float]] = dict(first)
    print(f"1차 정렬 {len(times)}/{len(lines)}줄")

    # 못 맞춘 줄이 이어진 구간은 그 구간만 다시 짧은 창(14초)으로 전사해서 한 번 더 맞춘다
    # (도입부에서 음성 인식이 환각을 내면 첫 벌스가 통째로 빠진다: 1호곡 벌스1)
    i = 0
    while i < len(lines):
        if i in times:
            i += 1
            continue
        j = i
        while j < len(lines) and j not in times:
            j += 1
        left = times[i - 1][1] if i - 1 in times else 0.0
        right = times[j][0] if j in times else dur
        a, b = max(0.0, left - 0.5), min(dur, right + 0.5)
        if b - a >= 3.0:
            seg = audio[int(a * sr):int(b * sr)]
            ws = qc.chunk_transcribe(model, seg, words=True, chunk=14.0, overlap=3.0)
            ws = [(w, s + a, e + a) for w, s, e in ws]
            fix = greedy(ws, list(range(i, j)))
            for k, v in fix.items():
                times[k] = v
            print(f"재정렬 {i}~{j - 1}줄: {len(fix)}/{j - i} ({a:.1f}~{b:.1f}초)")
        i = j

    # 끝까지 못 맞춘 줄은 앞뒤 줄 사이에 음절 수 비율로 나눠 넣는다
    est = {}
    i = 0
    while i < len(lines):
        if i in times:
            i += 1
            continue
        j = i
        while j < len(lines) and j not in times:
            j += 1
        left = times[i - 1][1] if i - 1 in times else None
        right = times[j][0] if j in times else None
        if left is None and right is None:
            left, right = 0.0, dur
        elif left is None:
            left = max(0.0, right - sum(lines[k]["n"] for k in range(i, j)) / 5.0 - 1.0)
        elif right is None:
            right = min(dur, left + sum(lines[k]["n"] for k in range(i, j)) / 5.0 + 1.0)
        total = sum(lines[k]["n"] for k in range(i, j))
        t = left
        for k in range(i, j):
            span = (right - left) * lines[k]["n"] / total
            est[k] = (t, t + span, 0.0)
            t += span
        i = j
    times.update(est)

    out = []
    for k, ln in enumerate(lines):
        s, e, r = times[k]
        out.append({"i": k, "start": round(s, 2), "end": round(e, 2), "score": round(r, 2), "estimated": k in est, "text": ln["text"],
                    "kind": ln["kind"], "section": ln["section"]})
    Path(args.json).write_text(json.dumps({"duration": dur, "lines": out, "words": [[w, round(s, 2), round(e, 2)] for w, s, e in words]},
                                          ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"완료: 정렬 {len(lines) - len(est)}/{len(lines)}줄, 추정 {len(est)}줄 → {args.json}")


# ------------------------------------------------------------------ ASS
def ts(t: float) -> str:
    t = max(0.0, t)
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def wrap(text: str, per_row: int) -> list[str]:
    """공백 기준으로 줄 수를 맞춰 균형 있게 나눈다."""
    words = text.split()
    total = len(text.replace(" ", "")) + len(words) - 1
    rows = max(1, math.ceil(total / per_row))
    if rows == 1:
        return [text]
    target = total / rows
    out, cur = [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > target + 1.5 and len(out) < rows - 1:
            out.append(cur)
            cur = w
        else:
            cur = (cur + " " + w).strip()
    out.append(cur)
    return out


def est_em(s: str) -> float:
    """맑은 고딕 굵은 글씨의 가로 폭을 글자 크기(em) 단위로 어림한다(한글·한자 1.0, 공백 0.32, 영문·숫자 0.6, 괄호·문장부호 0.4)."""
    w = 0.0
    for ch in s:
        if ch == " ":
            w += 0.32
        elif ord(ch) >= 0x1100:
            w += 1.0
        elif ch.isalnum():
            w += 0.6
        else:
            w += 0.4
    return w


def fit_band(tag: str, tl: str, width: int, base: int = 72) -> tuple[list[str], int, int]:
    """위쪽 제목 띠(punch)를 화면 폭에 맞춘다. WrapStyle 2 라서 자동 줄바꿈이 없어, 긴 제목(`치즈가 쭉 늘어나는 소리 (피자 응답가)`)이
    한 줄로는 양쪽이 잘렸다(2026-10-18 피자 릴스). 한 줄에 들어가면 그대로, 아니면 `태그 / 제목(2줄)` 로 나누고 글자 크기를 줄인다.
    반환: (줄 목록, 글자 크기, 처음 확대 %). 확대 %까지 화면 폭의 94% 안에 들어오게 한다."""
    label = f"{tag}  {tl}".strip() if tag else tl
    if est_em(label) * base * 1.20 <= width * 0.94:
        return [label], base, 120
    rows = ([tag] if tag else []) + wrap(tl, 12)
    maxem = max(est_em(r) for r in rows)
    fs = int(min(base, width * 0.94 / (maxem * 1.15)))
    return rows, max(40, fs), 115


def esc(s: str) -> str:
    return s.replace("{", "(").replace("}", ")").replace("\\", "")


def colorize(rows: list[str], keywords: list[str], base: str) -> str:
    text = r"\N".join(esc(r) for r in rows)
    for kw in sorted(keywords, key=len, reverse=True):
        if kw and kw in text:
            text = text.replace(kw, "{\\1c&H%s&}%s{\\1c&H%s&}" % (C_YELLOW if base != C_YELLOW else C_WHITE, kw, base))
    return text


def build_ass(lines: list[dict], opts) -> str:
    W, H = opts.width, opts.height
    start0 = opts.start or 0.0
    end0 = opts.end or 1e9
    keywords = [k.strip() for k in (opts.keywords or "").split(",") if k.strip()]
    ev: list[str] = []

    def dlg(layer, t0, t1, text):
        ev.append(f"Dialogue: {layer},{ts(t0)},{ts(t1)},Main,,0,0,0,,{text}")

    def pair(t0, t1, rows_text_main, rows_text_glow, pos, size, fill, glow, outline, anim):
        """글로우(스티커 외곽) 레이어 + 본문 레이어를 같은 위치·애니메이션으로 겹친다."""
        pre = "{\\an5\\pos(%d,%d)\\fs%d%s}" % (pos[0], pos[1], size, anim)
        dlg(0, t0, t1, pre.replace("}", "\\1c&H%s&\\3c&H%s&\\bord%d\\shad0\\blur3}" % (glow, glow, outline + 13), 1) + rows_text_glow)
        dlg(1, t0, t1, pre.replace("}", "\\1c&H%s&\\3c&H000000&\\bord%d\\shad5\\4c&H000000&}" % (fill, outline), 1) + rows_text_main)

    # ---- 가사 줄
    for ln in lines:
        s, e = ln["start"], ln["end"]
        if e <= start0 or s >= end0:
            continue
        s, e = max(s, start0) - start0, min(e, end0) - start0
        if e - s < 0.3:
            continue
        pieces = ln["pieces"] or [(ln["text"], False)]
        nsyl = [max(1, syl(p[0])) for p in pieces]
        tot = sum(nsyl)
        acc = 0
        k = ln["i"]
        glow = GLOWS[k % len(GLOWS)]
        chorus = ln["kind"] == "chorus"
        for (ptxt, shout), n in zip(pieces, nsyl):
            t0 = s + (e - s) * acc / tot
            acc += n
            if shout:
                # 외침: 윗쪽에 크게, 빨강 + 흰 테두리. 줄이 끝날 때까지 유지
                rows = wrap(ptxt, 6)
                txt = r"\N".join(esc(r) for r in rows)
                shake = r"\fscx190\fscy190\frz-6\t(0,90,\fscx135\fscy135\frz5)\t(90,180,\frz-4)\t(180,270,\frz3)\t(270,360,\frz0\fscx125\fscy125)\fad(0,120)"
                pre = "{\\an5\\pos(%d,%d)\\fs%d%s}" % (W // 2, int(H * 0.33), 150, shake)
                dlg(0, t0, max(e, t0 + 0.9) + 0.1, pre.replace("}", "\\1c&H000000&\\3c&H000000&\\bord30\\shad0\\blur2}", 1) + txt)
                dlg(1, t0, max(e, t0 + 0.9) + 0.1, pre.replace("}", "\\1c&H%s&\\3c&HFFFFFF&\\bord9\\shad6\\4c&H000000&}" % C_RED, 1) + txt)
            else:
                per_row = 9 if chorus else 10
                rows = wrap(ptxt, per_row)
                size = (118 if chorus else 104) - (16 if len(rows) >= 3 else 0)
                if len(ptxt.replace(" ", "")) <= 6:     # 선창 한 마디(`에어컨아`)는 더 크게
                    size += 44
                fill = C_YELLOW if chorus else C_WHITE
                gcol = C_RED if chorus else glow
                tilt = (-3 if k % 2 else 3) if chorus else 0
                anim = r"\fscx135\fscy135\frz%d\t(0,110,\fscx100\fscy100\frz%d)\fad(50,110)" % (tilt * 2, tilt)
                main = colorize(rows, keywords, fill)
                glw = r"\N".join(esc(r) for r in rows)
                # 일반 문장은 줄 시작부터 끝까지 보인다. `(외침) 문장` 줄에서는 외침이 앞 몫 시각에 위쪽에서 터진다.
                pair(s, e, main, glw, (W // 2, int(opts.text_y)), size, fill, gcol, 7, anim)

    # ---- 오프닝 연출
    tl = opts.title
    tag = opts.tag
    if opts.intro in ("full", "punch"):
        # 번쩍: 흰 사각형이 0.45초에 걸쳐 사라진다
        ev.append("Dialogue: 5,%s,%s,Main,,0,0,0,,{\\an7\\p1\\pos(0,0)\\1c&HFFFFFF&\\bord0\\shad0\\alpha&HFF&\\t(70,100,\\alpha&H00&)\\t(100,520,\\alpha&HFF&)}m 0 0 l %d 0 %d %d 0 %d{\\p0}"
                  % (ts(0.0), ts(0.55), W, W, H, H))
    if opts.intro == "full" and tl:
        dur_i = opts.intro_sec
        big = 170 if len(tl) <= 6 else (140 if len(tl) <= 8 else 112)
        rows = wrap(tl, 7 if len(tl) > 8 else 9)
        txt = r"\N".join(esc(r) for r in rows)
        pop = r"\fscx420\fscy420\alpha&HFF&\t(0,140,\fscx118\fscy118\alpha&H00&)\t(140,300,\fscx100\fscy100)" \
              r"\t(300,380,\frz-3)\t(380,460,\frz3)\t(460,540,\frz-2)\t(540,620,\frz0)\fad(0,260)"
        ytitle = int(H * 0.42)
        for layer, (fill, outl, outc, extra) in enumerate((("000000", 30, "000000", "\\blur2"), (C_YELLOW, 12, "000000", "\\shad7\\4c&H000000&"))):
            pre = "{\\an5\\pos(%d,%d)\\fs%d%s\\1c&H%s&\\3c&H%s&\\bord%d%s}" % (W // 2, ytitle, big, pop, fill, outc, outl, extra)
            ev.append(f"Dialogue: {6 + layer},{ts(0.0)},{ts(dur_i)},Main,,0,0,0,,{pre}{txt}")
        if tag:
            pre = "{\\an5\\pos(%d,%d)\\fs90\\fscx140\\fscy140\\alpha&HFF&\\t(100,300,\\fscx100\\fscy100\\alpha&H00&)\\fad(0,260)\\1c&HFFFFFF&\\3c&H%s&\\bord12\\shad0}" % (W // 2, int(H * 0.27), GLOWS[0])
            ev.append(f"Dialogue: 8,{ts(0.0)},{ts(dur_i)},Main,,0,0,0,,{pre}{esc(tag)}")
    elif opts.intro == "punch" and (tl or tag):
        brows, bfs, bpop = fit_band(tag, tl, W)
        ycen = int(H * 0.12) + (int(bfs * 0.55) * (len(brows) - 1) if len(brows) > 1 else 0)
        pre = "{\\an5\\pos(%d,%d)\\fs%d\\fscx%d\\fscy%d\\t(0,160,\\fscx100\\fscy100)\\fad(0,300)\\1c&HFFFFFF&\\3c&H%s&\\bord12\\shad0}" % (W // 2, ycen, bfs, bpop, bpop, GLOWS[0])
        ev.append(f"Dialogue: 8,{ts(0.0)},{ts(2.8)},Main,,0,0,0,,{pre}" + r"\N".join(esc(r) for r in brows))

    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Main,{FONT},84,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,7,3,5,40,40,40,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    return header + "\n".join(ev) + "\n"


def cmd_ass(args) -> None:
    data = json.loads(Path(args.lines).read_text(encoding="utf-8"))
    lines_t = data["lines"]
    _, lyrics = read_md(Path(args.md))
    parsed = parse_lines(lyrics)
    lines = []
    for t, p in zip(lines_t, parsed):
        lines.append({**p, "i": t["i"], "start": t["start"], "end": t["end"]})
    if args.shift:                                   # 자막이 노래보다 빠르면(+) 늦추고 느리면(-) 당긴다
        for ln in lines:
            ln["start"] += args.shift
            ln["end"] += args.shift
    # 줄이 겹치지 않게 다듬는다: 끝은 다음 줄 시작 직전, 간격이 1.2초 넘으면 0.35초만 더 보여 준다
    for k, ln in enumerate(lines):
        nxt = lines[k + 1]["start"] if k + 1 < len(lines) else ln["end"] + 2.0
        ln["end"] = min(max(ln["end"] + 0.15, ln["start"] + 1.0), nxt - 0.02) if nxt - ln["end"] < 1.2 else ln["end"] + 0.35
        if ln["end"] <= ln["start"]:
            ln["end"] = ln["start"] + 0.8
    Path(args.out).write_text(build_ass(lines, args), encoding="utf-8")
    shown = sum(1 for ln in lines if ln["end"] > (args.start or 0) and ln["start"] < (args.end or 1e9))
    print(f"완료: {args.out} (자막 줄 {shown}개, intro={args.intro})")


def cmd_cuts(args) -> None:
    """정렬 결과(줄 시각)로 릴스(후렴1 시작 ~ 후렴2 끝)와 스토리(후렴1만) 컷 시각을 제안한다.
    첫 줄의 시작 시각은 앞 구간까지 늘어나 보일 수 있어서 시작은 +0.1초, 끝은 다음 줄 시작 -0.1초로 잡는다. 컷을 만든 뒤 꼭 ASR 로 검증한다."""
    data = json.loads(Path(args.lines).read_text(encoding="utf-8"))
    L = data["lines"]
    groups: list[list[int]] = []
    for ln in L:
        if ln["section"] == "chorus":
            if groups and groups[-1][-1] == ln["i"] - 1:
                groups[-1].append(ln["i"])
            else:
                groups.append([ln["i"]])
    if len(groups) < 2:
        sys.exit("[Chorus] 가 2개 이상 필요합니다")

    words = data.get("words") or []

    def end_of(idx: int) -> float:
        """줄 끝(=마지막 단어 끝) 기준. 다음 줄이 붙어 있거나 겹치면 +0.05초(2호곡: 75.18초에 끝난 마지막 단어를 75.25초에 끊어 통과),
        간격이 있으면 +0.3초(다음 줄 시작 -0.1초 이내)."""
        nxt = L[idx + 1]["start"] if idx + 1 < len(L) else data["duration"]
        e = L[idx]["end"]
        if nxt - e < 0.1:
            return e + 0.05
        return min(e + 0.3, nxt - 0.1)

    def onset_of(idx: int) -> float:
        """줄 첫 단어의 시작은 앞 단어 끝에서 이어져 늘어나 보인다(`냄비에` 3음절이 2초). 끝 시각에서 음절 수 x 0.24초를 빼서 온셋을 추정한다."""
        s = L[idx]["start"]
        for w, ws, we in words:
            if abs(ws - s) < 0.03:
                return max(s, we - 0.24 * max(1, syl(w)))
        return s + 0.1

    g0, g1 = groups[0], groups[1]
    start = round(onset_of(g0[0]) - 0.2, 2)
    reel_end = round(end_of(g1[-1]), 2)
    if reel_end - start > 88:                       # 90초 제한: 후렴2 중간 줄에서 끊는다
        for idx in reversed(g1):
            if end_of(idx) - start <= 88:
                reel_end = round(end_of(idx), 2)
                break
    out = {"reel": {"start": start, "end": reel_end, "duration": round(reel_end - start, 2)},
           "story": {"start": start, "end": round(end_of(g0[-1]), 2)}}
    out["story"]["duration"] = round(out["story"]["end"] - start, 2)
    out["chorus1_lines"] = g0
    out["chorus2_lines"] = g1
    if args.json:
        Path(args.json).write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(out, ensure_ascii=False))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("cuts")
    c.add_argument("--lines", required=True)
    c.add_argument("--json")
    c.set_defaults(fn=cmd_cuts)
    a = sub.add_parser("align")
    a.add_argument("--media", required=True)
    a.add_argument("--md", required=True)
    a.add_argument("--json", required=True)
    a.add_argument("--model", default="small")
    a.add_argument("--reuse", action="store_true", help="--json 에 저장된 전사 단어를 재사용(정렬 규칙만 다시 돌릴 때)")
    a.set_defaults(fn=align)
    s = sub.add_parser("ass")
    s.add_argument("--lines", required=True, help="align 이 만든 json")
    s.add_argument("--md", required=True)
    s.add_argument("--out", required=True)
    s.add_argument("--start", type=float, default=0.0, help="컷 시작(초). 자막 시각을 이만큼 앞당긴다")
    s.add_argument("--end", type=float, default=None, help="컷 끝(초)")
    s.add_argument("--intro", choices=["full", "punch", "none"], default="none")
    s.add_argument("--intro-sec", type=float, default=3.8)
    s.add_argument("--title", default="")
    s.add_argument("--tag", default="병맛 찬양가")
    s.add_argument("--keywords", default="", help="노란색으로 강조할 단어(쉼표). 컨셉 JSON 의 items")
    s.add_argument("--width", type=int, default=1080)
    s.add_argument("--height", type=int, default=1920)
    s.add_argument("--text-y", type=float, default=1330)
    s.add_argument("--shift", type=float, default=0.0, help="모든 줄 시각을 이만큼(초) 민다. 자막이 빠르면 +0.3 처럼")
    s.set_defaults(fn=cmd_ass)
    args = ap.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
