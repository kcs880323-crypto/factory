#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""병맛 노래 제작: 짧은 영상 한 개를 곡 길이만큼 반복해서 영상을 만든다 (ffmpeg 필요, 표준 라이브러리만 사용).

  # 풀 영상 (곡 전체)
  python make_loop_video.py --clip genspark.mp4 --audio 곡.mp3 --out publish/날짜_제목_full.mp4
  # 릴스·쇼츠용 컷 (곡의 S~E초 구간, 영상은 처음부터 반복)
  python make_loop_video.py --clip genspark.mp4 --audio 곡.mp3 --out publish/날짜_제목_reel.mp4 --start 42.4 --end 117.7 --fade 0.25

- 반복은 기본이 '왕복'(앞으로 재생 후 거꾸로 재생)이라서 클립 끝과 처음이 튀지 않는다. --no-pingpong 으로 끈다.
- 클립 비율이 목표(기본 세로 1080x1920)와 다르면 배경을 흐리게 채우고 가운데에 맞춰 넣는다. --layout landscape 는 1920x1080.
- 오디오는 음질 보존(true peak 가 -1dBFS 를 넘을 때만 이득을 낮춤, --lufs 로 선형 음량 맞춤 가능). 30fps, H.264, AAC 320k·48kHz.
"""
from __future__ import annotations

import argparse
import glob
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")


def tool(name: str) -> str:
    p = shutil.which(name)
    if p:
        return p
    pattern = os.path.join(os.environ.get("LOCALAPPDATA", ""), "Microsoft", "WinGet", "Packages",
                           "Gyan.FFmpeg*", "**", "bin", name + ".exe")
    hits = glob.glob(pattern, recursive=True)
    if hits:
        return hits[0]
    sys.exit(f"{name} 를 찾을 수 없습니다 (ffmpeg 설치 필요)")


def probe(path: str, entries: str, stream: str | None = None) -> str:
    cmd = [tool("ffprobe"), "-v", "error"]
    if stream:
        cmd += ["-select_streams", stream]
    cmd += ["-show_entries", entries, "-of", "default=nw=1:nk=1", path]
    return subprocess.run(cmd, capture_output=True, text=True).stdout.strip()


def run(cmd: list[str]) -> None:
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        sys.exit("ffmpeg 실패:\n" + r.stderr[-1500:])


def safe_gain_filter(audio: str, ss: float, dur: float, ceiling: float = -1.0, lufs: float = 0.0) -> str:
    """음질 보존(2026-10-18): true peak 가 ceiling 보다 높을 때만 그만큼 낮추는 선형 이득. 리미터·loudnorm·리샘플 없음. lufs 를 주면 선형으로 그 음량까지(최대 +3dB)."""
    import re as _re
    r = subprocess.run([tool("ffmpeg"), "-hide_banner", "-nostats", "-ss", f"{ss:.3f}", "-t", f"{dur:.3f}", "-i", str(Path(audio).resolve()), "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    tail = r.stderr[r.stderr.rfind("Summary"):] if "Summary" in r.stderr else ""
    mi = _re.search(r"I:\s+(-?\d+\.\d+) LUFS", tail)
    mp = _re.search(r"True peak:\s+Peak:\s+(-?\d+\.\d+) dBFS", tail) or _re.search(r"Peak:\s+(-?\d+\.\d+) dBFS", tail)
    if not mp:
        return ""
    tp = float(mp.group(1))
    gain = min(0.0, ceiling - tp)
    if lufs and mi:
        gain = max(gain, min(lufs - float(mi.group(1)), ceiling - tp, 3.0))
    return f"volume={gain:.2f}dB" if abs(gain) > 0.005 else ""


def fit_filter(w: int, h: int, src_w: int, src_h: int) -> str:
    """목표 해상도에 맞춘다. 비율이 5% 이내로 같으면 꽉 채워 자르고, 다르면 흐린 배경 + 가운데 배치."""
    if abs((src_w / src_h) - (w / h)) / (w / h) <= 0.05:
        return f"[0:v]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},setsar=1,fps=30,format=yuv420p[o]"
    return (f"[0:v]split[a][b];[a]scale={w}:{h}:force_original_aspect_ratio=increase,crop={w}:{h},boxblur=30:5[bg];"
            f"[b]scale={w}:{h}:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1,fps=30,format=yuv420p[o]")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--clip", required=True, help="Genspark 짧은 영상")
    ap.add_argument("--audio", required=True, help="Suno 곡 (mp3/mp4/wav)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--start", type=float, default=0.0, help="곡의 시작(초)")
    ap.add_argument("--end", type=float, default=0.0, help="곡의 끝(초). 0이면 곡 끝까지")
    ap.add_argument("--fade", type=float, default=0.0, help="끝 페이드(초). 컷에서는 0.25 권장")
    ap.add_argument("--layout", choices=["portrait", "landscape"], default="portrait")
    ap.add_argument("--no-pingpong", action="store_true")
    ap.add_argument("--lufs", type=float, default=0.0, help="목표 음량. 기본 0=끔(음질 보존)")
    ap.add_argument("--crf", type=int, default=21)
    ap.add_argument("--ass", help="병맛 자막 ASS (make_subs.py ass 가 만든다). 영상에 입힌다")
    ap.add_argument("--intro-clip", help="임팩 오프닝 클립(Genspark). 영상의 처음 --intro-sec 초를 이것으로 대체한다")
    ap.add_argument("--intro-sec", type=float, default=3.8)
    a = ap.parse_args()

    for p in (a.clip, a.audio, a.ass, a.intro_clip):
        if p and not Path(p).exists():
            sys.exit(f"파일이 없습니다: {p}")
    w, h = (1080, 1920) if a.layout == "portrait" else (1920, 1080)
    total = float(probe(a.audio, "format=duration"))
    end = a.end if a.end > 0 else total
    dur = end - a.start
    if dur <= 1:
        sys.exit(f"구간이 너무 짧습니다 ({a.start}~{end}초, 곡 길이 {total:.1f}초)")
    cw, ch = (int(x) for x in probe(a.clip, "stream=width,height", "v:0").split()[:2])
    clip_dur = float(probe(a.clip, "format=duration"))
    print(f"클립 {cw}x{ch} {clip_dur:.1f}초 -> {w}x{h}, 곡 구간 {a.start:.2f}~{end:.2f}초 ({dur:.1f}초), 반복 약 {dur / (clip_dur * (1 if a.no_pingpong else 2)):.1f}회")

    ff = tool("ffmpeg")
    with tempfile.TemporaryDirectory() as td:
        # 1단계: 목표 해상도·30fps 로 맞춘 한 바퀴(base)를 만든다.
        base = str(Path(td) / "base.mp4")
        run([ff, "-v", "error", "-y", "-i", a.clip, "-an", "-filter_complex", fit_filter(w, h, cw, ch), "-map", "[o]",
             "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", base])
        # 2단계: 왕복(앞으로 + 거꾸로)으로 이어 붙여 반복 지점이 튀지 않게 한다.
        if a.no_pingpong:
            loop = base
        else:
            loop = str(Path(td) / "loop.mp4")
            run([ff, "-v", "error", "-y", "-i", base, "-an", "-filter_complex",
                 "[0:v]split[f][r0];[r0]reverse[r];[f][r]concat=n=2:v=1:a=0[v]", "-map", "[v]",
                 "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", loop])

        # 임팩 오프닝 클립: 영상의 처음 --intro-sec 초만 이것으로 바꾼다(곡 길이는 그대로, 오디오는 곡의 도입부가 그대로 흐른다).
        intro = None
        if a.intro_clip:
            iw, ih = (int(x) for x in probe(a.intro_clip, "stream=width,height", "v:0").split()[:2])
            intro = str(Path(td) / "intro.mp4")
            run([ff, "-v", "error", "-y", "-i", a.intro_clip, "-an", "-t", f"{a.intro_sec:.2f}", "-filter_complex", fit_filter(w, h, iw, ih),
                 "-map", "[o]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", intro])

        af = []
        sg = safe_gain_filter(a.audio, a.start, dur, lufs=a.lufs)  # 음질 보존: 필요할 때만 이득을 낮춘다(리미터·loudnorm·리샘플 없음)
        if sg:
            af.append(sg)
        if a.fade > 0:
            af.append(f"afade=t=out:st={max(0.0, dur - a.fade):.2f}:d={a.fade}")

        # 영상 필터: (오프닝 이어 붙이기) → (ASS 자막 입히기). ASS 는 폰트 폴더를 임시 폴더에 복사하고 상대 경로로 부른다(Windows 경로 이스케이프 회피).
        chain = []
        if intro:
            chain.append(f"[0:v]trim=duration={max(0.1, dur - a.intro_sec):.3f},setpts=PTS-STARTPTS[l];[2:v]setpts=PTS-STARTPTS[i];[i][l]concat=n=2:v=1:a=0[v0]")
        else:
            chain.append("[0:v]null[v0]")
        if a.ass:
            fdir = Path(td) / "fonts"
            fdir.mkdir()
            winfonts = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
            for fn in ("malgun.ttf", "malgunbd.ttf"):
                if (winfonts / fn).exists():
                    shutil.copy(winfonts / fn, fdir / fn)
            shutil.copy(a.ass, Path(td) / "subs.ass")
            chain.append("[v0]ass=subs.ass:fontsdir=fonts[v]")
        else:
            chain.append("[v0]null[v]")
        out_abs = str(Path(a.out).resolve())
        cmd = [ff, "-v", "error", "-y", "-stream_loop", "-1", "-i", str(Path(loop).resolve()), "-ss", f"{a.start:.2f}", "-t", f"{dur:.2f}", "-i", str(Path(a.audio).resolve())]
        if intro:
            cmd += ["-i", intro]
        cmd += ["-filter_complex", ";".join(chain), "-map", "[v]", "-map", "1:a:0", "-t", f"{dur:.2f}", "-c:v", "libx264", "-preset", "veryfast", "-crf", str(a.crf),
                "-maxrate", "6M", "-bufsize", "12M", "-pix_fmt", "yuv420p", "-r", "30", "-c:a", "aac", "-b:a", "320k", "-ar", "48000"]
        if af:
            cmd += ["-af", ",".join(af)]
        cmd += ["-movflags", "+faststart", out_abs]
        Path(out_abs).parent.mkdir(parents=True, exist_ok=True)
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=td)
        if r.returncode != 0:
            sys.exit("ffmpeg 실패:\n" + r.stderr[-1800:])

    od = float(probe(a.out, "format=duration"))
    ow, oh = (int(x) for x in probe(a.out, "stream=width,height", "v:0").split()[:2])
    size = Path(a.out).stat().st_size / 1e6
    print(f"완료: {a.out}  {ow}x{oh}, {od:.1f}초, {size:.1f}MB")


if __name__ == "__main__":
    main()
