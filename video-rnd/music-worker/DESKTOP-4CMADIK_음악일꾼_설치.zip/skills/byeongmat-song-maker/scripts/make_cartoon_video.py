#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AI 영상 없이 만화 무대 영상을 직접 그려서(Pillow, 박자에 맞춰) 병맛 자막과 합친다. numpy + Pillow + ffmpeg.

  asr-venv/python -u make_cartoon_video.py --audio 곡.mp3 --lines 곡_lines.json --ass full.ass --out full.mp4 [--theme pregnancy]
  ... --start 39.34 --end 91.17 --ass reel.ass --out reel.mp4

Genspark 크레딧이 없을 때(SKILL.md `Genspark 크레딧 소진 시 대체`) 쓰는 두 번째 대체 경로다(첫째는 커버 사진 클립). 파란 티셔츠·파란 반바지 둥근 머리 캐릭터가
무대 위에서 박자에 맞춰 팔을 올리고, 조명이 박자마다 색을 바꾸며, 객석 실루엣이 들썩이고, 후렴에는 색종이가 날린다. 가사에 소품 단어가 나오면 그 소품 그림이 위에 튀어 오른다.
- 박자: 곡 오디오에서 BPM(136~160, 0.05 단위)과 박 위상을 직접 잰다(20초 창마다 위상을 따로 잡아 구간 바뀜에 따라간다). 2026-10-18 `진통이 오 분 간격이래`: 147.0 BPM, 위상 0.327초.
- 구간 세기: 줄 JSON의 section 으로 정한다(후렴·chant 1.0, 벌스 0.6, 브릿지 0.25).
- 소품(`--theme pregnancy`): 입덧·초음파·배지·튼살크림·출산 가방·무통 주사·왕관(열 달의 여왕)·아기. 새 주제는 `THEMES` 에 키워드→그림을 추가한다.
- 작업 해상도 720x1280 을 ffmpeg 가 1080x1920 으로 키운다. 곡 전체(4분)는 약 5~10분 걸린다.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

sys.stdout.reconfigure(encoding="utf-8")
W, H = 720, 1280
FF = shutil.which("ffmpeg") or "ffmpeg"
FPS = 30
OUT = (15, 15, 25)
_rng = np.random.RandomState(7)
CONFETTI = [(int(_rng.randint(0, W)), int(_rng.randint(0, 900)), int(_rng.randint(140, 260))) for _ in range(48)]
PAL = [(255, 70, 160), (60, 200, 255), (255, 220, 60), (120, 255, 120)]  # 박자마다 도는 조명색(분홍·하늘·노랑·연두)


# ---------------------------------------------------------------- 박자
def beat_grid(audio: str):
    sr, hop, n_fft = 22050, 256, 1024
    raw = subprocess.run([FF, "-v", "error", "-i", audio, "-ac", "1", "-ar", str(sr), "-f", "f32le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, dtype=np.float32)
    win = np.hanning(n_fft).astype(np.float32)
    nf = (len(x) - n_fft) // hop
    S = np.empty((nf, n_fft // 2 + 1), dtype=np.float32)
    for i in range(nf):
        S[i] = np.abs(np.fft.rfft(x[i * hop:i * hop + n_fft] * win))
    L = np.log1p(S[:, 2:120] * 10)
    flux = np.maximum(0, np.diff(L, axis=0)).sum(axis=1)
    flux = np.maximum(flux - np.convolve(flux, np.ones(43) / 43, mode="same"), 0)
    t = np.arange(len(flux)) * hop / sr
    best = None
    for bpm in np.arange(136, 160, 0.05):
        P = 60 / bpm
        bins = np.zeros(20)
        np.add.at(bins, ((t % P) / P * 20).astype(int), flux)
        sc = bins.max() / (bins.mean() + 1e-9)
        if best is None or sc > best[0]:
            best = (sc, float(bpm))
    bpm = best[1]
    P = 60 / bpm
    anchors = []  # (창 중심초, 위상초)
    last = 0.0
    for lo in np.arange(0, max(1, t[-1] - 10), 10):
        m = (t >= lo) & (t < lo + 20)
        if m.sum() < 50:
            continue
        bins = np.zeros(40)
        np.add.at(bins, ((t[m] % P) / P * 40).astype(int), flux[m])
        sc = bins.max() / (bins.mean() + 1e-9)
        if sc >= 4.0:
            last = float(np.argmax(bins)) / 40 * P
        anchors.append((float(lo + 10), last))
    return bpm, P, anchors


def beat_at(tt: float, P: float, anchors):
    a = min(anchors, key=lambda z: abs(z[0] - tt))[1] if anchors else 0.0
    k = (tt - a) / P
    return k - math.floor(k), int(math.floor(k))


# ---------------------------------------------------------------- 소품 그림 (원점 중심 약 ±90px, 굵은 검정 윤곽)
def ol(d, shape, fill, w=6, kind="ellipse"):
    getattr(d, kind)(shape, fill=fill, outline=(0, 0, 0), width=w)


def icon_sick(d, cx, cy, s):
    r = 80 * s
    ol(d, (cx - r, cy - r, cx + r, cy + r), (140, 220, 110))
    for sx in (-1, 1):
        ex = cx + sx * 32 * s
        d.line((ex - 14 * s, cy - 30 * s, ex + 14 * s, cy - 18 * s), fill=(0, 0, 0), width=int(7 * s))
        ol(d, (ex - 7 * s, cy - 10 * s, ex + 7 * s, cy + 4 * s), (0, 0, 0), 1)
    pts = [(cx - 40 * s + i * 10 * s, cy + 40 * s + (8 * s if i % 2 else -8 * s)) for i in range(9)]
    d.line(pts, fill=(0, 0, 0), width=int(7 * s))
    ol(d, (cx + 55 * s, cy - 70 * s, cx + 80 * s, cy - 35 * s), (120, 200, 255), 4)  # 땀방울


def icon_scan(d, cx, cy, s):
    ol(d, (cx - 90 * s, cy - 70 * s, cx + 90 * s, cy + 70 * s), (40, 60, 110), 7, "rounded_rectangle")
    ol(d, (cx - 70 * s, cy - 52 * s, cx + 70 * s, cy + 52 * s), (15, 25, 50), 3, "rounded_rectangle")
    ol(d, (cx - 34 * s, cy - 28 * s, cx + 22 * s, cy + 26 * s), (235, 235, 245), 3)       # 콩알
    ol(d, (cx + 4 * s, cy - 36 * s, cx + 36 * s, cy - 8 * s), (235, 235, 245), 3)


def icon_badge(d, cx, cy, s):
    r = 78 * s
    ol(d, (cx - r, cy - r, cx + r, cy + r), (255, 130, 190))
    ol(d, (cx - 56 * s, cy - 56 * s, cx + 56 * s, cy + 56 * s), (255, 230, 240), 4)
    d.polygon([(cx, cy + 38 * s), (cx - 40 * s, cy - 4 * s), (cx - 22 * s, cy - 32 * s), (cx, cy - 12 * s), (cx + 22 * s, cy - 32 * s), (cx + 40 * s, cy - 4 * s)], fill=(255, 70, 120), outline=(0, 0, 0))


def icon_cream(d, cx, cy, s):
    ol(d, (cx - 66 * s, cy - 50 * s, cx + 66 * s, cy + 66 * s), (255, 240, 200), 7, "rounded_rectangle")
    ol(d, (cx - 74 * s, cy - 82 * s, cx + 74 * s, cy - 44 * s), (255, 120, 150), 6, "rounded_rectangle")
    for i in range(3):
        d.arc((cx - 44 * s, cy - 20 * s + i * 22 * s, cx + 44 * s, cy + 14 * s + i * 22 * s), 20, 160, fill=(255, 120, 150), width=int(6 * s))


def icon_bag(d, cx, cy, s):
    d.arc((cx - 48 * s, cy - 110 * s, cx + 48 * s, cy - 10 * s), 180, 360, fill=(0, 0, 0), width=int(12 * s))
    ol(d, (cx - 85 * s, cy - 40 * s, cx + 85 * s, cy + 75 * s), (255, 150, 60), 7, "rounded_rectangle")
    ol(d, (cx - 30 * s, cy - 6 * s, cx + 30 * s, cy + 22 * s), (255, 230, 160), 4, "rounded_rectangle")
    d.line((cx - 85 * s, cy + 10 * s, cx + 85 * s, cy + 10 * s), fill=(0, 0, 0), width=int(5 * s))


def icon_shot(d, cx, cy, s):
    ol(d, (cx - 96 * s, cy - 14 * s, cx - 18 * s, cy + 14 * s), (200, 200, 210), 5, "rounded_rectangle")  # 바늘
    ol(d, (cx - 20 * s, cy - 36 * s, cx + 70 * s, cy + 36 * s), (235, 245, 255), 6, "rounded_rectangle")  # 통
    ol(d, (cx + 8 * s, cy - 24 * s, cx + 52 * s, cy + 24 * s), (255, 90, 90), 3, "rounded_rectangle")
    ol(d, (cx + 70 * s, cy - 14 * s, cx + 100 * s, cy + 14 * s), (120, 120, 130), 4, "rounded_rectangle")
    ol(d, (cx + 98 * s, cy - 40 * s, cx + 112 * s, cy + 40 * s), (120, 120, 130), 4, "rounded_rectangle")


def icon_crown(d, cx, cy, s):
    pts = [(cx - 70 * s, cy + 40 * s), (cx - 78 * s, cy - 40 * s), (cx - 36 * s, cy - 4 * s), (cx, cy - 54 * s), (cx + 36 * s, cy - 4 * s), (cx + 78 * s, cy - 40 * s), (cx + 70 * s, cy + 40 * s)]
    d.polygon(pts, fill=(255, 205, 40), outline=(0, 0, 0))
    d.line(pts + [pts[0]], fill=(0, 0, 0), width=int(7 * s))
    for px, py in ((cx - 78 * s, cy - 40 * s), (cx, cy - 54 * s), (cx + 78 * s, cy - 40 * s)):
        ol(d, (px - 9 * s, py - 9 * s, px + 9 * s, py + 9 * s), (255, 70, 90), 4)


def icon_baby(d, cx, cy, s):
    r = 78 * s
    ol(d, (cx - r, cy - r, cx + r, cy + r), (255, 220, 190))
    d.arc((cx - 14 * s, cy - 100 * s, cx + 20 * s, cy - 60 * s), 200, 340, fill=(0, 0, 0), width=int(7 * s))
    for sx in (-1, 1):
        ex = cx + sx * 30 * s
        d.arc((ex - 14 * s, cy - 18 * s, ex + 14 * s, cy + 8 * s), 200, 340, fill=(0, 0, 0), width=int(6 * s))
        ol(d, (ex - 20 * s, cy + 8 * s, ex + 20 * s, cy + 28 * s), (255, 150, 160), 0)
    ol(d, (cx - 20 * s, cy + 34 * s, cx + 20 * s, cy + 62 * s), (200, 60, 70), 4)  # 우는 입


def icon_heart(d, cx, cy, s):
    ol(d, (cx - 74 * s, cy - 64 * s, cx, cy + 10 * s), (255, 70, 110), 6)
    ol(d, (cx, cy - 64 * s, cx + 74 * s, cy + 10 * s), (255, 70, 110), 6)
    d.polygon([(cx - 72 * s, cy - 18 * s), (cx + 72 * s, cy - 18 * s), (cx, cy + 78 * s)], fill=(255, 70, 110), outline=(0, 0, 0))
    ol(d, (cx - 62 * s, cy - 54 * s, cx - 8 * s, cy), (255, 70, 110), 0)
    ol(d, (cx + 8 * s, cy - 54 * s, cx + 62 * s, cy), (255, 70, 110), 0)


ICONS = {"sick": icon_sick, "scan": icon_scan, "badge": icon_badge, "cream": icon_cream, "bag": icon_bag, "shot": icon_shot, "crown": icon_crown, "baby": icon_baby, "heart": icon_heart}
THEMES = {
    "pregnancy": [("입덧", "sick"), ("초음파", "scan"), ("임산부 배지", "badge"), ("튼살", "cream"), ("출산 가방", "bag"), ("무통", "shot"),
                  ("열 달의 여왕", "crown"), ("울음소리", "baby"), ("손가락", "baby"), ("어머니", "baby"), ("산모여", "heart"), ("순산만", "heart")],
}


def icon_for(text: str, theme: str):
    for kw, ic in THEMES.get(theme, []):
        if kw in text:
            return ic
    return None


# ---------------------------------------------------------------- 장면
def make_background():
    bg = Image.new("RGB", (W, H))
    px = bg.load()
    for y in range(H):
        k = y / H
        col = (int(28 + 30 * k), int(14 + 12 * k), int(64 + 34 * k)) if y < 900 else (int(120 - 40 * (y - 900) / 380), int(70 - 25 * (y - 900) / 380), int(40 - 10 * (y - 900) / 380))
        for x in range(W):
            px[x, y] = col
    d = ImageDraw.Draw(bg)
    d.polygon([(0, 0), (150, 0), (0, 700)], fill=(120, 20, 40), outline=OUT)        # 커튼
    d.polygon([(W, 0), (W - 150, 0), (W, 700)], fill=(120, 20, 40), outline=OUT)
    for i in range(0, 380, 38):                                                    # 마루 선
        d.line((0, 900 + i, W, 900 + i), fill=(70, 40, 25), width=3)
    d.line((0, 900, W, 900), fill=OUT, width=6)
    return bg


def draw_frame(bg, tt: float, beat_f: float, beat_i: int, P: float, inten: float, icon, icon_t0: float, crown: bool, audience_seed):
    im = bg.copy()
    d = ImageDraw.Draw(im)
    pulse = max(0.0, 1 - beat_f * 2.2) ** 2
    # 조명: 박자마다 색이 바뀌고 좌우로 흔들린다
    col = PAL[beat_i % 4]
    dim = 0.35 + 0.65 * inten
    sweep = math.sin(tt / (P * 4) * 2 * math.pi)
    for ox, sgn in ((60, 1), (W - 60, -1), (W // 2, 0)):
        tx = W // 2 + sgn * (120 + 90 * sweep) + (sweep * 150 if sgn == 0 else 0)
        c = tuple(int(a * 0.25 * dim + b * (1 - 0.25 * dim)) for a, b in zip(col, (40, 25, 90)))
        d.polygon([(ox - 14, 0), (ox + 14, 0), (tx + 130, 900), (tx - 130, 900)], fill=c)
    if beat_i % 4 == 0 and pulse > 0.2 and inten > 0.5:                              # 강박 번쩍
        d.rectangle((0, 0, W, 900), outline=col, width=int(10 * pulse))
    # 객석 실루엣
    for i in range(9):
        x = 40 + i * 80 + (35 if i % 2 else 0) * 0
        bob = int(10 * math.sin(tt * 4 + i) * (0.4 + inten) + 14 * pulse * inten)
        y = 1170 - bob + (i % 2) * 34
        d.ellipse((x - 46, y + 30, x + 46, y + 150), fill=(14, 10, 22))
        d.ellipse((x - 32, y - 30, x + 32, y + 34), fill=(14, 10, 22))
        if inten > 0.9 and i % 2 == 0:                                               # 후렴: 손을 든다
            d.line((x - 36, y + 50, x - 56, y - 40 - int(20 * pulse)), fill=(14, 10, 22), width=16)
            d.line((x + 36, y + 50, x + 56, y - 40 - int(20 * pulse)), fill=(14, 10, 22), width=16)
    # 캐릭터(대체 영상의 기본형: 둥근 머리, 엄숙한 표정. AI 영상의 캐릭터는 곡마다 상황에 맞게 만든다 — SKILL.md `캐릭터 생성 기준`)
    lift = int(26 * pulse * (0.4 + inten))
    sway = int(12 * math.sin(tt / (P * 2) * 2 * math.pi) * (0.3 + inten * 0.7))
    cx = W // 2 + sway
    by = 0 - lift
    # 다리·신발
    for sx in (-1, 1):
        ol(d, (cx + sx * 44 - 20, 790 + by, cx + sx * 44 + 20, 880), (255, 215, 185), 6, "rounded_rectangle")
        ol(d, (cx + sx * 44 - 32, 868, cx + sx * 44 + 32, 902), (30, 30, 40), 5)
    ol(d, (cx - 92, 728 + by, cx + 92, 812 + by), (25, 70, 170), 7, "rounded_rectangle")      # 반바지
    # 몸통 + 불러온 배
    ol(d, (cx - 80, 560 + by, cx + 80, 740 + by), (30, 120, 235), 7, "rounded_rectangle")
    belly = 100 + int(6 * pulse)
    ol(d, (cx - belly, 600 + by, cx + belly, 600 + by + belly * 2 - 30), (30, 120, 235), 7)
    ol(d, (cx - 6, 690 + by, cx + 6, 702 + by), (20, 80, 170), 2)                          # 배꼽
    # 팔: 박자에 맞춰 번쩍 든다
    ang = 28 + (150 - 28) * pulse * (0.45 + 0.55 * inten)
    for sx in (-1, 1):
        shx, shy = cx + sx * 78, 590 + by
        a = math.radians(ang)
        hx, hy = shx + sx * 118 * math.sin(a), shy + 118 * math.cos(a)
        d.line((shx, shy, hx, hy), fill=(0, 0, 0), width=34)
        d.line((shx, shy, hx, hy), fill=(255, 215, 185), width=22)
        ol(d, (hx - 20, hy - 20, hx + 20, hy + 20), (255, 215, 185), 6)
    # 머리
    hy0 = 470 + by
    ol(d, (cx - 84, hy0 - 84, cx + 84, hy0 + 84), (255, 220, 190), 7)
    d.pieslice((cx - 84, hy0 - 84, cx + 84, hy0 + 84), 190, 350, fill=(35, 25, 30), outline=(0, 0, 0))
    for sx in (-1, 1):
        d.line((cx + sx * 20, hy0 - 26, cx + sx * 52, hy0 - 38 + 6 * sx), fill=(0, 0, 0), width=8)    # 엄숙한 눈썹
        d.ellipse((cx + sx * 36 - 7, hy0 - 12, cx + sx * 36 + 7, hy0 + 4), fill=(0, 0, 0))
        d.ellipse((cx + sx * 54 - 16, hy0 + 14, cx + sx * 54 + 16, hy0 + 34), fill=(255, 150, 160))
    d.line((cx - 20, hy0 + 40, cx + 20, hy0 + 40), fill=(0, 0, 0), width=7)
    if crown:
        icon_crown(d, cx, hy0 - 126 - int(10 * pulse), 0.62)
    # 소품 그림이 위에서 튀어 오른다
    if icon in ICONS:
        age = tt - icon_t0
        k = min(1.0, max(0.0, age / 0.22))
        s = (1 + 2.7 * (k - 1) ** 3 + 1.7 * (k - 1) ** 2) * (1.0 + 0.08 * pulse)             # 살짝 튕기는 등장
        if icon != "crown":
            ICONS[icon](d, W // 2, 235, 1.0 * max(0.05, s))
    # 색종이
    if inten > 0.9:
        for j in range(48):
            xs, ys, sp = CONFETTI[j]
            x = xs + 14 * math.sin(tt * 3 + j)
            y = (tt * sp + ys) % 900
            d.rectangle((x, y, x + 10, y + 16), fill=PAL[j % 4])
    return im


def section_inten(lines):
    def f(tt):
        cur = None
        for l in lines:
            if l["start"] <= tt:
                cur = l
            else:
                break
        if cur is None:
            return 0.5
        sec = cur.get("section", "")
        if "chorus" in sec or "chant" in sec:
            return 1.0
        if "bridge" in sec:
            return 0.25
        if "verse" in sec:
            return 0.6
        return 0.5
    return f


def safe_gain_filter(audio: str, ss: float, dur: float, ceiling: float = -1.0, lufs: float = 0.0) -> str:
    """음질 보존: true peak 가 ceiling 보다 높을 때만 그만큼 낮추는 선형 이득(`volume=XdB`)을 돌려준다. 리미터·압축·loudnorm 없음.
    lufs 를 주면 그 음량까지 선형으로 올리되 ceiling 을 넘지 않는다(최대 +3dB). 이득이 0이면 빈 문자열."""
    r = subprocess.run([FF, "-hide_banner", "-nostats", "-ss", f"{ss:.3f}", "-t", f"{dur:.3f}", "-i", str(Path(audio).resolve()), "-vn", "-af", "ebur128=peak=true", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    tail = r.stderr[r.stderr.rfind("Summary"):] if "Summary" in r.stderr else ""
    import re as _re
    mi = _re.search(r"I:\s+(-?\d+\.\d+) LUFS", tail)
    mp = _re.search(r"True peak:\s+Peak:\s+(-?\d+\.\d+) dBFS", tail) or _re.search(r"Peak:\s+(-?\d+\.\d+) dBFS", tail)
    if not mp:
        return ""
    tp = float(mp.group(1))
    gain = min(0.0, ceiling - tp)
    if lufs and mi:
        gain = max(gain, min(lufs - float(mi.group(1)), ceiling - tp, 3.0))
    print(f"오디오: 원본 {mi.group(1) if mi else '?'} LUFS / true peak {tp} dBFS -> 이득 {gain:+.2f} dB만 적용(리미터·압축 없음), AAC 320k 한 번 인코딩")
    return f"volume={gain:.2f}dB" if abs(gain) > 0.005 else ""


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--audio", required=True)
    ap.add_argument("--lines", required=True)
    ap.add_argument("--ass")
    ap.add_argument("--out", required=True)
    ap.add_argument("--theme", default="pregnancy")
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=0.0)
    ap.add_argument("--fade", type=float, default=0.25)
    ap.add_argument("--crf", type=int, default=20)
    ap.add_argument("--arate", type=int, default=48000, help="오디오 샘플레이트(Suno 원본과 같은 48000)")
    ap.add_argument("--abr", default="320k", help="오디오 비트레이트(원본 AAC 196k 보다 높게, 한 번만 인코딩)")
    ap.add_argument("--lufs", type=float, default=0.0, help="목표 음량. 기본 0=끔(음질 보존)")
    ap.add_argument("--frame", type=float, help="이 시각(곡 기준 초)의 정지 화면 PNG 하나만 저장하고 끝낸다(시험용)")
    a = ap.parse_args()

    data = json.loads(Path(a.lines).read_text(encoding="utf-8"))
    lines = sorted(data["lines"], key=lambda l: l["start"])
    total = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", a.audio], capture_output=True, text=True).stdout.strip())
    s0 = a.start
    s1 = a.end if a.end > 0 else total
    dur = s1 - s0
    bpm, P, anchors = beat_grid(a.audio)
    print(f"박자: {bpm:.2f} BPM, 위상 앵커 {len(anchors)}개")
    inten_f = section_inten(lines)
    bg = make_background()
    seeds = list(range(1, 40))

    def render(tt):
        bf, bi = beat_at(tt, P, anchors)
        icon, t0, crown = None, 0.0, False
        for l in lines:
            if l["start"] - 0.05 <= tt <= l["end"] + 0.3:
                ic = icon_for(l["text"], a.theme)
                if ic == "crown":
                    crown = True
                elif ic:
                    icon, t0 = ic, l["start"]
        # 거의 같은 줄이 연달아 있으면 가장 늦게 시작한 줄의 소품을 쓴다
        return draw_frame(bg, tt, bf, bi, P, inten_f(tt), icon, t0, crown, seeds)

    if a.frame is not None:
        render(a.frame).resize((1080, 1920)).save(Path(a.out).with_suffix(".png"))
        print("프레임 저장")
        return

    out_abs = Path(a.out).resolve()
    out_abs.parent.mkdir(parents=True, exist_ok=True)
    nframes = int(round(dur * FPS))
    with tempfile.TemporaryDirectory() as td:
        vf = "scale=1080:1920:flags=lanczos"
        if a.ass:
            fdir = Path(td) / "fonts"
            fdir.mkdir()
            wf = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Fonts"
            for fn in ("malgun.ttf", "malgunbd.ttf"):
                if (wf / fn).exists():
                    shutil.copy(wf / fn, fdir / fn)
            shutil.copy(a.ass, Path(td) / "subs.ass")
            vf += ",ass=subs.ass:fontsdir=fonts"
        vf += f",fade=t=out:st={max(0.0, dur - 0.8):.2f}:d=0.8,format=yuv420p"
        sg = safe_gain_filter(a.audio, s0, dur, lufs=a.lufs)  # 음질 보존: 이득만(리미터·loudnorm 없음)
        af = (sg + "," if sg else "") + "afade=t=in:st=0:d=0.04"
        if a.fade > 0:
            af += f",afade=t=out:st={max(0.0, dur - a.fade):.2f}:d={a.fade}"
        cmd = [FF, "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
               "-ss", f"{s0:.3f}", "-t", f"{dur:.3f}", "-i", str(Path(a.audio).resolve()),
               "-map", "0:v", "-map", "1:a", "-vf", vf, "-af", af,
               "-c:v", "libx264", "-preset", "veryfast", "-crf", str(a.crf), "-maxrate", "8M", "-bufsize", "16M", "-pix_fmt", "yuv420p", "-r", str(FPS),
               "-c:a", "aac", "-b:a", a.abr, "-ar", str(a.arate), "-t", f"{dur:.3f}", "-movflags", "+faststart", str(out_abs)]
        proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stderr=subprocess.PIPE, cwd=td)
        try:
            for i in range(nframes):
                proc.stdin.write(render(s0 + i / FPS).tobytes())
                if i % 600 == 0:
                    print(f"  {i}/{nframes} 프레임", flush=True)
            proc.stdin.close()
        except BrokenPipeError:
            pass
        err = proc.stderr.read().decode("utf-8", errors="replace")
        proc.wait()
        if proc.returncode != 0:
            sys.exit("ffmpeg 실패:\n" + err[-1500:])
    print(f"완료: {a.out}  {dur:.1f}초, {out_abs.stat().st_size / 1e6:.1f}MB")


if __name__ == "__main__":
    main()
