#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""릴스·스토리 컷의 머리와 꼬리를 직접 전사해서 첫 줄·마지막 줄이 들리는지 확인한다 (asr-venv 의 파이썬).

  asr-venv/python -u check_cut.py --cut 병맛/날짜_제목_reel.mp4 --md 병맛/날짜_제목_최종.md

첫 줄 = 첫 [Chorus] 의 첫 줄, 마지막 줄 = 첫 [Chorus] 의 마지막 줄(괄호 외침 제외). 컷 영상의 처음 5·9초, 마지막 5·9초를 전사해서
자모 유사도를 낸다. 머리 >= 0.8, 꼬리 >= 0.75 면 통과로 본다.
`find_cuts.py verify` 는 컷 머리가 `아 아 아…`로 환각하거나 후렴 문구를 잘못 들으면 컷이 맞아도 실패해서(2호곡) 이 확인을 같이 쓴다.
컷 머리 0~5초가 `아 아 아…`뿐이면 후렴 앞에 합창 도입이 붙어 있는 것이니 시작을 1~1.5초 늦춘다. 꼬리에서 마지막 음절이 빠지면 끝을 0.1~0.2초 늦춘다.
"""
from __future__ import annotations

import os
import argparse
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
sys.path.insert(0, str(Path(os.environ.get("SUNO_CYCLE_SCRIPTS") or (Path(__file__).resolve().parents[2] / "suno-music-cycle" / "scripts"))))
import quality_check as qc  # noqa: E402
from faster_whisper import WhisperModel  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--cut", required=True)
    ap.add_argument("--md", required=True)
    ap.add_argument("--head-min", type=float, default=0.8)
    ap.add_argument("--tail-min", type=float, default=0.75)
    a = ap.parse_args()

    blocks = re.findall(r"```[^\n]*\n(.*?)```", Path(a.md).read_text(encoding="utf-8"), flags=re.S)
    sec, chorus = "", []
    for raw in blocks[1].splitlines():
        t = raw.strip()
        m = re.match(r"^\[([^\]]+)\]$", t)
        if m:
            sec = m.group(1).split(":")[0].strip().lower()
            if sec == "chorus" and chorus:
                break
        elif t and sec == "chorus":
            chorus.append(re.sub(r"\([^)]*\)", "", t).strip())
    chorus = [c for c in chorus if c]
    first, last = chorus[0], chorus[-1]

    model = WhisperModel("small", device="cpu", compute_type="int8")
    audio = qc.load_audio_16k(a.cut)
    sr = 16000
    dur = len(audio) / sr
    ok = True
    print(f"컷 길이 {dur:.2f}초 / 첫 줄: {first} / 마지막 줄: {last}")
    for lab, s, e, tgt, thr in (("머리 0-5", 0, 5, first, a.head_min), ("머리 0-9", 0, 9, first, a.head_min),
                                 ("꼬리 -5", dur - 5, dur, last, a.tail_min), ("꼬리 -9", dur - 9, dur, last, a.tail_min)):
        seg, _ = model.transcribe(audio[int(max(0, s) * sr):int(e * sr)], language="ko", temperature=0.0, condition_on_previous_text=False)
        txt = "".join(x.text for x in seg).strip()
        sim = qc.best_window(qc.jamo(txt), qc.jamo(tgt))[0]
        flag = "통과" if sim >= thr else "확인"
        if flag == "확인" and lab in ("머리 0-5", "꼬리 -5"):
            ok = False
        print(f"[{flag}] {lab:9s} sim={sim:.2f} | {txt[:90]}")
    print("결과:", "통과" if ok else "머리/꼬리 보정 필요")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
