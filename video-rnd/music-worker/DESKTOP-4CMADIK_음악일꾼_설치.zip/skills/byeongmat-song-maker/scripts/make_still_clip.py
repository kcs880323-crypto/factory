#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""사진 한 장으로 짧은 세로 클립(1080x1920, 기본 6초, 천천히 확대)을 만든다. Pillow + ffmpeg.

  python -u -I make_still_clip.py --image cover.jpeg --out 병맛/날짜_제목_clip.mp4 [--sec 6] [--crop 36,36,988,988]

Genspark 크레딧이 떨어져 AI 동영상 생성을 못 할 때(SKILL.md `Genspark 크레딧 소진 시 대체`) 메인 클립 자리에 쓴다.
이 클립을 `make_loop_video.py --clip` 에 넣으면 왕복 반복(앞으로+거꾸로)이 되어 확대→축소가 이어진다. 오프닝 클립은 같은 파일로 대신하거나 `--intro-clip` 을 생략한다.
사진은 Suno 커버(`https://cdn2.suno.ai/image_large_<클립ID>.jpeg`, 1024x1024)를 쓴다. 움직임이 적어 AI 영상보다 밋밋하다 — 대신 자막 연출(make_subs.py)이 화면을 끈다.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--image", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--sec", type=float, default=6.0)
    ap.add_argument("--zoom", type=float, default=0.10, help="마지막 프레임의 추가 확대 비율")
    ap.add_argument("--crop", default="36,36,988,988", help="L,T,R,B 검은 테두리를 잘라 낸다(테두리 없는 그림은 0,0,1024,1024)")
    ap.add_argument("--square", action="store_true", help="9:16 으로 자르지 않고 정사각 1080x1080 클립으로 만든다(make_loop_video 가 흐린 배경을 채우고 가운데에 넣는다). 그림 전체를 보이고 싶을 때")
    a = ap.parse_args()
    from PIL import Image

    ff = shutil.which("ffmpeg") or "ffmpeg"
    im = Image.open(a.image).convert("RGB")
    l, t, r, b = (int(v) for v in a.crop.split(","))
    im = im.crop((l, t, r, b))
    # 세로 9:16 으로 가운데를 잘라(cover) 넉넉히 키운다(zoompan 은 정수 픽셀이라 크게 만들수록 떨림이 줄어든다).
    w, h = im.size
    if a.square:
        side = min(w, h)
        im = im.crop((0, 0, side, side)).resize((2160, 2160), Image.LANCZOS)
        out_size = "1080x1080"
    else:
        tw = int(h * 9 / 16)
        x0 = (w - tw) // 2
        im = im.crop((x0, 0, x0 + tw, h)).resize((2160, 3840), Image.LANCZOS)
        out_size = "1080x1920"
    fps = 30
    frames = int(round(a.sec * fps))
    with tempfile.TemporaryDirectory() as td:
        src = Path(td) / "still.png"
        im.save(src)
        out = Path(a.out).resolve()
        out.parent.mkdir(parents=True, exist_ok=True)
        zp = (f"zoompan=z='1+{a.zoom}*on/{frames}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={frames}:s={out_size}:fps={fps},"
              "format=yuv420p")
        cmd = [ff, "-v", "error", "-y", "-i", str(src), "-vf", zp, "-t", f"{a.sec:.2f}", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-an", str(out)]
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if r.returncode != 0:
            sys.exit("ffmpeg 실패:\n" + r.stderr[-1500:])
    print(f"완료: {a.out} ({a.sec:g}초, {out_size})")


if __name__ == "__main__":
    main()
