@echo off
chcp 65001 >nul
setlocal
echo ====================================================
echo  DESKTOP-4CMADIK NVIDIA 외장 GPU 가속(CUDA) 활성화
echo ====================================================
nvidia-smi >nul 2>nul
if errorlevel 1 (
  echo [FAIL] NVIDIA GPU 드라이버(nvidia-smi)가 감지되지 않았습니다.
  echo        NVIDIA 드라이버 설치 후 다시 실행해 주세요.
  pause
  exit /b 1
)
nvidia-smi --query-gpu=name,memory.total --format=csv,noheader
set "VENV=%USERPROFILE%\.config\suno-cycle\asr-venv"
if not exist "%VENV%\Scripts\python.exe" (
  echo [FAIL] asr-venv가 없습니다. install_music_worker.bat을 먼저 실행해 주세요.
  pause
  exit /b 1
)
echo [1/2] CUDA 런타임(cuBLAS · cuDNN) 설치 중...
"%VENV%\Scripts\python.exe" -m pip install --upgrade nvidia-cublas-cu12 nvidia-cudnn-cu12
echo [2/2] Whisper CUDA 자동 감지 확인...
"%VENV%\Scripts\python.exe" -c "import sys; sys.path.insert(0, r'%USERPROFILE%\.claude\skills\suno-music-cycle\scripts'); import quality_check as qc; dev, comp = qc.asr_device(); print('감지 결과:', dev, comp); assert dev == 'cuda', 'CUDA 미감지'"
if errorlevel 1 (
  echo [WARN] 아직 CUDA가 잡히지 않았습니다. PC 재부팅 후 다시 확인해 주세요.
) else (
  echo [OK] GPU 가속 활성화 완료! 다음 곡부터 Whisper 자막/컷 정렬이 자동으로 CUDA(float16)로 초고속 실행됩니다.
)
pause
