@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ====================================================
echo  DESKTOP-4CMADIK 자비스 음악 일꾼 1회 설치
echo ====================================================

echo [1/4] 음악 스킬 복사 (suno-music-cycle, byeongmat-song-maker)
if not exist "%USERPROFILE%\.claude\skills" mkdir "%USERPROFILE%\.claude\skills"
xcopy /E /I /Y "%~dp0skills\suno-music-cycle" "%USERPROFILE%\.claude\skills\suno-music-cycle" >nul
xcopy /E /I /Y "%~dp0skills\byeongmat-song-maker" "%USERPROFILE%\.claude\skills\byeongmat-song-maker" >nul
echo   [OK] 스킬 복사 완료

echo [2/4] Whisper 음성인식 가상환경(asr-venv) 설치
set "PYEXE="
for /f "delims=" %%i in ('py -3.13 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYEXE (
  echo   [FAIL] Python 3.13을 찾을 수 없습니다. install_worker.bat을 먼저 실행해 주세요.
  pause
  exit /b 1
)
set "VENV=%USERPROFILE%\.config\suno-cycle\asr-venv"
if not exist "%VENV%\Scripts\python.exe" (
  "%PYEXE%" -m venv "%VENV%"
)
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip
"%VENV%\Scripts\python.exe" -m pip install --upgrade faster-whisper numpy pillow scipy requests
if errorlevel 1 (
  echo   [FAIL] 패키지 설치 실패
  pause
  exit /b 1
)
echo   [OK] asr-venv 준비 완료

echo [3/4] 현재 장치(CPU/GPU) 자동 감지 테스트
"%VENV%\Scripts\python.exe" -c "import sys; sys.path.insert(0, r'%USERPROFILE%\.claude\skills\suno-music-cycle\scripts'); import quality_check as qc; print('  [OK] ASR 장치:', qc.asr_device())"

echo [4/4] 음악 전용 크롬(포트 9334) 실행 - Suno에 1회 로그인해 주세요!
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" --remote-debugging-port=9334 --remote-debugging-address=127.0.0.1 --user-data-dir="%LOCALAPPDATA%\JARVIS\music-chrome" --no-first-run --no-default-browser-check "https://suno.com/create"
  echo   [OK] Suno 로그인 창을 열었습니다. 로그인 후 창을 닫지 말고 두거나, 영상 일꾼 대시보드에서 '일꾼 최신 업데이트'를 눌러 주세요!
) else (
  echo   [WARN] Chrome 경로를 자동 감지하지 못했습니다.
)
echo.
echo ====================================================
echo  설치 완료! 이제 영상 일꾼 대시보드에서
echo  '일꾼 최신 업데이트'를 한 번 누르면 자동으로 음악 일꾼이 활성화됩니다.
echo  (향후 외장 GPU 추가 시 enable_gpu_whisper.bat 실행!)
echo ====================================================
pause
